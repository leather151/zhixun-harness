"""为网络请求错误提供无认证的 Base URL 连通性诊断。"""

import socket
import ssl
import time
from dataclasses import dataclass
from typing import Literal, TypeAlias

import httpx

ConnectivityStatus: TypeAlias = Literal[
    "reachable",
    "dns_failed",
    "connect_timeout",
    "tls_failed",
    "network_error",
    "timeout",
    "probe_failed",
]

_PROBE_TIMEOUT_SECONDS = 3.0
_PROBE_CACHE_SECONDS = 60.0


@dataclass(frozen=True)
class ConnectivityDiagnostic:
    """一次 Base URL 连通性探测的结构化结果。"""

    origin: str
    status: ConnectivityStatus
    latency_ms: int
    http_status: int = 0
    error_type: str = ""

    def details(self) -> dict[str, object]:
        values: dict[str, object] = {
            "origin": self.origin,
            "status": self.status,
            "latency_ms": self.latency_ms,
        }
        if self.http_status > 0:
            values["http_status"] = self.http_status
        if self.error_type:
            values["error_type"] = self.error_type
        return values

    def hint(self) -> str:
        if self.status == "reachable":
            return (
                "The Actor request failed after retries. The Base URL connectivity "
                f"probe reached {self.origin} (HTTP {self.http_status}, "
                f"{self.latency_ms} ms); check Actor routing or proxy rules."
            )
        return (
            "The Actor request failed after retries. The Base URL connectivity "
            f"probe to {self.origin} failed ({self.status}, {self.latency_ms} ms); "
            "check DNS, proxy, and network settings."
        )


@dataclass(frozen=True)
class _CachedDiagnostic:
    diagnostic: ConnectivityDiagnostic
    expires_at: float


_probe_cache: dict[str, _CachedDiagnostic] = {}


async def probe_base_url_connectivity(base_url: str) -> ConnectivityDiagnostic:
    """探测配置的 Base URL；诊断失败也只返回结果，不覆盖原始网络错误。"""
    started_at = time.monotonic()
    try:
        origin = str(httpx.URL(base_url).copy_with(path="/", query=None, fragment=None))
        now = time.monotonic()
        cached = _probe_cache.get(origin)
        if cached is not None and cached.expires_at > now:
            return cached.diagnostic
        diagnostic = await _run_probe(origin)
        _probe_cache[origin] = _CachedDiagnostic(
            diagnostic=diagnostic,
            expires_at=time.monotonic() + _PROBE_CACHE_SECONDS,
        )
        return diagnostic
    except Exception as error:  # noqa: BLE001 - diagnostics must never mask request
        return ConnectivityDiagnostic(
            origin=base_url,
            status="probe_failed",
            latency_ms=_elapsed_ms(started_at),
            error_type=type(error).__name__,
        )


async def _run_probe(
    origin: str,
    *,
    transport: httpx.AsyncBaseTransport | None = None,
) -> ConnectivityDiagnostic:
    started_at = time.monotonic()
    try:
        if transport is None:
            client = httpx.AsyncClient(
                timeout=httpx.Timeout(_PROBE_TIMEOUT_SECONDS),
                follow_redirects=False,
            )
        else:
            client = httpx.AsyncClient(
                timeout=httpx.Timeout(_PROBE_TIMEOUT_SECONDS),
                follow_redirects=False,
                transport=transport,
            )
        async with client:
            response = await client.head(origin)
    except httpx.ConnectTimeout as error:
        status: ConnectivityStatus = "connect_timeout"
        error_type = type(error).__name__
    except httpx.ConnectError as error:
        if _has_cause(error, socket.gaierror):
            status = "dns_failed"
        elif _has_cause(error, ssl.SSLError):
            status = "tls_failed"
        else:
            status = "network_error"
        error_type = type(error).__name__
    except httpx.TimeoutException as error:
        status = "timeout"
        error_type = type(error).__name__
    except httpx.RequestError as error:
        status = "network_error"
        error_type = type(error).__name__
    else:
        return ConnectivityDiagnostic(
            origin=origin,
            status="reachable",
            latency_ms=_elapsed_ms(started_at),
            http_status=response.status_code,
        )
    return ConnectivityDiagnostic(
        origin=origin,
        status=status,
        latency_ms=_elapsed_ms(started_at),
        error_type=error_type,
    )


def _has_cause(error: BaseException, cause_type: type[BaseException]) -> bool:
    current: BaseException | None = error
    seen: set[int] = set()
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        if isinstance(current, cause_type):
            return True
        current = current.__cause__ or current.__context__
    return False


def _elapsed_ms(started_at: float) -> int:
    return max(0, round((time.monotonic() - started_at) * 1000))
