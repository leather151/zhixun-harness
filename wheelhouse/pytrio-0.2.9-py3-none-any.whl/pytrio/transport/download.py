"""执行 checkpoint 续传、下载源刷新和响应完整性校验。"""

import asyncio
import json
import logging
import random
import re
import ssl
import xml.etree.ElementTree as ET
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import TypeVar, cast
from urllib.parse import urlparse

import httpx

from pytrio.config.config import Configuration, configuration
from pytrio.errors.base import PyTrioError
from pytrio.protocol.control.checkpoint.download import (
    CheckpointDownloadSource,
)
from pytrio.transport.retry import (
    RETRYABLE_EXCEPTIONS,
    RETRYABLE_STATUS_CODES,
    request_error_message,
)

logger = logging.getLogger(__name__)

_DOWNLOAD_CHUNK_SIZE = 1024 * 1024
_DOWNLOAD_URL_REFRESH_WINDOW_SECONDS = 60
_CONTENT_RANGE_PATTERN = re.compile(r"bytes (\d+)-(\d+)/(\d+)")
_UNSATISFIED_CONTENT_RANGE_PATTERN = re.compile(r"bytes \*/(\d+)")
FileIOResultT = TypeVar("FileIOResultT")


async def _run_blocking_file_call(
    call: Callable[..., FileIOResultT],
    *args: object,
    cancelled_result_cleanup: Callable[[FileIOResultT], object] | None = None,
) -> FileIOResultT:
    """Finish one file operation before propagating task cancellation.

    ``asyncio.to_thread`` cancellation does not stop the worker call. Shielding and
    joining it here prevents a later close from racing an in-progress write. Calls
    such as ``open`` may return an owned resource, so their cancellation path can
    provide a cleanup that is itself completed before cancellation escapes.
    """
    task = asyncio.create_task(asyncio.to_thread(call, *args))
    cancellation: asyncio.CancelledError | None = None
    while True:
        try:
            result = await asyncio.shield(task)
            break
        except asyncio.CancelledError as error:
            cancellation = error
        except BaseException:
            if cancellation is not None:
                raise cancellation from None
            raise
    if cancellation is None:
        return result
    if cancelled_result_cleanup is not None:
        try:
            await _run_blocking_file_call(cancelled_result_cleanup, result)
        except asyncio.CancelledError as error:
            cancellation = error
        except Exception:
            # Cancellation is the public terminal state. The cleanup call has
            # already completed, so its failure must not replace that state.
            logger.debug("Cancelled file-open cleanup failed", exc_info=True)
    raise cancellation


def _download_error_fields(
    body: bytes,
    *,
    encoding: str | None = None,
) -> tuple[str, str, dict[str, object]]:
    """从下载失败响应中保留 JSON、XML 或纯文本错误信息。"""
    if not body:
        return "", "", {}

    try:
        parsed = cast(object, json.loads(body))
    except (UnicodeDecodeError, json.JSONDecodeError):
        parsed = None
    if isinstance(parsed, dict):
        raw = cast(dict[object, object], parsed)
        details = {str(key): value for key, value in raw.items()}
        nested = raw.get("error")
        values = cast(dict[object, object], nested) if isinstance(nested, dict) else raw
        code_value = values.get("code", "")
        message_value = values.get("message", "")
        code = code_value if isinstance(code_value, str) else ""
        message = message_value if isinstance(message_value, str) else ""
        return code, message, details

    try:
        root = ET.fromstring(body)
    except ET.ParseError:
        root = None
    if root is not None:
        fields = {
            element.tag.rsplit("}", 1)[-1]: element.text.strip()
            for element in root.iter()
            if element.text and element.text.strip()
        }
        code = fields.get("Code", fields.get("code", ""))
        message = fields.get("Message", fields.get("message", ""))
        return code, message, {"response": fields}

    message = body.decode(encoding or "utf-8", errors="replace").strip()
    return "", message, {"response": message} if message else {}


@dataclass(frozen=True)
class DownloadSource:
    """一次 checkpoint 下载可使用的 URL、来源和 TLS 信任材料。"""

    url: str
    expires_at: datetime
    source: CheckpointDownloadSource
    tls_cert_pem: str | None = None
    tls_not_after: datetime | None = None


@dataclass(frozen=True)
class DownloadResult:
    """传输层完成下载后的文件和响应状态。"""

    path: Path
    bytes_written: int
    file_size_bytes: int
    status_code: int
    resumed: bool


class Downloader:
    """执行支持续传和下载源刷新的 checkpoint 文件传输。

    默认情况下下载器拥有按当前源创建的异步 HTTP Client；测试或上层注入固定
    Client 时，其生命周期仍归调用方。Actor TLS 证书变化会触发自有 Client 重建。
    """

    def __init__(
        self,
        http_client: httpx.AsyncClient | None = None,
        runtime_configuration: Configuration | None = None,
    ) -> None:
        self._http_client: httpx.AsyncClient | None = http_client
        self.configuration: Configuration = (
            configuration if runtime_configuration is None else runtime_configuration
        )

    async def download(
        self,
        source: DownloadSource,
        destination_path: Path,
        *,
        resume: bool,
        refresh_source: Callable[[], Awaitable[DownloadSource]] | None = None,
    ) -> DownloadResult:
        """下载 checkpoint，并校验续传响应覆盖完整剩余区间。

        Args:
            source: 首次请求使用的下载源。
            destination_path: 本地目标文件。
            resume: 是否从已有文件大小继续传输。
            refresh_source: URL 或 Actor TLS 证书临近过期时异步获取新源的回调。

        Returns:
            本次写入量、最终文件大小和 HTTP 状态。

        Raises:
            PyTrioError: 下载源、TLS、HTTP 状态或响应完整性不满足契约。
        """
        destination_path.parent.mkdir(parents=True, exist_ok=True)
        active_source = source
        attempts = max(1, self.configuration.retry_max_attempts)
        delay = self.configuration.retry_initial_delay_seconds
        http_client = self._http_client
        owned_client = False
        tls_cert_pem: str | None = None
        try:
            for attempt in range(1, attempts + 1):
                # URL 与 Actor 证书共同定义下载源有效期；刷新发生在创建连接和计算续传
                # 偏移之前，保证本次尝试的认证与 TLS 身份来自同一源快照。
                if refresh_source is not None:
                    refresh_before = datetime.now(timezone.utc) + timedelta(
                        seconds=_DOWNLOAD_URL_REFRESH_WINDOW_SECONDS
                    )
                    url_expires_at = active_source.expires_at
                    if url_expires_at.tzinfo is None:
                        url_expires_at = url_expires_at.replace(tzinfo=timezone.utc)
                    tls_not_after = active_source.tls_not_after
                    if tls_not_after is not None and tls_not_after.tzinfo is None:
                        tls_not_after = tls_not_after.replace(tzinfo=timezone.utc)
                    tls_expires_soon = (
                        active_source.source == "actor"
                        and tls_not_after is not None
                        and tls_not_after <= refresh_before
                    )
                    if url_expires_at <= refresh_before or tls_expires_soon:
                        active_source = await refresh_source()
                if self._http_client is None:
                    active_tls_cert_pem = self._actor_tls_cert_pem(active_source)
                    if http_client is None or active_tls_cert_pem != tls_cert_pem:
                        if owned_client and http_client is not None:
                            await http_client.aclose()
                        http_client = self._create_http_client(active_source)
                        tls_cert_pem = active_tls_cert_pem
                        owned_client = True
                existing_size = (
                    destination_path.stat().st_size
                    if resume and destination_path.exists()
                    else 0
                )
                headers: dict[str, str] = (
                    {"Range": f"bytes={existing_size}-"} if existing_size > 0 else {}
                )
                try:
                    assert http_client is not None
                    async with http_client.stream(
                        "GET", active_source.url, headers=headers
                    ) as response:
                        status_code = response.status_code
                        if (
                            status_code in (401, 403)
                            and refresh_source is not None
                            and attempt < attempts
                        ):
                            active_source = await refresh_source()
                            continue
                        if status_code in RETRYABLE_STATUS_CODES and attempt < attempts:
                            await self._sleep_before_retry(delay)
                            delay = min(
                                delay * self.configuration.retry_multiplier,
                                self.configuration.retry_max_delay_seconds,
                            )
                            continue
                        if status_code == 416 and existing_size > 0:
                            # Range 起点等于服务端完整文件大小时，416 表示本地文件已经
                            # 完整，Content-Range 总长度用于确认这一终态。
                            content_range = response.headers.get("Content-Range", "")
                            match = _UNSATISFIED_CONTENT_RANGE_PATTERN.fullmatch(
                                content_range
                            )
                            if (
                                match is not None
                                and int(match.group(1)) == existing_size
                            ):
                                return DownloadResult(
                                    path=destination_path,
                                    bytes_written=0,
                                    file_size_bytes=existing_size,
                                    status_code=response.status_code,
                                    resumed=True,
                                )
                        if status_code >= 400:
                            body = await response.aread()
                            code, message, details = _download_error_fields(
                                body,
                                encoding=response.encoding,
                            )
                            raise PyTrioError(
                                message or f"Download failed with HTTP {status_code}",
                                code=code or "download.failed",
                                details=details,
                                source=active_source.source,
                                status_code=status_code,
                                retryable=status_code in RETRYABLE_STATUS_CODES,
                            )

                        return await self._write_response(
                            destination_path,
                            response,
                            existing_size=existing_size,
                            source_url=active_source.url,
                        )
                except RETRYABLE_EXCEPTIONS as e:
                    if attempt == attempts:
                        hint = ""
                        if (
                            active_source.source == "actor"
                            and urlparse(active_source.url).scheme.lower() == "https"
                            and not active_source.tls_cert_pem
                        ):
                            hint = (
                                "Actor HTTPS download failed using the system CA store. "
                                "If this Actor uses a self-signed certificate, Control must "
                                "provide tls_cert_pem."
                            )
                        raise PyTrioError(
                            request_error_message(e),
                            code="download.request_failed",
                            hint=hint,
                            source=active_source.source,
                            retryable=True,
                        ) from None
                    await self._sleep_before_retry(delay)
                    delay = min(
                        delay * self.configuration.retry_multiplier,
                        self.configuration.retry_max_delay_seconds,
                    )
            raise PyTrioError(
                "Download failed after retries",
                code="download.failed",
                retryable=True,
            )
        finally:
            if owned_client and http_client is not None:
                try:
                    await http_client.aclose()
                except Exception:
                    logger.debug(
                        "Failed to close owned download HTTP client", exc_info=True
                    )

    def _create_http_client(self, source: DownloadSource) -> httpx.AsyncClient:
        verify: ssl.SSLContext | bool = True
        tls_cert_pem = self._actor_tls_cert_pem(source)
        if tls_cert_pem is not None:
            try:
                verify = ssl.create_default_context(cadata=tls_cert_pem)
            except (ssl.SSLError, ValueError) as error:
                raise PyTrioError(
                    str(error) or "Invalid Actor TLS trust material",
                    code="download.invalid_tls_certificate",
                    hint="Control returned invalid Actor TLS trust material.",
                    details={
                        "error_type": type(error).__name__,
                    },
                    source=source.source,
                ) from None
        return httpx.AsyncClient(
            timeout=self.configuration.request_timeout_seconds,
            follow_redirects=True,
            verify=verify,
        )

    def _actor_tls_cert_pem(self, source: DownloadSource) -> str | None:
        if source.source != "actor":
            return None
        if urlparse(source.url).scheme.lower() != "https":
            return None
        return source.tls_cert_pem

    async def _write_response(
        self,
        path: Path,
        response: httpx.Response,
        *,
        existing_size: int,
        source_url: str,
    ) -> DownloadResult:
        """按完整响应或续传响应写入文件，并核对声明的字节范围。"""
        append = existing_size > 0 and response.status_code == 206
        expected_bytes: int | None = None
        if response.status_code == 206:
            if not append:
                raise PyTrioError(
                    "Download returned partial content without a resume request",
                    code="download.unexpected_partial_content",
                    status_code=response.status_code,
                )
            expected_bytes = self._require_complete_content_range(
                response,
                expected_start=existing_size,
            )
        mode = "ab" if append else "wb"
        bytes_written = 0
        file = await _run_blocking_file_call(
            path.open,
            mode,
            cancelled_result_cleanup=lambda opened: opened.close(),
        )
        try:
            async for chunk in response.aiter_bytes(_DOWNLOAD_CHUNK_SIZE):
                if not chunk:
                    continue
                bytes_written += await _run_blocking_file_call(file.write, chunk)
        finally:
            await _run_blocking_file_call(file.close)
        if expected_bytes is not None and bytes_written != expected_bytes:
            raise PyTrioError(
                "Download response length does not match Content-Range",
                code="download.content_range_length_mismatch",
                status_code=response.status_code,
            )
        file_size_bytes = path.stat().st_size
        logger.debug(
            "Downloaded checkpoint url=%s status=%s bytes=%s file_size=%s resumed=%s",
            source_url,
            response.status_code,
            bytes_written,
            file_size_bytes,
            append,
        )
        return DownloadResult(
            path=path,
            bytes_written=bytes_written,
            file_size_bytes=file_size_bytes,
            status_code=response.status_code,
            resumed=append,
        )

    def _require_complete_content_range(
        self,
        response: httpx.Response,
        *,
        expected_start: int,
    ) -> int:
        """校验 206 响应从请求偏移连续覆盖到文件末尾。"""
        content_range = response.headers.get("Content-Range", "")
        match = _CONTENT_RANGE_PATTERN.fullmatch(content_range)
        if match is None:
            raise PyTrioError(
                "Download resume response has an invalid Content-Range",
                code="download.invalid_content_range",
            )
        actual_start, actual_end, total = (int(part) for part in match.groups())
        if (
            actual_start != expected_start
            or actual_end < actual_start
            or actual_end >= total
            or actual_end + 1 != total
        ):
            raise PyTrioError(
                "Download resume response has an invalid Content-Range",
                code="download.invalid_content_range",
                status_code=response.status_code,
            )
        return actual_end - actual_start + 1

    async def _sleep_before_retry(self, delay: float) -> None:
        if delay <= 0:
            return
        factor = 1 + random.uniform(
            0,
            max(0, self.configuration.retry_jitter_ratio),
        )
        await asyncio.sleep(delay * factor)
