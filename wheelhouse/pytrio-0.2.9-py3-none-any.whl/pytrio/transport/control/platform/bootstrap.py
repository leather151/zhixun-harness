"""实现 Control 平台启动策略接口的 HTTP 传输。"""

from pytrio.protocol.control.platform.bootstrap import SDKBootstrapResponse
from pytrio.transport.control.http_base import BaseControlHTTPClient


class SDKBootstrapControlMixin(BaseControlHTTPClient):
    """提供 ``SDKBootstrap`` Control 接口的强类型 HTTP 调用。"""

    async def sdk_bootstrap(
        self,
        sdk_version: str | None = None,
        *,
        locale: str | None = None,
    ) -> SDKBootstrapResponse:
        params: dict[str, str] = {
            "sdk_version": sdk_version or self.configuration.version
        }
        if locale:
            params["locale"] = locale
        return await self._validated_json(
            SDKBootstrapResponse,
            "GET",
            "sdk/bootstrap",
            params=params,
            headers={"User-Agent": f"pytrio/{params['sdk_version']}"},
        )
