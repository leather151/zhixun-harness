"""实现 Control 采样任务创建接口的 HTTP 传输。"""

import logging

from pytrio.protocol.control.sampling_run.create import (
    SamplingRunCreateRequest,
    SamplingRunCreateResponse,
)
from pytrio.transport.control.http_base import BaseControlHTTPClient

logger = logging.getLogger(__name__)


class SamplingRunCreateControlMixin(BaseControlHTTPClient):
    """提供 ``SamplingRunCreate`` Control 接口的强类型 HTTP 调用。"""

    async def create_sampling_run(
        self,
        service_session_cuid: str,
        *,
        base_model: str,
        source_checkpoint_uri: str = "",
    ) -> SamplingRunCreateResponse:
        """创建 sampling run 并返回 Actor 连接凭据。

        Args:
            service_session_cuid: sampling run 所属服务会话。
            base_model: 采样器基础模型 ID。
            source_checkpoint_uri: 可选 LoRA 权重 URI。

        Returns:
            新 sampling run、Actor endpoint 和 JWT。
        """
        payload = SamplingRunCreateRequest(
            base_model=base_model,
            source_checkpoint_uri=source_checkpoint_uri,
        )
        logger.debug(
            "Sending Control sampling run create service_session=%s base_model=%s source_checkpoint=%s",
            service_session_cuid,
            base_model,
            bool(source_checkpoint_uri),
        )
        response = await self._validated_json(
            SamplingRunCreateResponse,
            "POST",
            f"openapi/v1/service-sessions/{service_session_cuid}/sampling-runs",
            json=payload.model_dump(mode="python", exclude_none=True),
            telemetry_attributes={"service_session_cuid": service_session_cuid},
        )
        logger.debug(
            "Received Control sampling run create service_session=%s sampling_run=%s actor=%s",
            service_session_cuid,
            response.sampling_run_cuid,
            response.actor.actor_cuid,
        )
        return response
