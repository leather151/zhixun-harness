"""实现 Control 采样任务凭据续期接口的 HTTP 传输。"""

from pytrio.protocol.control.sampling_run.renew import SamplingRunRenewResponse
from pytrio.transport.control.http_base import BaseControlHTTPClient


class SamplingRunRenewControlMixin(BaseControlHTTPClient):
    """提供 ``SamplingRunRenew`` Control 接口的强类型 HTTP 调用。"""

    async def renew_sampling_run(
        self, sampling_run_cuid: str
    ) -> SamplingRunRenewResponse:
        return await self._validated_json(
            SamplingRunRenewResponse,
            "POST",
            f"openapi/v1/sampling-runs/{sampling_run_cuid}/renew",
            telemetry_attributes={"sampling_run_cuid": sampling_run_cuid},
        )
