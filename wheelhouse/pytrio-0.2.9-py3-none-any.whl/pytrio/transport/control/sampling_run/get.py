"""实现 Control 采样任务查询接口的 HTTP 传输。"""

from pytrio.protocol.control.sampling_run.get import SamplingRunGetResponse
from pytrio.transport.control.http_base import BaseControlHTTPClient


class SamplingRunGetControlMixin(BaseControlHTTPClient):
    """提供 ``SamplingRunGet`` Control 接口的强类型 HTTP 调用。"""

    async def get_sampling_run(self, sampling_run_cuid: str) -> SamplingRunGetResponse:
        return await self._validated_json(
            SamplingRunGetResponse,
            "GET",
            f"openapi/v1/sampling-runs/{sampling_run_cuid}",
            telemetry_attributes={"sampling_run_cuid": sampling_run_cuid},
        )
