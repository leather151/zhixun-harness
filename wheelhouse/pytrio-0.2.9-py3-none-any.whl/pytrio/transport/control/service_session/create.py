"""实现 Control 服务会话创建接口的 HTTP 传输。"""

from pytrio.protocol.control.service_session.create import (
    ServiceSessionCreateRequest,
    ServiceSessionCreateResponse,
)
from pytrio.transport.control.http_base import BaseControlHTTPClient


class ServiceSessionCreateControlMixin(BaseControlHTTPClient):
    """提供 ``ServiceSessionCreate`` Control 接口的强类型 HTTP 调用。"""

    async def create_service_session(
        self, user_metadata: dict[str, object] | None = None
    ) -> ServiceSessionCreateResponse:
        payload = ServiceSessionCreateRequest(
            sdk_version=self.configuration.version, user_metadata=user_metadata
        )
        return await self._validated_json(
            ServiceSessionCreateResponse,
            "POST",
            "openapi/v1/service-sessions",
            json=payload.model_dump(mode="python", exclude_none=True),
        )
