"""实现 Control 服务会话查询接口的 HTTP 传输。"""

from pytrio.protocol.control.service_session.get import ServiceSessionGetResponse
from pytrio.transport.control.http_base import BaseControlHTTPClient


class ServiceSessionGetControlMixin(BaseControlHTTPClient):
    """提供 ``ServiceSessionGet`` Control 接口的强类型 HTTP 调用。"""

    async def get_service_session(
        self,
        service_session_cuid: str,
        *,
        access_scope: str = "owned",
    ) -> ServiceSessionGetResponse:
        return await self._validated_json(
            ServiceSessionGetResponse,
            "GET",
            f"openapi/v1/service-sessions/{service_session_cuid}",
            params={"access_scope": access_scope},
            telemetry_attributes={"service_session_cuid": service_session_cuid},
        )
