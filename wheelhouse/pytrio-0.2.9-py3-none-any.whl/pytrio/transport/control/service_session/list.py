"""实现 Control 服务会话列表查询接口的 HTTP 传输。"""

from pytrio.protocol.control.service_session.list import ServiceSessionListResponse
from pytrio.transport.control.http_base import BaseControlHTTPClient


class ServiceSessionListControlMixin(BaseControlHTTPClient):
    """提供 ``ServiceSessionList`` Control 接口的强类型 HTTP 调用。"""

    async def list_service_sessions(
        self,
        *,
        limit: int = 20,
        offset: int = 0,
        access_scope: str = "owned",
    ) -> ServiceSessionListResponse:
        return await self._validated_json(
            ServiceSessionListResponse,
            "GET",
            "openapi/v1/service-sessions",
            params={"limit": limit, "offset": offset, "access_scope": access_scope},
        )
