"""实现 Control 服务会话凭据续期接口的 HTTP 传输。"""

from pytrio.protocol.control.service_session.renew import ServiceSessionRenewResponse
from pytrio.transport.control.http_base import BaseControlHTTPClient


class ServiceSessionRenewControlMixin(BaseControlHTTPClient):
    """提供 ``ServiceSessionRenew`` Control 接口的强类型 HTTP 调用。"""

    async def renew_service_session(
        self, service_session_cuid: str
    ) -> ServiceSessionRenewResponse:
        return await self._validated_json(
            ServiceSessionRenewResponse,
            "POST",
            f"openapi/v1/service-sessions/{service_session_cuid}/renew",
            telemetry_attributes={"service_session_cuid": service_session_cuid},
        )
