"""实现 Control 服务会话关闭接口的 HTTP 传输。"""

from pytrio.protocol.control.service_session.close import (
    ServiceSessionCloseRequest,
    ServiceSessionCloseStatus,
)
from pytrio.transport.control.http_base import BaseControlHTTPClient


class ServiceSessionCloseControlMixin(BaseControlHTTPClient):
    """提供 ``ServiceSessionClose`` Control 接口的强类型 HTTP 调用。"""

    async def close_service_session(
        self,
        service_session_cuid: str,
        *,
        status: ServiceSessionCloseStatus,
    ) -> None:
        payload = ServiceSessionCloseRequest(status=status)
        await self._request(
            "POST",
            f"openapi/v1/service-sessions/{service_session_cuid}/close",
            json=payload.model_dump(mode="python"),
            telemetry_attributes={"service_session_cuid": service_session_cuid},
        )
