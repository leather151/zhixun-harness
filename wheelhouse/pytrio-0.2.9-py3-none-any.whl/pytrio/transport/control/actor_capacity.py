"""等待 Control 为 Run 分配可用 Actor 容量。"""

import asyncio
import logging
import random
from collections.abc import Awaitable, Callable
from time import monotonic
from typing import TypeVar

import httpx

from pytrio.config.config import Configuration, configuration
from pytrio.errors.control import ControlAPIError
from pytrio.transport.retry import is_retryable_response

T = TypeVar("T")

logger = logging.getLogger("pytrio")

WAITING_MESSAGE = (
    "Server is at capacity. Waiting for an available slot. Retrying automatically."
)
CONTINUING_MESSAGE = "Server capacity is now available. Continuing."
ACTOR_CAPACITY_EXCEEDED_CODE = "actor_capacity_exceeded"


def is_actor_capacity_response(response: httpx.Response) -> bool:
    """返回 Control 响应是否表示 Actor 容量已满。"""
    if response.status_code != 429:
        return False
    try:
        data = response.json()
    except ValueError:
        return False
    return isinstance(data, dict) and data.get("code") == ACTOR_CAPACITY_EXCEEDED_CODE


def should_retry_before_actor_capacity_polling(response: httpx.Response) -> bool:
    """将容量错误留给外层轮询，其余瞬时响应沿用通用重试。"""
    return is_retryable_response(response) and not is_actor_capacity_response(response)


def is_actor_capacity_error(error: ControlAPIError) -> bool:
    """返回 Control 领域错误是否表示 Actor 容量已满。"""
    return error.status_code == 429 and error.code == ACTOR_CAPACITY_EXCEEDED_CODE


async def call_with_actor_capacity_polling(
    call: Callable[[], Awaitable[T]],
    runtime_configuration: Configuration | None = None,
) -> T:
    """异步轮询 Actor 容量，直到调用成功或超过等待窗口。"""
    current = configuration if runtime_configuration is None else runtime_configuration
    deadline: float | None = None
    waiting = False
    while True:
        try:
            result = await call()
        except ControlAPIError as error:
            if not is_actor_capacity_error(error):
                raise

            if deadline is None:
                deadline = monotonic() + current.actor_capacity_wait_timeout_seconds
            remaining = deadline - monotonic()
            if remaining <= 0:
                raise

            if not waiting:
                logger.info(WAITING_MESSAGE)
                waiting = True

            factor = 1 + random.uniform(
                0,
                max(0.0, current.actor_capacity_poll_jitter_ratio),
            )
            delay = max(
                0.0,
                current.actor_capacity_poll_interval_seconds * factor,
            )
            await asyncio.sleep(min(delay, remaining))
            continue

        if waiting:
            logger.info(CONTINUING_MESSAGE)
        return result
