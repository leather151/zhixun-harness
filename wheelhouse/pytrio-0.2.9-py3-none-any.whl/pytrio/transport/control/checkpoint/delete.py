"""实现 Control checkpoint 删除接口的 HTTP 传输。"""

from pytrio.transport.control.http_base import BaseControlHTTPClient


class CheckpointDeleteControlMixin(BaseControlHTTPClient):
    """提供 ``CheckpointDelete`` Control 接口的强类型 HTTP 调用。"""

    async def delete_checkpoint(self, checkpoint_cuid: str) -> None:
        await self._request(
            "DELETE",
            f"openapi/v1/checkpoints/{checkpoint_cuid}",
            telemetry_attributes={"checkpoint_cuid": checkpoint_cuid},
        )
