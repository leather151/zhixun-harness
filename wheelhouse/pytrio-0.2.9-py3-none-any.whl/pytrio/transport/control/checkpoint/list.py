"""实现 Control checkpoint 列表查询接口的 HTTP 传输。"""

from pytrio.protocol.control.checkpoint.list import CheckpointListResponse
from pytrio.transport.control.http_base import BaseControlHTTPClient


class CheckpointListControlMixin(BaseControlHTTPClient):
    """提供 ``CheckpointList`` Control 接口的强类型 HTTP 调用。"""

    async def list_checkpoints(
        self,
        *,
        limit: int = 100,
        offset: int = 0,
    ) -> CheckpointListResponse:
        return await self._validated_json(
            CheckpointListResponse,
            "GET",
            "openapi/v1/checkpoints",
            params={"limit": limit, "offset": offset},
        )
