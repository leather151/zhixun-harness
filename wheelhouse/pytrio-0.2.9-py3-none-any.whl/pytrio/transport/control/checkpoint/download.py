"""实现 Control checkpoint 下载地址查询接口的 HTTP 传输。"""

from pytrio.protocol.control.checkpoint.download import CheckpointDownloadResponse
from pytrio.transport.control.http_base import BaseControlHTTPClient


class CheckpointDownloadControlMixin(BaseControlHTTPClient):
    """提供 ``CheckpointDownload`` Control 接口的强类型 HTTP 调用。"""

    async def get_checkpoint_download_url(
        self, checkpoint_cuid: str
    ) -> CheckpointDownloadResponse:
        return await self._validated_json(
            CheckpointDownloadResponse,
            "GET",
            f"openapi/v1/checkpoints/{checkpoint_cuid}/download-url",
            telemetry_attributes={"checkpoint_cuid": checkpoint_cuid},
        )
