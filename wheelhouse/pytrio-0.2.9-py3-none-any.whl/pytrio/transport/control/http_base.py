"""实现 Control HTTP 请求、JSON 解析和错误转换的公共传输。"""

import functools
from collections.abc import Callable, Mapping
from time import perf_counter
from typing import TypeVar

import httpx
from pydantic import BaseModel
from pydantic import ValidationError as PydanticValidationError

from pytrio.config.config import (
    Configuration,
    configuration,
    control_api_url,
    normalize_base_url,
)
from pytrio.errors.control import ControlAPIError
from pytrio.observability.api import error_attributes, record_operation
from pytrio.observability.emitter import (
    NOOP_TELEMETRY_EMITTER,
    TelemetryEmitter,
)
from pytrio.observability.event import TelemetryScalar
from pytrio.transport.retry import (
    is_retryable_response,
    request_error_message,
    request_with_retry_timeout,
)

EMPTY_JSON_BODY: dict[str, object] = {}
EMPTY_QUERY_PARAMS: Mapping[str, str | int | float | bool] = {}
EMPTY_HEADERS: dict[str, str] = {}
EMPTY_TELEMETRY_ATTRIBUTES: Mapping[str, TelemetryScalar] = {}
ControlResponseT = TypeVar("ControlResponseT", bound=BaseModel)


def _operation(method: str, path: str) -> str:
    display_path = path if path.startswith("/") else f"/{path}"
    return f"{method.upper()} {display_path}"


def _response_validation_message(error: Exception) -> str:
    """保留响应校验位置与原因，同时排除可能敏感的原始输入值。"""
    if not isinstance(error, PydanticValidationError):
        return str(error)
    messages: list[str] = []
    for detail in error.errors(
        include_url=False,
        include_context=False,
        include_input=False,
    ):
        location = ".".join(str(part) for part in detail["loc"])
        prefix = f"{location}: " if location else ""
        messages.append(f"{prefix}{detail['msg']} (type={detail['type']})")
    return "; ".join(messages)


class BaseControlHTTPClient:
    """提供 Control API 的认证、重试、JSON 校验、错误转换和结果遥测。"""

    def __init__(
        self,
        api_key: str,
        http_client: httpx.AsyncClient | None = None,
        telemetry: TelemetryEmitter | None = None,
        runtime_configuration: Configuration | None = None,
    ) -> None:
        self.configuration: Configuration = (
            configuration if runtime_configuration is None else runtime_configuration
        )
        self.api_key: str = api_key
        self._telemetry: TelemetryEmitter = telemetry or NOOP_TELEMETRY_EMITTER
        if http_client is None:
            self.http_client: httpx.AsyncClient = httpx.AsyncClient(
                base_url=control_api_url(self.configuration.base_url),
                headers={"X-API-Key": api_key, "Authorization": f"Bearer {api_key}"},
                timeout=self.configuration.request_timeout_seconds,
            )
        else:
            self.http_client = http_client
        self.server: str = normalize_base_url(str(self.http_client.base_url))

    async def aclose(self) -> None:
        """Close the owned or injected asynchronous HTTP client."""
        await self.http_client.aclose()

    async def _request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, object] = EMPTY_JSON_BODY,
        params: Mapping[str, str | int | float | bool] = EMPTY_QUERY_PARAMS,
        headers: dict[str, str] = EMPTY_HEADERS,
        content: bytes = b"",
        should_retry_response: Callable[[httpx.Response], bool] = is_retryable_response,
        telemetry_attributes: Mapping[
            str, TelemetryScalar
        ] = EMPTY_TELEMETRY_ATTRIBUTES,
    ) -> httpx.Response:
        """发送 Control HTTP 请求并将网络与状态码错误转换为领域错误。"""
        operation = _operation(method, path)
        started = perf_counter()
        try:
            if content:
                request_call = functools.partial(
                    self.http_client.request,
                    method,
                    path,
                    params=params,
                    headers=headers,
                    content=content,
                )
            elif json:
                request_call = functools.partial(
                    self.http_client.request,
                    method,
                    path,
                    json=json,
                    params=params,
                    headers=headers,
                )
            else:
                request_call = functools.partial(
                    self.http_client.request,
                    method,
                    path,
                    params=params,
                    headers=headers,
                )
            response = await request_with_retry_timeout(
                request_call,
                retry_timeout=self.configuration.control_retry_timeout_seconds,
                initial_delay=self.configuration.retry_initial_delay_seconds,
                multiplier=self.configuration.retry_multiplier,
                max_delay=self.configuration.retry_max_delay_seconds,
                jitter=self.configuration.retry_jitter_ratio,
                should_retry_response=should_retry_response,
            )
        except httpx.RequestError as e:
            error = ControlAPIError(
                request_error_message(e),
                operation=operation,
                server=self.server,
                retryable=True,
            )
            record_operation(
                self._telemetry,
                "control_request",
                status="error",
                attributes={
                    **telemetry_attributes,
                    "operation": operation,
                    **error_attributes(error),
                    "duration_ms": int((perf_counter() - started) * 1000),
                },
            )
            raise error from None
        if response.status_code >= 400:
            error = self._error(response, operation=operation)
            record_operation(
                self._telemetry,
                "control_request",
                status="error",
                attributes={
                    **telemetry_attributes,
                    "operation": operation,
                    "status_code": response.status_code,
                    "request_id": response.headers.get("x-request-id", ""),
                    **error_attributes(error),
                    "duration_ms": int((perf_counter() - started) * 1000),
                },
            )
            raise error
        record_operation(
            self._telemetry,
            "control_request",
            attributes={
                **telemetry_attributes,
                "operation": operation,
                "status_code": response.status_code,
                "request_id": response.headers.get("x-request-id", ""),
                "duration_ms": int((perf_counter() - started) * 1000),
            },
        )
        return response

    async def _validated_json(
        self,
        response_model: type[ControlResponseT],
        method: str,
        path: str,
        *,
        json: dict[str, object] = EMPTY_JSON_BODY,
        params: Mapping[str, str | int | float | bool] = EMPTY_QUERY_PARAMS,
        headers: dict[str, str] = EMPTY_HEADERS,
        content: bytes = b"",
        should_retry_response: Callable[[httpx.Response], bool] = is_retryable_response,
        telemetry_attributes: Mapping[
            str, TelemetryScalar
        ] = EMPTY_TELEMETRY_ATTRIBUTES,
    ) -> ControlResponseT:
        """发送 Control 请求，并在保留 HTTP 上下文时校验协议模型。"""
        response, data = await self._json_object(
            method,
            path,
            json=json,
            params=params,
            headers=headers,
            content=content,
            should_retry_response=should_retry_response,
            telemetry_attributes=telemetry_attributes,
        )
        try:
            return response_model.model_validate(data)
        except PydanticValidationError as e:
            validation_message = _response_validation_message(e)
            error = ControlAPIError(
                validation_message
                or "Control response does not match the expected schema",
                code="control.invalid_response",
                hint="Control response does not match the expected schema.",
                details={
                    "error": validation_message,
                    "error_type": type(e).__name__,
                },
                operation=_operation(method, path),
                server=self.server,
                request_id=response.headers.get("x-request-id", ""),
            )
            self._record_response_error(
                error,
                response=response,
                telemetry_attributes=telemetry_attributes,
            )
            raise error from None

    async def _json_object(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, object] = EMPTY_JSON_BODY,
        params: Mapping[str, str | int | float | bool] = EMPTY_QUERY_PARAMS,
        headers: dict[str, str] = EMPTY_HEADERS,
        content: bytes = b"",
        should_retry_response: Callable[[httpx.Response], bool] = is_retryable_response,
        telemetry_attributes: Mapping[
            str, TelemetryScalar
        ] = EMPTY_TELEMETRY_ATTRIBUTES,
    ) -> tuple[httpx.Response, dict[str, object]]:
        """发送 Control 请求并返回 HTTP 响应及 JSON object。"""
        response = await self._request(
            method,
            path,
            json=json,
            params=params,
            headers=headers,
            content=content,
            should_retry_response=should_retry_response,
            telemetry_attributes=telemetry_attributes,
        )
        try:
            data = response.json()
        except ValueError as e:
            error = ControlAPIError(
                str(e) or "Failed to parse Control response",
                code="control.invalid_response",
                hint="Failed to parse the Control response as JSON.",
                operation=_operation(method, path),
                server=self.server,
                request_id=response.headers.get("x-request-id", ""),
            )
            self._record_response_error(
                error,
                response=response,
                telemetry_attributes=telemetry_attributes,
            )
            raise error from None
        if not isinstance(data, dict):
            error = ControlAPIError(
                "Control response must be a JSON object",
                code="control.invalid_response",
                details={"type": type(data).__name__},
                operation=_operation(method, path),
                server=self.server,
                request_id=response.headers.get("x-request-id", ""),
            )
            self._record_response_error(
                error,
                response=response,
                telemetry_attributes=telemetry_attributes,
            )
            raise error
        return response, data

    def _record_response_error(
        self,
        error: ControlAPIError,
        *,
        response: httpx.Response,
        telemetry_attributes: Mapping[str, TelemetryScalar],
    ) -> None:
        """Record a Control protocol failure after an HTTP success."""
        record_operation(
            self._telemetry,
            "control_response",
            status="error",
            attributes={
                **telemetry_attributes,
                "operation": error.operation,
                "status_code": response.status_code,
                "request_id": response.headers.get("x-request-id", ""),
                **error_attributes(error),
            },
        )

    def _error(self, response: httpx.Response, *, operation: str) -> ControlAPIError:
        """从 Control 失败响应提取稳定错误字段和请求上下文。"""
        try:
            data = response.json()
        except ValueError:
            data = {}
        data = data if isinstance(data, dict) else {}
        code_value = data.get("code", "")
        message_value = data.get("message", "")
        code = code_value if isinstance(code_value, str) else ""
        message = message_value if isinstance(message_value, str) else ""
        details = {key: value for key, value in data.items() if key != "message"}
        return ControlAPIError(
            message or f"Control request failed with HTTP {response.status_code}",
            status_code=response.status_code,
            code=code,
            details=details,
            operation=operation,
            server=self.server,
            request_id=response.headers.get("x-request-id", ""),
        )
