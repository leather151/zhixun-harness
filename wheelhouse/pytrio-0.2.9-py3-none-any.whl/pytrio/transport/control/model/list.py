"""实现 Control 模型目录列表查询接口的 HTTP 传输。"""

from pytrio.errors.control import ControlAPIError
from pytrio.protocol.control.model.list import ModelInfo, ModelListResponse
from pytrio.transport.control.http_base import BaseControlHTTPClient

_MODEL_PAGE_SIZE = 100


class ModelListControlMixin(BaseControlHTTPClient):
    """提供 ``ModelList`` Control 接口的强类型 HTTP 调用。"""

    async def get_models(self) -> list[ModelInfo]:
        """分页拉取 Control 模型目录并验证总数收敛。"""
        models: list[ModelInfo] = []
        offset = 0
        while True:
            page = await self._validated_json(
                ModelListResponse,
                "GET",
                "models",
                params={"limit": _MODEL_PAGE_SIZE, "offset": offset},
            )
            models.extend(page.items)
            offset += len(page.items)
            if offset >= page.total:
                return models
            if not page.items:
                raise ControlAPIError(
                    "Model catalog ended before its reported total",
                    code="control.invalid_response",
                    operation="GET /models",
                    server=self.server,
                )
