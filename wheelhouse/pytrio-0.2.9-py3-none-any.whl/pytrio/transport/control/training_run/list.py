"""实现 Control 训练任务列表查询接口的 HTTP 传输。"""

from pytrio.protocol.control.training_run.list import TrainingRunListResponse
from pytrio.transport.control.http_base import BaseControlHTTPClient


class TrainingRunListControlMixin(BaseControlHTTPClient):
    """提供 ``TrainingRunList`` Control 接口的强类型 HTTP 调用。"""

    async def list_training_runs(
        self,
        *,
        limit: int = 20,
        offset: int = 0,
        access_scope: str = "owned",
    ) -> TrainingRunListResponse:
        return await self._validated_json(
            TrainingRunListResponse,
            "GET",
            "openapi/v1/training-runs",
            params={"limit": limit, "offset": offset, "access_scope": access_scope},
        )
