"""实现 Control 训练任务查询接口的 HTTP 传输。"""

from pytrio.protocol.control.training_run.get import TrainingRunGetResponse
from pytrio.transport.control.http_base import BaseControlHTTPClient


class TrainingRunGetControlMixin(BaseControlHTTPClient):
    """提供 ``TrainingRunGet`` Control 接口的强类型 HTTP 调用。"""

    async def get_training_run(
        self,
        training_run_cuid: str,
        *,
        access_scope: str = "owned",
    ) -> TrainingRunGetResponse:
        return await self._validated_json(
            TrainingRunGetResponse,
            "GET",
            f"openapi/v1/training-runs/{training_run_cuid}",
            params={"access_scope": access_scope},
            telemetry_attributes={"training_run_cuid": training_run_cuid},
        )
