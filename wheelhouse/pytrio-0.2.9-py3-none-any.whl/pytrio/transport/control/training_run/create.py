"""实现 Control 训练任务创建接口的 HTTP 传输。"""

import logging

from pytrio.protocol.control.training_run.create import (
    TrainingRunCreateRequest,
    TrainingRunCreateResponse,
)
from pytrio.transport.control.actor_capacity import (
    should_retry_before_actor_capacity_polling,
)
from pytrio.transport.control.http_base import BaseControlHTTPClient

logger = logging.getLogger(__name__)


class TrainingRunCreateControlMixin(BaseControlHTTPClient):
    """提供 ``TrainingRunCreate`` Control 接口的强类型 HTTP 调用。"""

    async def create_training_run(
        self,
        service_session_cuid: str,
        *,
        base_model: str,
        lora_rank: int,
        train_mlp: bool,
        train_attn: bool,
        train_unembed: bool,
        source_checkpoint_uri: str = "",
        restore_optimizer: bool = False,
        seed: int | None = None,
    ) -> TrainingRunCreateResponse:
        """创建 LoRA training run 并返回 Actor 连接凭据。

        Args:
            service_session_cuid: training run 所属服务会话。
            base_model: 新任务使用的基础模型 ID。
            lora_rank: LoRA rank。
            train_mlp: 是否训练 MLP 层。
            train_attn: 是否训练 attention 层。
            train_unembed: 是否训练输出 embedding 层。
            source_checkpoint_uri: 可选 checkpoint 来源。
            restore_optimizer: 是否恢复 checkpoint 优化器状态。
            seed: LoRA 初始化随机种子。

        Returns:
            新 training run、Actor endpoint 和 JWT。
        """
        payload = TrainingRunCreateRequest(
            base_model=base_model,
            lora_rank=lora_rank,
            train_mlp=train_mlp,
            train_attn=train_attn,
            train_unembed=train_unembed,
            source_checkpoint_uri=source_checkpoint_uri,
            restore_optimizer=restore_optimizer,
            seed=seed,
        )
        logger.debug(
            "Sending Control training run create service_session=%s base_model=%s rank=%s restore_optimizer=%s source_checkpoint=%s",
            service_session_cuid,
            base_model,
            lora_rank,
            restore_optimizer,
            bool(source_checkpoint_uri),
        )
        response = await self._validated_json(
            TrainingRunCreateResponse,
            "POST",
            f"openapi/v1/service-sessions/{service_session_cuid}/training-runs",
            json=payload.model_dump(mode="python", exclude_none=True),
            should_retry_response=should_retry_before_actor_capacity_polling,
            telemetry_attributes={"service_session_cuid": service_session_cuid},
        )
        logger.debug(
            "Received Control training run create service_session=%s training_run=%s actor=%s",
            service_session_cuid,
            response.training_run_cuid,
            response.actor.actor_cuid,
        )
        return response
