"""实现 Control 训练任务凭据续期接口的 HTTP 传输。"""

from pytrio.protocol.control.training_run.renew import TrainingRunRenewResponse
from pytrio.transport.control.http_base import BaseControlHTTPClient


class TrainingRunRenewControlMixin(BaseControlHTTPClient):
    """提供 ``TrainingRunRenew`` Control 接口的强类型 HTTP 调用。"""

    async def renew_training_run(
        self, training_run_cuid: str
    ) -> TrainingRunRenewResponse:
        return await self._validated_json(
            TrainingRunRenewResponse,
            "POST",
            f"openapi/v1/training-runs/{training_run_cuid}/renew",
            telemetry_attributes={"training_run_cuid": training_run_cuid},
        )
