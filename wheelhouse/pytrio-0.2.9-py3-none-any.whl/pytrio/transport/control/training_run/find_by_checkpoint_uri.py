"""实现 Control 训练任务按 checkpoint URI 查询接口的 HTTP 传输。"""

from pytrio.protocol.control.training_run.find_by_checkpoint_uri import (
    TrainingRunFindByCheckpointURIResponse,
)
from pytrio.transport.control.http_base import BaseControlHTTPClient


class TrainingRunFindByCheckpointURIControlMixin(BaseControlHTTPClient):
    """提供 ``TrainingRunFindByCheckpointURI`` Control 接口的强类型 HTTP 调用。"""

    async def find_training_run_by_checkpoint_uri(
        self, checkpoint_uri: str
    ) -> TrainingRunFindByCheckpointURIResponse:
        return await self._validated_json(
            TrainingRunFindByCheckpointURIResponse,
            "GET",
            "openapi/v1/training-runs/by-checkpoint-uri",
            params={"checkpoint_uri": checkpoint_uri},
        )
