"""实现 Control 训练任务初始化前恢复绑定接口。"""

from pytrio.protocol.control.training_run.update import (
    TrainingRunUpdateRequest,
    TrainingRunUpdateResponse,
)
from pytrio.transport.control.actor_capacity import (
    should_retry_before_actor_capacity_polling,
)
from pytrio.transport.control.http_base import BaseControlHTTPClient


class TrainingRunUpdateControlMixin(BaseControlHTTPClient):
    """提供 ``TrainingRunUpdate`` Control 接口的强类型 HTTP 调用。"""

    async def update_training_run(
        self,
        service_session_cuid: str,
        training_run_cuid: str,
        *,
        source_checkpoint_uri: str,
        restore_optimizer: bool,
    ) -> TrainingRunUpdateResponse:
        """绑定恢复来源并返回最终 Actor 凭据与 Trainer 限制。"""
        request = TrainingRunUpdateRequest(
            source_checkpoint_uri=source_checkpoint_uri,
            restore_optimizer=restore_optimizer,
        )
        return await self._validated_json(
            TrainingRunUpdateResponse,
            "PATCH",
            f"openapi/v1/service-sessions/{service_session_cuid}/training-runs/{training_run_cuid}",
            json=request.model_dump(mode="python"),
            should_retry_response=should_retry_before_actor_capacity_polling,
            telemetry_attributes={"training_run_cuid": training_run_cuid},
        )
