"""实现 Control 训练任务 checkpoint 列表查询接口的 HTTP 传输。"""

from pytrio.protocol.control.checkpoint.list import CheckpointListResponse
from pytrio.transport.control.http_base import BaseControlHTTPClient


class TrainingRunListCheckpointsControlMixin(BaseControlHTTPClient):
    """提供 ``TrainingRunListCheckpoints`` Control 接口的强类型 HTTP 调用。"""

    async def list_training_run_checkpoints(
        self,
        training_run_cuid: str,
        *,
        limit: int = 200,
        offset: int = 0,
    ) -> CheckpointListResponse:
        return await self._validated_json(
            CheckpointListResponse,
            "GET",
            f"openapi/v1/training-runs/{training_run_cuid}/checkpoints",
            params={"limit": limit, "offset": offset},
            telemetry_attributes={"training_run_cuid": training_run_cuid},
        )
