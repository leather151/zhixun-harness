"""实现 Control API Key 校验接口的 HTTP 传输。"""

from pytrio.protocol.control.api_key.verify import APIKeyInfo
from pytrio.transport.control.http_base import BaseControlHTTPClient


class APIKeyVerifyControlMixin(BaseControlHTTPClient):
    """提供 ``APIKeyVerify`` Control 接口的强类型 HTTP 调用。"""

    async def verify_api_key(self) -> APIKeyInfo:
        return await self._validated_json(
            APIKeyInfo, "GET", "openapi/v1/api-key/verify"
        )
