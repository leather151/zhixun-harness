"""汇集全部 Control API 传输 mixin。"""

from pytrio.transport.control.api_key.verify import APIKeyVerifyControlMixin
from pytrio.transport.control.checkpoint.delete import CheckpointDeleteControlMixin
from pytrio.transport.control.checkpoint.download import CheckpointDownloadControlMixin
from pytrio.transport.control.checkpoint.list import CheckpointListControlMixin
from pytrio.transport.control.model.list import ModelListControlMixin
from pytrio.transport.control.platform.bootstrap import SDKBootstrapControlMixin
from pytrio.transport.control.sampling_run.create import SamplingRunCreateControlMixin
from pytrio.transport.control.sampling_run.get import SamplingRunGetControlMixin
from pytrio.transport.control.sampling_run.renew import SamplingRunRenewControlMixin
from pytrio.transport.control.service_session.close import (
    ServiceSessionCloseControlMixin,
)
from pytrio.transport.control.service_session.create import (
    ServiceSessionCreateControlMixin,
)
from pytrio.transport.control.service_session.get import ServiceSessionGetControlMixin
from pytrio.transport.control.service_session.list import ServiceSessionListControlMixin
from pytrio.transport.control.service_session.renew import (
    ServiceSessionRenewControlMixin,
)
from pytrio.transport.control.training_run.create import TrainingRunCreateControlMixin
from pytrio.transport.control.training_run.find_by_checkpoint_uri import (
    TrainingRunFindByCheckpointURIControlMixin,
)
from pytrio.transport.control.training_run.get import TrainingRunGetControlMixin
from pytrio.transport.control.training_run.list import TrainingRunListControlMixin
from pytrio.transport.control.training_run.list_checkpoints import (
    TrainingRunListCheckpointsControlMixin,
)
from pytrio.transport.control.training_run.renew import TrainingRunRenewControlMixin
from pytrio.transport.control.training_run.update import TrainingRunUpdateControlMixin


class ControlHTTPClient(
    APIKeyVerifyControlMixin,
    SDKBootstrapControlMixin,
    ModelListControlMixin,
    ServiceSessionCreateControlMixin,
    ServiceSessionRenewControlMixin,
    ServiceSessionCloseControlMixin,
    ServiceSessionGetControlMixin,
    ServiceSessionListControlMixin,
    TrainingRunCreateControlMixin,
    TrainingRunFindByCheckpointURIControlMixin,
    TrainingRunGetControlMixin,
    TrainingRunListControlMixin,
    TrainingRunListCheckpointsControlMixin,
    TrainingRunRenewControlMixin,
    TrainingRunUpdateControlMixin,
    SamplingRunCreateControlMixin,
    SamplingRunRenewControlMixin,
    SamplingRunGetControlMixin,
    CheckpointListControlMixin,
    CheckpointDownloadControlMixin,
    CheckpointDeleteControlMixin,
):
    """汇集全部 Control API 传输能力。"""
