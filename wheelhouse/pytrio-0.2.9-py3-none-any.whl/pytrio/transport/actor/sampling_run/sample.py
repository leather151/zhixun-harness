"""流式读取 Actor 采样的最终 JSON 响应并校验。"""

import asyncio
import json
import logging
from time import monotonic

from pytrio.errors.actor import ActorAPIError
from pytrio.protocol.actor.sampling_run.sample import ActorSampleResponse, SampleRequest
from pytrio.transport.actor.http_base import BaseActorHTTPClient

logger = logging.getLogger(__name__)


class SamplingRunSampleActorMixin(BaseActorHTTPClient):
    """提供 ``SamplingRunSampleActor`` 接口的强类型 HTTP 调用。"""

    async def sample(
        self,
        sampling_run_cuid: str,
        request: SampleRequest,
    ) -> ActorSampleResponse:
        """调用指定 sampling run 的 Actor 采样接口。"""
        logger.debug(
            "Sending Actor sample request task=%s request=%s actor=%s",
            sampling_run_cuid,
            request.request_id,
            self.actor.actor_cuid,
        )
        async with self._stream_with_actor_jwt(
            "POST",
            f"v1/sampling-runs/{sampling_run_cuid}/sample",
            json=request.model_dump(mode="json"),
            headers={"Accept": "application/json"},
            timeout=self.configuration.sampling_timeout_seconds,
            retry_timeout=self.configuration.sampling_retry_timeout_seconds,
        ) as response:
            if response.status_code >= 400:
                await response.aread()
                error = self._error(
                    response,
                    ActorAPIError,
                    operation="POST /v1/sampling-runs/{sampling_run_cuid}/sample",
                )
                self._record_response_error(error)
                raise error
            try:
                data = await self._read_final_json_response(response)
                if not isinstance(data, dict):
                    raise ActorAPIError(
                        "Actor sample response must be a JSON object",
                        code="actor.invalid_response",
                        details={"type": type(data).__name__},
                        operation="actor.sampling.sample",
                    )
                actor_response = ActorSampleResponse.model_validate(data)
            except ActorAPIError as error:
                self._record_response_error(error)
                raise
            except Exception as e:  # noqa: BLE001 - validation failures become domain errors
                error = ActorAPIError(
                    str(e) or "Failed to parse Actor sample response",
                    code="actor.invalid_response",
                    hint="Failed to parse the Actor sample response.",
                    operation="actor.sampling.sample",
                )
                self._record_response_error(error)
                raise error from None
        logger.debug(
            "Received Actor sample response task=%s request=%s sequences=%s actor=%s",
            sampling_run_cuid,
            actor_response.request_id,
            len(actor_response.sequences),
            self.actor.actor_cuid,
        )
        return actor_response

    async def _read_final_json_response(self, response: object) -> object:
        """按首 chunk/帧间空闲/总时长读取最终 JSON body。

        The endpoint remains JSON-shaped; streaming is only a transport-level
        liveness signal. The caller receives no partial result.
        """
        # ``_request_with_actor_jwt`` historically returns an already buffered
        # response. Use its bytes as a compatibility path for custom transports.
        if not hasattr(response, "aiter_bytes"):
            return response.json()  # type: ignore[union-attr]

        chunks: list[bytes] = []
        started = monotonic()
        first_timeout = self.configuration.sampling_first_chunk_timeout_seconds
        idle_timeout = self.configuration.sampling_chunk_idle_timeout_seconds
        total_timeout = float(self.configuration.sampling_timeout_seconds)
        iterator = response.aiter_bytes()  # type: ignore[union-attr]
        first = True
        try:
            while True:
                remaining_total = total_timeout - (monotonic() - started)
                if remaining_total <= 0:
                    raise self._sampling_timeout("total")
                timeout = first_timeout if first else idle_timeout
                timeout = min(timeout, remaining_total)
                try:
                    chunk = await asyncio.wait_for(iterator.__anext__(), timeout)
                except StopAsyncIteration:
                    break
                except asyncio.TimeoutError:
                    raise self._sampling_timeout("first_chunk" if first else "chunk_idle") from None
                if chunk:
                    chunks.append(chunk)
                    first = False
        finally:
            await response.aclose()  # type: ignore[union-attr]
        try:
            return json.loads(b"".join(chunks).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise ActorAPIError(
                str(error) or "Failed to parse Actor sample response",
                code="actor.invalid_response",
                hint="Failed to parse the Actor sample response.",
                operation="actor.sampling.sample",
            ) from None

    @staticmethod
    def _sampling_timeout(kind: str) -> ActorAPIError:
        labels = {
            "first_chunk": "first response chunk",
            "chunk_idle": "response chunk idle",
            "total": "total response",
        }
        return ActorAPIError(
            f"Actor sampling {labels[kind]} timeout",
            code=f"actor.sampling.{kind}_timeout",
            operation="actor.sampling.sample",
            retryable=False,
        )
