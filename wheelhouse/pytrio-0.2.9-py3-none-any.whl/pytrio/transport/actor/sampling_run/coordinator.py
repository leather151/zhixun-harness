"""调度单个采样任务的并发请求与队列生命周期。"""

from __future__ import annotations

import asyncio
import weakref
from collections import deque
from concurrent.futures import Future as ConcurrentFuture
from dataclasses import dataclass
from enum import Enum, auto
from typing import TYPE_CHECKING

from pytrio.config.config import Configuration, configuration
from pytrio.errors.base import PyTrioError, ValidationError
from pytrio.protocol.actor.sampling_run.sample import ActorSampleResponse, SampleRequest
from pytrio.transport.actor.http_client import ActorHTTPClient
from pytrio.types.future.api_future import APIFuture

if TYPE_CHECKING:
    from pytrio.runtime.service import ServiceRuntime


@dataclass(frozen=True)
class _QueuedSample:
    """等待占用并发槽位的采样请求及其用户可见结果。"""

    request: SampleRequest
    future: ConcurrentFuture[ActorSampleResponse]


class _QueueScanState(Enum):
    IDLE = auto()
    CLOSED = auto()


class ActorSamplingRunCoordinator:
    """调度单个 sampling run 的本地队列和并发请求。

    coordinator 绑定创建它的事件循环；并发槽位统计已经进入 asyncio task 的请求，本地
    队列提供背压，HTTP transport 由这些 task 直接异步驱动。
    """

    def __init__(
        self,
        *,
        actor_client: ActorHTTPClient,
        sampling_run_cuid: str,
        max_in_flight_requests: int = 0,
        max_queued_requests: int = 0,
        runtime: ServiceRuntime | None = None,
        runtime_configuration: Configuration | None = None,
    ) -> None:
        self.actor_client: ActorHTTPClient = actor_client
        self.sampling_run_cuid: str = sampling_run_cuid
        self._runtime: ServiceRuntime | None = runtime
        self._configuration: Configuration = (
            configuration if runtime_configuration is None else runtime_configuration
        )
        current = self._configuration
        self._loop: asyncio.AbstractEventLoop = asyncio.get_running_loop()
        self._max_in_flight_requests: int = (
            current.sampling_request_max_in_flight
            if max_in_flight_requests == 0
            else max_in_flight_requests
        )
        self._max_queued_requests: int = (
            current.sampling_request_queue_capacity
            if max_queued_requests == 0
            else max_queued_requests
        )
        if self._max_in_flight_requests < 1 or self._max_queued_requests < 1:
            raise ValidationError(
                "Sampling queue limits must be positive",
                code="validation.invalid_sampling_queue_limit",
            )
        self._closed: bool = False
        self._submit_lock: asyncio.Lock = asyncio.Lock()
        self._queue_condition: asyncio.Condition = asyncio.Condition()
        self._queue: deque[_QueuedSample] = deque()
        self._in_flight_requests: int = 0
        self._tasks: set[asyncio.Task[None]] = set()
        self._pending_futures: set[ConcurrentFuture[ActorSampleResponse]] = set()
        self._dispatcher_task: asyncio.Task[None] | None = None

    async def submit(self, request: SampleRequest) -> APIFuture[ActorSampleResponse]:
        """等待本地队列容量并提交一个采样请求。

        Args:
            request: 已通过协议模型校验的采样请求。

        Returns:
            采样 HTTP 调用的异步结果。

        Raises:
            PyTrioError: run coordinator 已关闭或跨事件循环使用。
        """
        async with self._submit_lock:
            self._raise_if_unavailable()
            self._get_or_bind_loop()
            future: ConcurrentFuture[ActorSampleResponse] = ConcurrentFuture()
            self._track_future(future)
            queued_sample = _QueuedSample(request, future)
            try:
                # 准入在 condition 内直接预留空闲槽位，繁忙时进入有界 FIFO 队列；
                # submit_lock 保持并发调用的准入顺序。
                direct_submit = await self._enqueue_or_reserve_slot(queued_sample)
            except BaseException:
                future.cancel()
                raise
            api_future = APIFuture(future)
            if direct_submit:
                self._start_sample_task(queued_sample)
            else:
                self._ensure_dispatcher_task()
            return api_future

    def _ensure_dispatcher_task(self) -> None:
        if self._dispatcher_task is None or self._dispatcher_task.done():
            self._dispatcher_task = asyncio.create_task(self._dispatch_queued_samples())

    def _raise_if_unavailable(self) -> None:
        if self._closed:
            raise PyTrioError(
                "ActorSamplingRunCoordinator is closed",
                code="sampling.run_closed",
            )

    def _get_or_bind_loop(self) -> asyncio.AbstractEventLoop:
        loop = asyncio.get_running_loop()
        if self._loop is not loop:
            raise PyTrioError(
                "ActorSamplingRunCoordinator cannot be used across multiple event loops",
                code="sampling.run_loop_mismatch",
            )
        return self._loop

    async def _enqueue_or_reserve_slot(self, queued_sample: _QueuedSample) -> bool:
        """在 condition 内原子预留并发槽位或把请求加入 FIFO 队列。"""
        async with self._queue_condition:
            while len(self._queue) >= self._max_queued_requests:
                self._raise_if_unavailable()
                await self._queue_condition.wait()
            self._raise_if_unavailable()
            if (
                not self._queue
                and self._in_flight_requests < self._max_in_flight_requests
            ):
                self._in_flight_requests += 1
                return True
            self._queue.append(queued_sample)
            self._queue_condition.notify_all()
            return False

    async def _dispatch_queued_samples(self) -> None:
        """持续把队首请求转移到空闲并发槽位。"""
        while True:
            # 预热凭据但不在 dispatcher 中等待 Control HTTP；真正发送边界仍会
            # await renew_if_needed，保证 direct-submit 路径不会漏检。
            await self.actor_client.schedule_renewal_if_needed()
            queued_sample = await self._next_queued_sample()
            if isinstance(queued_sample, _QueueScanState):
                return
            if queued_sample.future.cancelled():
                await self._release_in_flight_slot()
                continue
            self._start_sample_task(queued_sample)

    async def _next_queued_sample(
        self,
    ) -> _QueuedSample | _QueueScanState:
        async with self._queue_condition:
            while True:
                # 已取消结果在占用并发槽位前从队列清理；condition 的每次状态变化唤醒
                # dispatcher 和等待队列容量的 submit 调用。
                self._drop_done_queued_samples_locked()
                if self._closed:
                    return _QueueScanState.CLOSED
                if not self._queue and self._in_flight_requests == 0:
                    return _QueueScanState.IDLE
                if (
                    self._queue
                    and self._in_flight_requests < self._max_in_flight_requests
                ):
                    queued_sample = self._queue.popleft()
                    self._in_flight_requests += 1
                    self._queue_condition.notify_all()
                    return queued_sample
                await self._queue_condition.wait()

    def _drop_done_queued_samples_locked(self) -> None:
        if not any(queued_sample.future.done() for queued_sample in self._queue):
            return
        self._queue = deque(
            queued_sample
            for queued_sample in self._queue
            if not queued_sample.future.done()
        )

    def _start_sample_task(self, queued_sample: _QueuedSample) -> None:
        """创建拥有并发槽位的请求 task，并建立双向取消通知。"""
        task = asyncio.create_task(self._run_sample(queued_sample))
        self._tasks.add(task)

        def _cleanup(_: asyncio.Task[None]) -> None:
            self._tasks.discard(task)

        def _cancel_task(src: ConcurrentFuture[ActorSampleResponse]) -> None:
            if src.cancelled() and not task.done():
                try:
                    task.get_loop().call_soon_threadsafe(task.cancel)
                except RuntimeError:
                    pass

        task.add_done_callback(_cleanup)
        queued_sample.future.add_done_callback(_cancel_task)

    def _attach_error_context(self, error: PyTrioError) -> None:
        if not error.task_cuid:
            error.task_cuid = self.sampling_run_cuid
        if not error.actor_cuid:
            error.actor_cuid = self.actor_client.actor.actor_cuid

    async def _run_sample(self, queued_sample: _QueuedSample) -> None:
        """异步调用 Actor，并在所有终态释放并发槽位。"""
        try:
            if queued_sample.future.cancelled():
                return
            response = await self.actor_client.sample(
                self.sampling_run_cuid,
                queued_sample.request,
            )
            if not queued_sample.future.done():
                queued_sample.future.set_result(response)
        except asyncio.CancelledError:
            if not queued_sample.future.done():
                queued_sample.future.cancel()
            raise
        except Exception as e:  # noqa: BLE001 - user future carries transport failures
            if not queued_sample.future.done():
                if isinstance(e, PyTrioError):
                    self._attach_error_context(e)
                queued_sample.future.set_exception(e)
        finally:
            await self._release_in_flight_slot()

    async def _release_in_flight_slot(self) -> None:
        async with self._queue_condition:
            if self._in_flight_requests > 0:
                self._in_flight_requests -= 1
            self._queue_condition.notify_all()

    def _track_future(self, future: ConcurrentFuture[ActorSampleResponse]) -> None:
        self._pending_futures.add(future)
        coordinator_ref = weakref.ref(self)

        def _cleanup(src: ConcurrentFuture[ActorSampleResponse]) -> None:
            coordinator = coordinator_ref()
            if coordinator is None:
                return
            try:
                coordinator._loop.call_soon_threadsafe(
                    coordinator._future_done_on_loop, src
                )
            except RuntimeError:
                pass

        future.add_done_callback(_cleanup)

    def _future_done_on_loop(
        self, future: ConcurrentFuture[ActorSampleResponse]
    ) -> None:
        self._pending_futures.discard(future)
        if self._loop.is_closed():
            return
        asyncio.create_task(self._notify_queue_waiters())

    async def _notify_queue_waiters(self) -> None:
        async with self._queue_condition:
            self._queue_condition.notify_all()

    async def aclose(self) -> None:
        """关闭 coordinator、取消本地工作并释放 Actor 异步资源。"""
        self._closed = True
        await self._cancel_pending_samples_on_loop()
        current = asyncio.current_task()
        tasks = [
            task for task in self._tasks if task is not current and not task.done()
        ]
        if (
            self._dispatcher_task is not None
            and self._dispatcher_task is not current
            and not self._dispatcher_task.done()
        ):
            self._dispatcher_task.cancel()
            tasks.append(self._dispatcher_task)
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        await self.actor_client.aclose()

    async def _cancel_pending_samples_on_loop(self) -> None:
        for future in list(self._pending_futures):
            if not future.done():
                future.cancel()
        async with self._queue_condition:
            self._queue.clear()
            self._queue_condition.notify_all()
        for task in list(self._tasks):
            if not task.done() and task is not asyncio.current_task():
                task.cancel()
