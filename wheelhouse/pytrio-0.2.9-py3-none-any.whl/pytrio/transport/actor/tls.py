"""归一化 Actor 地址并建立 TLS 信任上下文。"""

import hashlib
import ssl

import httpx

from pytrio.protocol.control.actor.credentials import ActorConnectionInfo


def normalize_endpoint(actor: ActorConnectionInfo) -> str:
    endpoint = actor.endpoint.strip().rstrip("/")
    if endpoint.startswith(("http://", "https://")):
        return endpoint + "/"
    scheme = "https" if actor.tls_enabled else "http"
    return f"{scheme}://{endpoint}/"


def actor_tls_fingerprint(actor: ActorConnectionInfo) -> str:
    if not actor.tls_enabled or not actor.tls_cert_pem:
        return ""
    return hashlib.sha256(actor.tls_cert_pem.encode("utf-8")).hexdigest()


def create_actor_ssl_context(actor: ActorConnectionInfo) -> ssl.SSLContext | bool:
    if not actor.tls_enabled or not actor.tls_cert_pem:
        return True
    return ssl.create_default_context(cadata=actor.tls_cert_pem)


def create_actor_async_http_client(
    actor: ActorConnectionInfo,
    *,
    limits: httpx.Limits | None = None,
    timeout: float = 30,
) -> httpx.AsyncClient:
    verify: ssl.SSLContext | bool = True
    if actor.tls_enabled and actor.tls_cert_pem:
        verify = create_actor_ssl_context(actor)
    if limits is None:
        return httpx.AsyncClient(
            base_url=normalize_endpoint(actor),
            headers={"Accept": "application/msgpack"},
            timeout=timeout,
            verify=verify,
        )
    return httpx.AsyncClient(
        base_url=normalize_endpoint(actor),
        headers={"Accept": "application/msgpack"},
        timeout=timeout,
        verify=verify,
        limits=limits,
    )
