"""实现 Actor 异步认证、HTTP 请求和错误转换的公共传输。

Actor transport 只在 ``ServiceRuntime`` 所有的 asyncio loop 中运行；同步公共 API
由上层的 ``SDKEventLoopRunner`` 负责桥接。
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Mapping
from contextlib import asynccontextmanager
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from time import monotonic, perf_counter
from typing import Protocol

import httpx
import msgpack

from pytrio.config.config import Configuration, configuration
from pytrio.errors.actor import ActorAPIError, ActorError
from pytrio.observability.api import error_attributes, record_operation
from pytrio.observability.emitter import (
    NOOP_TELEMETRY_EMITTER,
    TelemetryEmitter,
)
from pytrio.observability.event import TelemetryScalar
from pytrio.protocol.actor.events.event import (
    EventFailedResponse,
    EventSucceededResponse,
    EventType,
)
from pytrio.protocol.control.actor.credentials import ActorConnectionInfo, ActorJWT
from pytrio.transport.actor.http_registry import ActorHTTPClientRegistry
from pytrio.transport.actor.tls import normalize_endpoint
from pytrio.transport.connectivity import probe_base_url_connectivity
from pytrio.transport.retry import (
    RETRYABLE_EXCEPTIONS,
    RETRYABLE_STATUS_CODES,
    request_error_message,
    request_with_retries,
    request_with_retry_timeout,
)


class ActorRenewalResult(Protocol):
    """Control 续期操作返回的 Actor 地址与 JWT。"""

    actor: ActorConnectionInfo
    actor_jwt: ActorJWT


class ActorRenewalCallback(Protocol):
    """Actor Client 请求凭据续期的异步回调契约。"""

    def __call__(self) -> Awaitable[ActorRenewalResult]:
        raise NotImplementedError


@dataclass(frozen=True)
class ActorAuthorizationSnapshot:
    """一次请求使用的认证头及其 JWT 快照。"""

    headers: dict[str, str]
    token: str


EMPTY_JSON_BODY: dict[str, object] = {}
EMPTY_HEADERS: dict[str, str] = {}
EMPTY_TELEMETRY_ATTRIBUTES: Mapping[str, TelemetryScalar] = {}


def _operation(method: str, path: str) -> str:
    display_path = path if path.startswith("/") else f"/{path}"
    return f"{method.upper()} {display_path}"


class BaseActorHTTPClient:
    """管理 Actor 异步 HTTP 传输、JWT 续期、错误上下文和遥测。

    Client、registry 和续期任务都由 SDK event loop 所有。续期采用 single-flight：并发
    请求共享同一个 renewal task，取消某一个请求不会取消其他请求共同等待的续期。
    """

    def __init__(
        self,
        actor: ActorConnectionInfo,
        actor_jwt: ActorJWT,
        renewal_callback: ActorRenewalCallback | None = None,
        http_client: httpx.AsyncClient | None = None,
        http_client_registry: ActorHTTPClientRegistry | None = None,
        renewal_window_seconds: int = 300,
        telemetry: TelemetryEmitter | None = None,
        telemetry_attributes: Mapping[
            str, TelemetryScalar
        ] = EMPTY_TELEMETRY_ATTRIBUTES,
        runtime_configuration: Configuration | None = None,
    ) -> None:
        self.configuration: Configuration = (
            configuration if runtime_configuration is None else runtime_configuration
        )
        self.actor: ActorConnectionInfo = actor
        self.actor_jwt: ActorJWT = actor_jwt
        self.renewal_callback: ActorRenewalCallback | None = renewal_callback
        self.renewal_window: timedelta = timedelta(seconds=renewal_window_seconds)
        self.base_url: str = normalize_endpoint(actor)
        self._credential_lock: asyncio.Lock = asyncio.Lock()
        self._renewal_lock: asyncio.Lock = asyncio.Lock()
        self._renewal_task: asyncio.Task[None] | None = None
        self._closed: bool = False
        self._http_client: httpx.AsyncClient | None = None
        self._http_client_registry: ActorHTTPClientRegistry | None = None
        self._owns_http_client_registry: bool = False
        self._telemetry: TelemetryEmitter = telemetry or NOOP_TELEMETRY_EMITTER
        self._telemetry_attributes: dict[str, TelemetryScalar] = dict(
            telemetry_attributes
        )
        if http_client is not None:
            self._http_client = http_client
        elif http_client_registry is not None:
            self._http_client_registry = http_client_registry
        else:
            self._owns_http_client_registry = True
            self._http_client_registry = ActorHTTPClientRegistry(
                runtime_configuration=self.configuration
            )

    def _request_telemetry_attributes(
        self, *, event_cuid: str = ""
    ) -> dict[str, TelemetryScalar]:
        attributes = {
            **self._telemetry_attributes,
            "actor_cuid": self.actor.actor_cuid,
        }
        if event_cuid:
            attributes["event_cuid"] = event_cuid
        return attributes

    def _record_response_error(
        self,
        error: ActorAPIError,
        *,
        event_cuid: str = "",
    ) -> None:
        """记录 HTTP 成功后发生的 Actor 响应解析或校验失败。"""
        if not error.server:
            error.server = self.base_url.rstrip("/")
        if not error.actor_cuid:
            error.actor_cuid = self.actor.actor_cuid
        if event_cuid and not error.event_cuid:
            error.event_cuid = event_cuid
        record_operation(
            self._telemetry,
            "actor_response",
            status="error",
            attributes={
                **self._request_telemetry_attributes(event_cuid=event_cuid),
                **error_attributes(error),
            },
        )

    def _record_checkpoint_save(self, response: EventSucceededResponse) -> None:
        if response.type not in {
            EventType.TRAINER_SAVE_STATE,
            EventType.TRAINER_SAVE_WEIGHTS,
        }:
            return
        checkpoint = response.result.get("checkpoint")
        if not isinstance(checkpoint, dict):
            return
        checkpoint_cuid = checkpoint.get("checkpoint_cuid") or checkpoint.get("cuid")
        if not isinstance(checkpoint_cuid, str) or not checkpoint_cuid:
            return
        record_operation(
            self._telemetry,
            "checkpoint_save",
            attributes={
                **self._request_telemetry_attributes(event_cuid=response.event_id),
                "checkpoint_cuid": checkpoint_cuid,
            },
        )

    def _record_event_failure(self, response: EventFailedResponse) -> None:
        record_operation(
            self._telemetry,
            "training_event",
            status="error",
            attributes={
                **self._request_telemetry_attributes(event_cuid=response.event_id),
                "operation": response.type.value,
                "error": "EventFailedError",
                "error.code": response.error.code,
                "error.message": response.error.message,
            },
        )

    async def _resolve_http_client(self) -> httpx.AsyncClient:
        """从固定 Client 或共享 registry 解析当前 Actor 传输。"""
        if self._closed:
            raise ActorError("ActorHTTPClient is closed", code="actor.client_closed")
        if self._http_client is not None:
            return self._http_client
        if self._http_client_registry is None:
            raise ActorError(
                "ActorHTTPClient has no HTTP transport",
                code="actor.transport_unavailable",
            )
        return await self._http_client_registry.client_for(self.actor)

    async def aclose(self) -> None:
        """取消本 Client 的续期任务并释放其独占 HTTP 资源。"""
        if self._closed:
            return
        self._closed = True
        current = asyncio.current_task()
        async with self._renewal_lock:
            renewal_task = self._renewal_task
            self._renewal_task = None
        if (
            renewal_task is not None
            and renewal_task is not current
            and not renewal_task.done()
        ):
            renewal_task.cancel()
            await asyncio.gather(renewal_task, return_exceptions=True)
        if self._owns_http_client_registry and self._http_client_registry is not None:
            await self._http_client_registry.aclose()

    async def update_credentials(
        self, actor: ActorConnectionInfo, actor_jwt: ActorJWT
    ) -> None:
        """原子更新 Actor 地址和 JWT。"""
        async with self._credential_lock:
            if self._closed:
                raise ActorError(
                    "ActorHTTPClient is closed", code="actor.client_closed"
                )
            self.actor = actor
            self.actor_jwt = actor_jwt
            self.base_url = normalize_endpoint(actor)
            if self._http_client is not None:
                self._http_client.base_url = httpx.URL(self.base_url)

    async def _credential_snapshot(self) -> tuple[ActorConnectionInfo, ActorJWT]:
        async with self._credential_lock:
            if self._closed:
                raise ActorError(
                    "ActorHTTPClient is closed", code="actor.client_closed"
                )
            return self.actor, self.actor_jwt

    async def _headers_with_actor_jwt(
        self, headers: dict[str, str]
    ) -> ActorAuthorizationSnapshot:
        _, actor_jwt = await self._credential_snapshot()
        authorized_headers = dict(headers)
        authorized_headers["Authorization"] = f"Bearer {actor_jwt.token}"
        return ActorAuthorizationSnapshot(
            headers=authorized_headers,
            token=actor_jwt.token,
        )

    async def _perform_renewal(self) -> None:
        renewal_callback = self.renewal_callback
        if renewal_callback is None:
            raise ActorError(
                "Actor credentials are expiring and no renewal callback is configured",
                code="actor.renew_unavailable",
            )
        renewed = await renewal_callback()
        try:
            actor = renewed.actor
            actor_jwt = renewed.actor_jwt
        except AttributeError as error:
            raise ActorError(
                "Actor renew callback returned an invalid response",
                code="actor.invalid_renew_response",
            ) from error
        await self.update_credentials(actor, actor_jwt)

    async def _get_or_create_renewal_task(
        self,
        *,
        force: bool = False,
        expected_token: str | None = None,
        wait: bool = True,
    ) -> None:
        """获取 single-flight renewal task；可只预热而不等待网络。"""
        async with self._renewal_lock:
            if self._closed:
                raise ActorError(
                    "ActorHTTPClient is closed", code="actor.client_closed"
                )
            _, actor_jwt = await self._credential_snapshot()
            if expected_token is not None and actor_jwt.token != expected_token:
                return
            if not force:
                expires_at = actor_jwt.expires_at
                if not expires_at.tzinfo:
                    expires_at = expires_at.replace(tzinfo=timezone.utc)
                if expires_at - datetime.now(timezone.utc) > self.renewal_window:
                    return
            task = self._renewal_task
            if task is None or task.done():
                task = asyncio.create_task(self._perform_renewal())
                task.add_done_callback(self._consume_renewal_exception)
                self._renewal_task = task
        if not wait:
            return
        try:
            await asyncio.shield(task)
        finally:
            if task.done():
                async with self._renewal_lock:
                    if self._renewal_task is task:
                        self._renewal_task = None

    @staticmethod
    def _consume_renewal_exception(task: asyncio.Task[None]) -> None:
        """Mark background failures retrieved; send-boundary await still propagates them."""
        if not task.cancelled():
            task.exception()

    async def schedule_renewal_if_needed(self) -> None:
        """在队列扫描时调度临近过期凭据的续期，但不阻塞 dispatcher。"""
        await self._get_or_create_renewal_task(wait=False)

    async def renew_if_needed(self) -> None:
        """在请求发送前等待进入续期窗口的 single-flight task。"""
        await self._get_or_create_renewal_task()

    async def renew(self) -> None:
        """强制刷新当前 Actor 凭据。"""
        await self._get_or_create_renewal_task(force=True)

    async def _renew_if_token_matches(self, token: str) -> None:
        """401 后只为仍持有失败 token 的请求触发续期。"""
        await self._get_or_create_renewal_task(force=True, expected_token=token)

    async def _request_with_actor_jwt(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, object] = EMPTY_JSON_BODY,
        headers: dict[str, str] = EMPTY_HEADERS,
        content: bytes = b"",
        timeout: float = 0.0,
        max_attempts: int = 0,
        retry_timeout: float | None = None,
        error_cls: type[ActorAPIError] = ActorAPIError,
        event_cuid: str = "",
    ) -> httpx.Response:
        """使用 JWT 发起请求，并对同一 token 的首次 401 强制续期后重试。"""
        await self.renew_if_needed()
        authorized = await self._headers_with_actor_jwt(headers)
        try:
            return await self._request(
                method,
                path,
                json=json,
                headers=authorized.headers,
                content=content,
                timeout=timeout,
                max_attempts=max_attempts,
                retry_timeout=retry_timeout,
                error_cls=error_cls,
                event_cuid=event_cuid,
            )

        except ActorAPIError as error:
            if error.status_code != 401:
                raise
            # 401 强制续期比较请求使用的 token 快照；并发请求已经完成续期时直接复用
            # 新凭据，保证同一过期 token 只触发一次 Control 续期。
            await self._renew_if_token_matches(authorized.token)
            renewed_authorized = await self._headers_with_actor_jwt(headers)
            return await self._request(
                method,
                path,
                json=json,
                headers=renewed_authorized.headers,
                content=content,
                timeout=timeout,
                max_attempts=max_attempts,
                retry_timeout=retry_timeout,
                error_cls=error_cls,
                event_cuid=event_cuid,
            )

    @asynccontextmanager
    async def _stream_with_actor_jwt(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, object] = EMPTY_JSON_BODY,
        headers: dict[str, str] = EMPTY_HEADERS,
        timeout: float = 0.0,
        retry_timeout: float | None = None,
    ):
        """Open an Actor response body without buffering it in httpx."""
        await self.renew_if_needed()
        authorized = await self._headers_with_actor_jwt(headers)
        client = await self._resolve_http_client()

        async def send(snapshot: ActorAuthorizationSnapshot) -> httpx.Response:
            request = client.build_request(
                method, path, json=json, headers=snapshot.headers
            )
            if timeout > 0.0:
                request.extensions["timeout"] = {
                    "connect": timeout,
                    "read": timeout,
                    "write": timeout,
                    "pool": timeout,
                }
            return await client.send(
                request,
                stream=True,
            )

        async def wrap_stream_request_error(error: httpx.RequestError) -> ActorAPIError:
            connectivity = await probe_base_url_connectivity(
                self.configuration.base_url
            )
            wrapped = ActorAPIError(
                request_error_message(error),
                hint="Check your network connection and proxy settings.",
                details={"connectivity": connectivity.details()},
                operation=_operation(method, path),
                retryable=True,
                server=self.base_url.rstrip("/"),
                actor_cuid=self.actor.actor_cuid,
            )
            record_operation(
                self._telemetry,
                "actor_request",
                status="error",
                attributes={
                    "operation": _operation(method, path),
                    **self._request_telemetry_attributes(),
                    **error_attributes(wrapped),
                },
            )
            return wrapped

        async def send_with_retry(
            snapshot: ActorAuthorizationSnapshot,
        ) -> httpx.Response:
            response: httpx.Response | None = None
            retry_deadline: float | None = None
            delay = self.configuration.retry_initial_delay_seconds
            while response is None or response.status_code in RETRYABLE_STATUS_CODES:
                try:
                    response = await send(snapshot)
                except RETRYABLE_EXCEPTIONS as error:
                    if retry_timeout is None:
                        wrapped = await wrap_stream_request_error(error)
                        raise wrapped from None
                    if retry_deadline is None:
                        retry_deadline = monotonic() + max(0.0, retry_timeout)
                    remaining = retry_deadline - monotonic()
                    if remaining <= 0:
                        wrapped = await wrap_stream_request_error(error)
                        raise wrapped from None
                else:
                    if response.status_code not in RETRYABLE_STATUS_CODES:
                        break
                    if retry_timeout is None:
                        break
                    if retry_deadline is None:
                        retry_deadline = monotonic() + max(0.0, retry_timeout)
                    read_error: httpx.RequestError | None = None
                    try:
                        await response.aread()
                    except RETRYABLE_EXCEPTIONS as error:
                        read_error = error
                    finally:
                        await response.aclose()
                    remaining = retry_deadline - monotonic()
                    if remaining <= 0:
                        if read_error is not None:
                            wrapped = await wrap_stream_request_error(read_error)
                            raise wrapped from None
                        break
                await asyncio.sleep(min(delay, remaining))
                delay = min(
                    delay * self.configuration.retry_multiplier,
                    self.configuration.retry_max_delay_seconds,
                )
            assert response is not None
            return response

        response = await send_with_retry(authorized)
        if response.status_code == 401:
            try:
                await response.aread()
            except httpx.RequestError as error:
                wrapped = await wrap_stream_request_error(error)
                raise wrapped from None
            finally:
                await response.aclose()
            await self._renew_if_token_matches(authorized.token)
            response = await send_with_retry(await self._headers_with_actor_jwt(headers))
        try:
            yield response
        finally:
            await response.aclose()

    async def _request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, object] = EMPTY_JSON_BODY,
        headers: dict[str, str] = EMPTY_HEADERS,
        content: bytes = b"",
        timeout: float = 0.0,
        max_attempts: int = 0,
        retry_timeout: float | None = None,
        error_cls: type[ActorAPIError] = ActorAPIError,
        event_cuid: str = "",
    ) -> httpx.Response:
        """构造 Actor HTTP 调用，应用异步瞬时错误重试并转换失败响应。"""
        operation = _operation(method, path)
        started = perf_counter()
        try:
            http_client = await self._resolve_http_client()
            configured_timeout = timeout if timeout > 0.0 else None

            async def request_call() -> httpx.Response:
                if content:
                    if configured_timeout is None:
                        return await http_client.request(
                            method, path, headers=headers, content=content
                        )
                    return await http_client.request(
                        method,
                        path,
                        headers=headers,
                        content=content,
                        timeout=configured_timeout,
                    )
                if json:
                    if configured_timeout is None:
                        return await http_client.request(
                            method, path, headers=headers, json=json
                        )
                    return await http_client.request(
                        method,
                        path,
                        headers=headers,
                        json=json,
                        timeout=configured_timeout,
                    )
                if configured_timeout is None:
                    return await http_client.request(method, path, headers=headers)
                return await http_client.request(
                    method,
                    path,
                    headers=headers,
                    timeout=configured_timeout,
                )

            if retry_timeout is None:
                response = await request_with_retries(
                    request_call,
                    max_attempts=(
                        self.configuration.retry_max_attempts
                        if max_attempts <= 0
                        else max_attempts
                    ),
                    initial_delay=self.configuration.retry_initial_delay_seconds,
                    multiplier=self.configuration.retry_multiplier,
                    max_delay=self.configuration.retry_max_delay_seconds,
                    jitter=self.configuration.retry_jitter_ratio,
                )
            else:
                response = await request_with_retry_timeout(
                    request_call,
                    retry_timeout=retry_timeout,
                    initial_delay=self.configuration.retry_initial_delay_seconds,
                    multiplier=self.configuration.retry_multiplier,
                    max_delay=self.configuration.retry_max_delay_seconds,
                    jitter=self.configuration.retry_jitter_ratio,
                )
        except httpx.RequestError as error:
            connectivity = await probe_base_url_connectivity(
                self.configuration.base_url
            )
            wrapped = error_cls(
                request_error_message(error),
                hint="Check your network connection and proxy settings.",
                details={
                    "connectivity": connectivity.details(),
                },
                operation=operation,
                retryable=True,
                server=self.base_url.rstrip("/"),
                actor_cuid=self.actor.actor_cuid,
                event_cuid=event_cuid,
            )
            record_operation(
                self._telemetry,
                "actor_request",
                status="error",
                attributes={
                    "operation": operation,
                    **self._request_telemetry_attributes(event_cuid=event_cuid),
                    **error_attributes(wrapped),
                    "duration_ms": int((perf_counter() - started) * 1000),
                },
            )
            raise wrapped from None
        if response.status_code >= 400:
            error = self._error(
                response,
                error_cls,
                operation=operation,
                event_cuid=event_cuid,
            )
            record_operation(
                self._telemetry,
                "actor_request",
                status="error",
                attributes={
                    "operation": operation,
                    "status_code": response.status_code,
                    "request_id": response.headers.get("x-request-id", ""),
                    **self._request_telemetry_attributes(event_cuid=event_cuid),
                    **error_attributes(error),
                    "duration_ms": int((perf_counter() - started) * 1000),
                },
            )
            raise error
        record_operation(
            self._telemetry,
            "actor_request",
            attributes={
                "operation": operation,
                "status_code": response.status_code,
                "request_id": response.headers.get("x-request-id", ""),
                **self._request_telemetry_attributes(event_cuid=event_cuid),
                "duration_ms": int((perf_counter() - started) * 1000),
            },
        )
        return response

    def _error(
        self,
        response: httpx.Response,
        error_cls: type[ActorAPIError],
        *,
        operation: str,
        event_cuid: str = "",
    ) -> ActorAPIError:
        """从 JSON 或 MessagePack 失败响应提取 Actor 领域错误。"""
        content_type = response.headers.get("content-type", "")
        try:
            if "application/msgpack" in content_type:
                data = msgpack.unpackb(response.content, raw=False)
            else:
                data = response.json()
        except Exception:  # noqa: BLE001 - invalid remote bodies become domain errors
            data = {}
        data = data if isinstance(data, dict) else {}

        if isinstance(data.get("error"), dict):
            error = data["error"]
            code_value = error.get("code", "")
            message_value = error.get("message", "")
            details = dict(data)
            details["error"] = {
                key: value for key, value in error.items() if key != "message"
            }
        else:
            code_value = data.get("code", "")
            message_value = data.get("message", "")
            details = {key: value for key, value in data.items() if key != "message"}

        code = code_value if isinstance(code_value, str) else ""
        message = message_value if isinstance(message_value, str) else ""

        return error_cls(
            message or f"Actor request failed with HTTP {response.status_code}",
            status_code=response.status_code,
            code=code,
            details=details,
            operation=operation,
            server=self.base_url.rstrip("/"),
            request_id=response.headers.get("x-request-id", ""),
            actor_cuid=self.actor.actor_cuid,
            event_cuid=event_cuid,
        )
