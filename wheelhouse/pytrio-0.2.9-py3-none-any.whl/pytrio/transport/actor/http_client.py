"""汇集 Actor 心跳、事件和采样传输能力。"""

from pytrio.transport.actor.event.get import EventGetActorMixin
from pytrio.transport.actor.event.submit import EventSubmitActorMixin
from pytrio.transport.actor.heartbeat import HeartbeatActorMixin
from pytrio.transport.actor.sampling_run.sample import SamplingRunSampleActorMixin


class ActorHTTPClient(
    EventSubmitActorMixin,
    EventGetActorMixin,
    SamplingRunSampleActorMixin,
    HeartbeatActorMixin,
):
    """汇集 Actor 心跳、事件和采样 HTTP 能力。"""
