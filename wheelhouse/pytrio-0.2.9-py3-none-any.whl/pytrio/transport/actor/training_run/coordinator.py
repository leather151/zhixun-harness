"""Actor 训练事件的有序提交、并发控制与终态收敛。

该层拥有 event metadata 序列和本地队列。Client 提交由多个物理事件组成的逻辑组，
coordinator 统一管理 index、step、单片 Future 和组内事件顺序。
"""

from __future__ import annotations

import asyncio
import logging
import weakref
from collections import deque
from collections.abc import Sequence
from concurrent.futures import Future as ConcurrentFuture
from dataclasses import dataclass
from enum import Enum, auto
from typing import TYPE_CHECKING

from pytrio.config.config import Configuration, configuration
from pytrio.errors.actor import ActorEventGetError
from pytrio.errors.base import PyTrioError, ValidationError
from pytrio.errors.event import EventFailedError, EventPollingError
from pytrio.protocol.actor.events.base import ProtocolPayload
from pytrio.protocol.actor.events.codec import payload_to_wire_value
from pytrio.protocol.actor.events.event import (
    EventEnvelope,
    EventFailedResponse,
    EventMetadata,
    EventResponse,
    EventSucceededResponse,
    EventType,
    build_event_envelope,
    current_timestamp_ms,
)
from pytrio.transport.actor.http_client import ActorHTTPClient
from pytrio.types.future.api_future import APIFuture
from pytrio.types.future.collect import collect_api_futures

if TYPE_CHECKING:
    from pytrio.runtime.service import ServiceRuntime

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class _QueuedEvent:
    """一个物理事件及其逻辑组边界、失败安全策略。"""

    event_type: EventType
    payload_value: dict[str, object]
    future: ConcurrentFuture[dict[str, object]]
    ends_logical_step: bool
    failure_breaks_run: bool


class _QueueScanState(Enum):
    IDLE = auto()
    CLOSED = auto()


class ActorTrainingRunCoordinator:
    """维护单个 training run 的事件序列、背压和异步轮询生命周期。

    ``index`` 标识每个物理事件，``step`` 标识 Trainer 看到的逻辑训练步。自动梯度累加
    通过重复 step 表达，chunk 归一化信息由 forward payload 承载。
    """

    def __init__(
        self,
        *,
        actor_client: ActorHTTPClient,
        training_run_cuid: str,
        poll_interval: float = 0.5,
        max_in_flight_events: int = 0,
        max_queued_events: int = 0,
        runtime: ServiceRuntime | None = None,
        runtime_configuration: Configuration | None = None,
    ) -> None:
        self.actor_client: ActorHTTPClient = actor_client
        self._runtime: ServiceRuntime | None = runtime
        self._configuration: Configuration = (
            configuration if runtime_configuration is None else runtime_configuration
        )
        current = self._configuration
        self._loop: asyncio.AbstractEventLoop = asyncio.get_running_loop()
        self._max_in_flight_events: int = (
            current.training_event_max_in_flight
            if max_in_flight_events == 0
            else max_in_flight_events
        )
        self._max_queued_events: int = (
            current.training_event_queue_capacity
            if max_queued_events == 0
            else max_queued_events
        )
        if self._max_in_flight_events < 1 or self._max_queued_events < 1:
            raise ValidationError(
                "Training event queue limits must be positive",
                code="validation.invalid_event_queue_limit",
            )
        self.training_run_cuid: str = training_run_cuid
        self.poll_interval: float = poll_interval
        self.index: int = 1
        self.step: int = 0
        self._closed: bool = False
        self._broken: bool = False
        self._broken_message: str = (
            "ActorTrainingRunCoordinator is broken after an uncertain submit failure"
        )
        self._sequence_lock: asyncio.Lock = asyncio.Lock()
        self._submit_lock: asyncio.Lock = asyncio.Lock()
        self._queue_condition: asyncio.Condition = asyncio.Condition()
        self._queue: deque[_QueuedEvent] = deque()
        self._in_flight_events: int = 0
        self._tasks: set[asyncio.Task[None]] = set()
        self._pending_futures: set[ConcurrentFuture[dict[str, object]]] = set()
        self._dispatcher_task: asyncio.Task[None] | None = None

    async def submit(
        self, event_type: EventType, payload: ProtocolPayload
    ) -> APIFuture[dict[str, object]]:
        futures = await self._submit_event_group(event_type, [payload])
        return futures[0]

    async def submit_group(
        self,
        event_type: EventType,
        payloads: Sequence[ProtocolPayload],
    ) -> APIFuture[list[dict[str, object]]]:
        """提交一个不可插入的 forward 逻辑组，并返回单一聚合 Future。

        成组接口适用于具有逐样本输出和 FB step 边界的 forward 类事件；optimize/save
        等控制事件保持一调用一事件的状态转换语义。
        """
        if not payloads:
            raise ValueError("training event group cannot be empty")
        if event_type not in (
            EventType.TRAINER_FORWARD,
            EventType.TRAINER_FORWARD_BACKWARD,
        ):
            raise ValueError(f"training event groups do not support {event_type.value}")
        futures = await self._submit_event_group(event_type, payloads)
        return collect_api_futures(futures)

    async def _submit_event_group(
        self,
        event_type: EventType,
        payloads: Sequence[ProtocolPayload],
    ) -> list[APIFuture[dict[str, object]]]:
        """编码并原子准入一组物理事件，同时建立 step 与失败策略。"""
        payload_values = [
            payload_to_wire_value(event_type, payload) for payload in payloads
        ]
        async with self._submit_lock:
            self._raise_if_unavailable()
            self._get_or_bind_loop()
            queued_events: list[_QueuedEvent] = []
            try:
                for position, payload_value in enumerate(payload_values):
                    future: ConcurrentFuture[dict[str, object]] = ConcurrentFuture()
                    self._track_future(future)
                    # FB 组内所有 chunk 使用当前 step，最后一片成功提交时推进 step；多片
                    # FB 任一失败时梯度完整性未知，coordinator 进入永久 broken 状态。
                    queued_event = _QueuedEvent(
                        event_type=event_type,
                        payload_value=payload_value,
                        future=future,
                        ends_logical_step=(
                            event_type == EventType.TRAINER_FORWARD_BACKWARD
                            and position == len(payload_values) - 1
                        ),
                        failure_breaks_run=(
                            event_type == EventType.TRAINER_FORWARD_BACKWARD
                            and len(payload_values) > 1
                        ),
                    )
                    queued_events.append(queued_event)
                await self._enqueue_events(queued_events)
                self._ensure_dispatcher_task()
            except BaseException:
                for queued_event in queued_events:
                    queued_event.future.cancel()
                raise
            return [APIFuture(queued_event.future) for queued_event in queued_events]

    def _ensure_dispatcher_task(self) -> None:
        if self._dispatcher_task is None or self._dispatcher_task.done():
            self._dispatcher_task = asyncio.create_task(self._dispatch_queued_events())

    def _raise_if_unavailable(self) -> None:
        if self._closed:
            raise PyTrioError(
                "ActorTrainingRunCoordinator is closed", code="training.run_closed"
            )
        if self._broken:
            raise PyTrioError(
                self._broken_message,
                code="training.run_broken",
            )

    def _get_or_bind_loop(self) -> asyncio.AbstractEventLoop:
        loop = asyncio.get_running_loop()
        if self._loop is not loop:
            raise PyTrioError(
                "ActorTrainingRunCoordinator cannot be used across multiple event loops",
                code="training.run_loop_mismatch",
            )
        return self._loop

    def _build_envelope(self, queued_event: _QueuedEvent) -> EventEnvelope:
        metadata = EventMetadata(
            index=self.index,
            step=self.step,
            timestamp=current_timestamp_ms(),
            sdk="pytrio",
            sdk_version=self._configuration.version,
            run_id=self.training_run_cuid,
        )
        return build_event_envelope(
            queued_event.event_type,
            queued_event.payload_value,
            metadata,
        )

    def _advance_sequence(self, queued_event: _QueuedEvent) -> None:
        """在 Actor 确认接收物理事件后推进已提交序列。"""
        self.index += 1
        if queued_event.ends_logical_step:
            self.step += 1

    async def _enqueue_events(self, queued_events: Sequence[_QueuedEvent]) -> None:
        async with self._queue_condition:
            # 一个逻辑调用整体准入，单组可以暂时把队列推过阈值；队列阈值决定后续
            # 逻辑调用的准入时机。
            while len(self._queue) >= self._max_queued_events:
                self._raise_if_unavailable()
                await self._queue_condition.wait()
            self._raise_if_unavailable()
            self._queue.extend(queued_events)
            self._queue_condition.notify_all()

    async def _dispatch_queued_events(self) -> None:
        """按 FIFO 顺序为已准入事件分配并发槽位并提交。"""
        while True:
            # 队列扫描时预热即将过期的 Actor 凭据；提交边界仍会再次检查，避免
            # direct/恢复路径绕过认证屏障。
            await self.actor_client.schedule_renewal_if_needed()
            queued_event = await self._next_queued_event()
            if isinstance(queued_event, _QueueScanState):
                return
            if queued_event.future.cancelled():
                await self._release_in_flight_slot()
                continue
            await self._submit_queued_event(
                queued_event,
                raise_submit_error=False,
                release_slot=True,
            )

    async def _next_queued_event(
        self,
    ) -> _QueuedEvent | _QueueScanState:
        async with self._queue_condition:
            while True:
                self._drop_done_queued_events_locked()
                if self._closed or self._broken:
                    return _QueueScanState.CLOSED
                if not self._queue and self._in_flight_events == 0:
                    return _QueueScanState.IDLE
                if self._queue and self._in_flight_events < self._max_in_flight_events:
                    queued_event = self._queue.popleft()
                    self._in_flight_events += 1
                    self._queue_condition.notify_all()
                    return queued_event
                await self._queue_condition.wait()

    def _drop_done_queued_events_locked(self) -> None:
        if not any(queued_event.future.done() for queued_event in self._queue):
            return
        self._queue = deque(
            queued_event
            for queued_event in self._queue
            if not queued_event.future.done()
        )

    def _future_for_response(
        self, response: EventResponse
    ) -> APIFuture[dict[str, object]]:
        future: ConcurrentFuture[dict[str, object]] = ConcurrentFuture()
        self._track_future(future)
        self._handle_response_without_slot(response, future)
        return APIFuture(future)

    def _track_future(self, future: ConcurrentFuture[dict[str, object]]) -> None:
        self._pending_futures.add(future)
        coordinator_ref = weakref.ref(self)

        def _cleanup(src: ConcurrentFuture[dict[str, object]]) -> None:
            coordinator = coordinator_ref()
            if coordinator is None:
                return
            try:
                coordinator._loop.call_soon_threadsafe(
                    coordinator._future_done_on_loop, src
                )
            except RuntimeError:
                pass

        future.add_done_callback(_cleanup)

    def _attach_error_context(
        self,
        error: PyTrioError,
        event_cuid: str = "",
    ) -> None:
        if not error.task_cuid:
            error.task_cuid = self.training_run_cuid
        if not error.actor_cuid:
            error.actor_cuid = self.actor_client.actor.actor_cuid
        if event_cuid:
            error.event_cuid = event_cuid

    def _future_done_on_loop(self, future: ConcurrentFuture[dict[str, object]]) -> None:
        self._pending_futures.discard(future)
        if self._loop.is_closed():
            return
        asyncio.create_task(self._notify_queue_waiters())

    async def _notify_queue_waiters(self) -> None:
        async with self._queue_condition:
            self._queue_condition.notify_all()

    async def _submit_queued_event(
        self,
        queued_event: _QueuedEvent,
        *,
        raise_submit_error: bool,
        release_slot: bool,
    ) -> None:
        """串行分配 metadata 序列并把一个物理事件提交给 Actor。

        事件只有在 Actor 确认接收后推进 ``index`` 和逻辑 ``step``。提交结果处理移出
        sequence lock，使后续事件可以继续提交并由 in-flight 上限控制并发。
        """
        async with self._sequence_lock:
            try:
                self._raise_if_unavailable()
                envelope = self._build_envelope(queued_event)
            except Exception as e:
                if release_slot:
                    await self._release_in_flight_slot()
                if not queued_event.future.done():
                    queued_event.future.set_exception(e)
                if raise_submit_error:
                    raise
                return
            try:
                response = await self.actor_client.submit_event(envelope)
            except Exception as e:
                if isinstance(e, PyTrioError):
                    self._attach_error_context(e, event_cuid=envelope.event_id)
                self._broken = True
                await self._mark_broken()
                if release_slot:
                    await self._release_in_flight_slot()
                if not queued_event.future.done():
                    queued_event.future.set_exception(e)
                if raise_submit_error:
                    raise
                return
            self._advance_sequence(queued_event)
        await self._handle_submit_response(
            response,
            queued_event,
            release_slot=release_slot,
        )

    async def _handle_submit_response(
        self,
        response: EventResponse,
        queued_event: _QueuedEvent,
        *,
        release_slot: bool,
    ) -> None:
        """将 Actor 首次响应收敛为终态 future 或启动轮询。"""
        future = queued_event.future
        if future.done():
            if release_slot:
                await self._release_in_flight_slot()
            return
        if isinstance(response, EventSucceededResponse):
            future.set_result({"result": response.result})
            if release_slot:
                await self._release_in_flight_slot()
        elif isinstance(response, EventFailedResponse):
            error = EventFailedError(
                response.event_id,
                response.error.code,
                response.error.message,
                task_cuid=self.training_run_cuid,
            )
            self._attach_error_context(error)
            future.set_exception(error)
            if queued_event.failure_breaks_run:
                # 前序 chunk 可能已经完成 backward，此时梯度完整性状态未知。coordinator
                # 进入永久 broken 状态并阻断后续训练操作。
                await self._mark_broken(
                    "ActorTrainingRunCoordinator cannot continue after a gradient "
                    "accumulation chunk failed"
                )
            if release_slot:
                await self._release_in_flight_slot()
        else:
            self._start_poll(
                response.event_id,
                future,
                release_slot=release_slot,
                failure_breaks_run=queued_event.failure_breaks_run,
            )

    def _handle_response_without_slot(
        self,
        response: EventResponse,
        future: ConcurrentFuture[dict[str, object]],
    ) -> None:
        """处理不占用普通 in-flight 槽位的事件响应。"""
        if isinstance(response, EventSucceededResponse):
            future.set_result({"result": response.result})
        elif isinstance(response, EventFailedResponse):
            error = EventFailedError(
                response.event_id,
                response.error.code,
                response.error.message,
                task_cuid=self.training_run_cuid,
            )
            self._attach_error_context(error)
            future.set_exception(error)
        else:
            self._start_poll(
                response.event_id,
                future,
                release_slot=False,
                failure_breaks_run=False,
            )

    def _start_poll(
        self,
        event_id: str,
        future: ConcurrentFuture[dict[str, object]],
        *,
        release_slot: bool,
        failure_breaks_run: bool,
    ) -> None:
        """创建事件终态轮询 task，并建立 future 取消联动。"""
        logger.debug(
            "Starting event polling task=%s event=%s release_slot=%s",
            self.training_run_cuid,
            event_id,
            release_slot,
        )
        task = asyncio.create_task(
            self._poll(
                event_id,
                future,
                release_slot=release_slot,
                failure_breaks_run=failure_breaks_run,
            )
        )
        self._tasks.add(task)

        def _cleanup(_: asyncio.Task[None]) -> None:
            self._tasks.discard(task)

        def _cancel_poll(src: ConcurrentFuture[dict[str, object]]) -> None:
            if src.cancelled() and not task.done():
                try:
                    task.get_loop().call_soon_threadsafe(task.cancel)
                except RuntimeError:
                    pass

        task.add_done_callback(_cleanup)
        future.add_done_callback(_cancel_poll)

    async def _release_in_flight_slot(self) -> None:
        async with self._queue_condition:
            if self._in_flight_events > 0:
                self._in_flight_events -= 1
            self._queue_condition.notify_all()

    async def _mark_broken(self, message: str | None = None) -> None:
        """使 coordinator 永久不可提交，并用同一原因收敛尚未发出的队列事件。"""
        async with self._queue_condition:
            self._broken = True
            if message is not None:
                self._broken_message = message
            error = PyTrioError(
                self._broken_message,
                code="training.run_broken",
            )
            while self._queue:
                queued_event = self._queue.popleft()
                if not queued_event.future.done():
                    queued_event.future.set_exception(error)
            self._queue_condition.notify_all()

    def begin_shutdown(self) -> None:
        self._closed = True
        for future in list(self._pending_futures):
            if not future.done():
                future.cancel()

    async def aclose(self) -> None:
        """关闭 coordinator、取消本地工作并释放 Actor 异步资源。"""
        self.begin_shutdown()
        await self._cancel_pending_events_on_loop()
        current = asyncio.current_task()
        tasks = [
            task for task in self._tasks if task is not current and not task.done()
        ]
        if (
            self._dispatcher_task is not None
            and self._dispatcher_task is not current
            and not self._dispatcher_task.done()
        ):
            self._dispatcher_task.cancel()
            tasks.append(self._dispatcher_task)
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        await self.actor_client.aclose()

    async def _cancel_pending_events_on_loop(self) -> None:
        for future in list(self._pending_futures):
            if not future.done():
                future.cancel()
        async with self._queue_condition:
            self._queue.clear()
            self._queue_condition.notify_all()
        for task in list(self._tasks):
            if not task.done() and task is not asyncio.current_task():
                task.cancel()

    async def _poll(
        self,
        event_id: str,
        future: ConcurrentFuture[dict[str, object]],
        *,
        release_slot: bool,
        failure_breaks_run: bool,
    ) -> None:
        """轮询 Actor 事件直到终态，并维护槽位与梯度完整性状态。"""
        try:
            while not future.done():
                logger.debug(
                    "Polling Actor event task=%s event=%s",
                    self.training_run_cuid,
                    event_id,
                )
                response = await self.actor_client.get_event(event_id)
                if isinstance(response, EventSucceededResponse):
                    logger.debug(
                        "Actor event reached success task=%s event=%s",
                        self.training_run_cuid,
                        event_id,
                    )
                    future.set_result({"result": response.result})
                    return
                if isinstance(response, EventFailedResponse):
                    logger.debug(
                        "Actor event reached failure task=%s event=%s code=%s",
                        self.training_run_cuid,
                        event_id,
                        response.error.code,
                    )
                    error = EventFailedError(
                        event_id,
                        response.error.code,
                        response.error.message,
                        task_cuid=self.training_run_cuid,
                    )
                    self._attach_error_context(error)
                    future.set_exception(error)
                    if failure_breaks_run:
                        await self._mark_broken(
                            "ActorTrainingRunCoordinator cannot continue after a gradient "
                            "accumulation chunk failed"
                        )
                    return
                await asyncio.sleep(self.poll_interval)
        except asyncio.CancelledError:
            if not future.done():
                future.cancel()
            raise
        except ActorEventGetError as e:
            if not future.done():
                self._attach_error_context(e, event_cuid=event_id)
                future.set_exception(e)
                if failure_breaks_run:
                    # 终态查询失败将梯度累加组的已执行范围标记为未知，coordinator 随即进入
                    # broken 状态。
                    await self._mark_broken(
                        "ActorTrainingRunCoordinator cannot continue after a gradient "
                        "accumulation chunk result became uncertain"
                    )
        except Exception as e:  # noqa: BLE001 - user future carries polling failures
            if not future.done():
                error = EventPollingError(
                    event_id, str(e), details={"event_cuid": event_id, "cause": repr(e)}
                )
                self._attach_error_context(error)
                future.set_exception(error)
                if failure_breaks_run:
                    await self._mark_broken(
                        "ActorTrainingRunCoordinator cannot continue after a gradient "
                        "accumulation chunk result became uncertain"
                    )
        finally:
            if release_slot:
                await self._release_in_flight_slot()
