"""按 Actor 地址与 TLS 身份复用异步 HTTP 客户端。"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass

import httpx

from pytrio.config.config import Configuration, configuration
from pytrio.protocol.control.actor.credentials import ActorConnectionInfo
from pytrio.transport.actor.tls import (
    actor_tls_fingerprint,
    create_actor_async_http_client,
    normalize_endpoint,
)


@dataclass(frozen=True)
class ActorHTTPClientKey:
    """决定 HTTP 连接可安全复用的 Actor endpoint 与 TLS 身份。"""

    base_url: str
    tls_fingerprint: str


def actor_http_client_key(actor: ActorConnectionInfo) -> ActorHTTPClientKey:
    """从已校验的 Actor 连接信息构造 registry 键。"""
    return ActorHTTPClientKey(
        base_url=normalize_endpoint(actor),
        tls_fingerprint=actor_tls_fingerprint(actor),
    )


class ActorHTTPClientRegistry:
    """拥有 ServiceRuntime 范围内的 Actor 异步 HTTP 连接。

    Registry 只在 SDK event loop 中访问，因此不需要线程锁。相同 endpoint 和 TLS 证书
    复用一个 ``httpx.AsyncClient``；证书轮换会自然生成新键和新连接。
    """

    def __init__(
        self,
        *,
        max_connections: int | None = None,
        max_keepalive_connections: int | None = None,
        runtime_configuration: Configuration | None = None,
    ) -> None:
        self.configuration: Configuration = (
            configuration if runtime_configuration is None else runtime_configuration
        )
        self._max_connections: int = (
            self.configuration.actor_http_max_connections
            if max_connections is None
            else max_connections
        )
        self._max_keepalive_connections: int = (
            self.configuration.actor_http_max_keepalive_connections
            if max_keepalive_connections is None
            else max_keepalive_connections
        )
        if self._max_connections < 1 or self._max_keepalive_connections < 1:
            raise ValueError("Actor HTTP connection limits must be positive")
        self._clients: dict[ActorHTTPClientKey, httpx.AsyncClient] = {}
        self._closed: bool = False

    async def client_for(self, actor: ActorConnectionInfo) -> httpx.AsyncClient:
        """返回当前 Actor TLS 身份对应的可用异步 HTTP Client。"""
        key = actor_http_client_key(actor)
        if self._closed:
            raise RuntimeError("ActorHTTPClientRegistry is closed")
        client = self._clients.get(key)
        if client is not None and not client.is_closed:
            return client
        client = create_actor_async_http_client(
            actor,
            timeout=self.configuration.request_timeout_seconds,
            limits=httpx.Limits(
                max_connections=self._max_connections,
                max_keepalive_connections=self._max_keepalive_connections,
            ),
        )
        self._clients[key] = client
        return client

    async def aclose(self) -> None:
        """幂等关闭 registry 拥有的全部 AsyncClient。"""
        if self._closed:
            return
        self._closed = True
        clients = list(self._clients.values())
        self._clients.clear()
        if clients:
            results = await asyncio.gather(
                *(client.aclose() for client in clients),
                return_exceptions=True,
            )
            for result in results:
                if isinstance(result, BaseException):
                    raise result
