"""校验 Actor 事件提交与查询响应。"""

from pytrio.errors.actor import ActorEventGetError, ActorEventSubmitError
from pytrio.protocol.actor.events.event import EventEnvelope, EventResponse


def validate_submit_response(envelope: EventEnvelope, response: EventResponse) -> None:
    if response.event_id != envelope.event_id:
        raise ActorEventSubmitError(
            "Actor response event_id does not match submitted event",
            code="actor.event_mismatch",
            details={
                "expected_event_id": envelope.event_id,
                "actual_event_id": response.event_id,
                "expected_type": envelope.type.value,
                "actual_type": response.type.value,
            },
        )
    if response.type != envelope.type:
        raise ActorEventSubmitError(
            "Actor response type does not match submitted event",
            code="actor.event_mismatch",
            details={
                "expected_event_id": envelope.event_id,
                "actual_event_id": response.event_id,
                "expected_type": envelope.type.value,
                "actual_type": response.type.value,
            },
        )


def validate_get_response(event_id: str, response: EventResponse) -> None:
    if response.event_id != event_id:
        raise ActorEventGetError(
            "Actor response event_id does not match requested event",
            code="actor.event_mismatch",
            details={
                "expected_event_id": event_id,
                "actual_event_id": response.event_id,
            },
        )
