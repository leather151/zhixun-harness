"""查询 Actor 事件执行状态。"""

import logging

from pytrio.errors.actor import ActorEventGetError
from pytrio.protocol.actor.events.event import (
    EventFailedResponse,
    EventResponse,
    EventSucceededResponse,
)
from pytrio.transport.actor.event.response import event_response_from_http
from pytrio.transport.actor.event.validate import validate_get_response
from pytrio.transport.actor.http_base import BaseActorHTTPClient

logger = logging.getLogger(__name__)


class EventGetActorMixin(BaseActorHTTPClient):
    """提供 ``EventGetActor`` 接口的强类型 HTTP 调用。"""

    async def get_event(
        self, event_id: str, *, wait_timeout_seconds: int | None = None
    ) -> EventResponse:
        """长轮询一个 Actor 事件的当前状态。

        Args:
            event_id: 事件信封中的唯一 ID。
            wait_timeout_seconds: Actor 等待状态变化的秒数。

        Returns:
            经过 MessagePack 解码和事件 ID 校验的状态响应。
        """
        wait_timeout = (
            self.configuration.actor_event_polling_timeout_seconds
            if wait_timeout_seconds is None
            else wait_timeout_seconds
        )
        logger.debug(
            "Sending Actor event get event=%s wait_timeout=%s actor=%s",
            event_id,
            wait_timeout,
            self.actor.actor_cuid,
        )
        response = await self._request_with_actor_jwt(
            "GET",
            f"v1/events/{event_id}",
            headers={
                "Accept": "application/msgpack",
                "Prefer": f"wait={wait_timeout}",
            },
            timeout=self.configuration.actor_event_polling_timeout_seconds,
            retry_timeout=self.configuration.training_retry_timeout_seconds,
            error_cls=ActorEventGetError,
            event_cuid=event_id,
        )
        try:
            event_response = event_response_from_http(response, ActorEventGetError)
            validate_get_response(event_id, event_response)
        except ActorEventGetError as error:
            self._record_response_error(error, event_cuid=event_id)
            raise
        if isinstance(event_response, EventFailedResponse):
            self._record_event_failure(event_response)
        elif isinstance(event_response, EventSucceededResponse):
            self._record_checkpoint_save(event_response)
        logger.debug(
            "Received Actor event get event=%s status=%s actor=%s",
            event_response.event_id,
            event_response.status.value,
            self.actor.actor_cuid,
        )
        return event_response
