"""提交 Actor 事件信封。"""

import logging

from pytrio.errors.actor import ActorEventSubmitError
from pytrio.protocol.actor.events.event import (
    EVENT_PROTOCOL_VERSION,
    EventAcceptedResponse,
    EventEnvelope,
    EventFailedResponse,
    EventResponse,
    EventStatus,
    EventSucceededResponse,
    pack_event_envelope,
)
from pytrio.transport.actor.event.response import event_response_from_http
from pytrio.transport.actor.event.validate import validate_submit_response
from pytrio.transport.actor.http_base import BaseActorHTTPClient

logger = logging.getLogger(__name__)


class EventSubmitActorMixin(BaseActorHTTPClient):
    """提供 ``EventSubmitActor`` 接口的强类型 HTTP 调用。"""

    async def submit_event(self, envelope: EventEnvelope) -> EventResponse:
        """提交 Actor 事件信封并校验首次状态响应。

        Args:
            envelope: 带唯一 ID、顺序元数据和强类型载荷的事件。

        Returns:
            Actor 返回的接收、运行或终态响应。

        Raises:
            ActorEventSubmitError: Actor 拒绝事件或返回无效响应。
        """
        logger.debug(
            "Sending Actor event submit task=%s event=%s type=%s actor=%s",
            envelope.metadata.run_id,
            envelope.event_id,
            envelope.type.value,
            self.actor.actor_cuid,
        )
        try:
            response = await self._request_with_actor_jwt(
                "POST",
                "v1/events",
                content=pack_event_envelope(envelope),
                headers={
                    "Content-Type": "application/msgpack",
                    "Accept": "application/msgpack",
                },
                timeout=self.configuration.actor_event_submit_timeout_seconds,
                retry_timeout=self.configuration.training_retry_timeout_seconds,
                error_cls=ActorEventSubmitError,
                event_cuid=envelope.event_id,
            )
        except ActorEventSubmitError as e:
            # event ID 是幂等键；Actor 已持有相同事件时，coordinator 可以继续按已接收状态
            # 轮询原事件，不重复推进本地序列。
            if e.status_code == 409 and e.code == "event_exists":
                logger.debug(
                    "Actor event submit deduplicated task=%s event=%s actor=%s",
                    envelope.metadata.run_id,
                    envelope.event_id,
                    self.actor.actor_cuid,
                )
                return EventAcceptedResponse(
                    version=EVENT_PROTOCOL_VERSION,
                    event_id=envelope.event_id,
                    type=envelope.type,
                    status=EventStatus.ACCEPTED,
                )
            raise
        try:
            event_response = event_response_from_http(response, ActorEventSubmitError)
            validate_submit_response(envelope, event_response)
        except ActorEventSubmitError as error:
            self._record_response_error(error, event_cuid=envelope.event_id)
            raise
        if isinstance(event_response, EventFailedResponse):
            self._record_event_failure(event_response)
        elif isinstance(event_response, EventSucceededResponse):
            self._record_checkpoint_save(event_response)
        logger.debug(
            "Received Actor event submit task=%s event=%s status=%s actor=%s",
            envelope.metadata.run_id,
            event_response.event_id,
            event_response.status.value,
            self.actor.actor_cuid,
        )
        return event_response
