"""将 Actor 事件 HTTP 响应解析为终态协议模型。"""

import httpx

from pytrio.errors.actor import ActorAPIError
from pytrio.protocol.actor.events.event import (
    EventResponse,
    parse_event_response,
    unpack_event_response,
)


def event_response_from_http(
    response: httpx.Response, error_cls: type[ActorAPIError]
) -> EventResponse:
    content_type = response.headers.get("content-type", "")
    try:
        if "application/json" in content_type:
            return parse_event_response(response.json())
        return unpack_event_response(response.content)
    except Exception as e:  # noqa: BLE001 - protocol parsers have multiple error types
        raise error_cls(
            str(e) or "Failed to parse Actor event response",
            code="actor.invalid_response",
            hint="Failed to parse the Actor event response.",
            details={"content_type": content_type},
        ) from None
