"""发送 Actor 心跳请求。"""

from pytrio.errors.actor import ActorAPIError
from pytrio.transport.actor.http_base import BaseActorHTTPClient


class HeartbeatActorMixin(BaseActorHTTPClient):
    """提供 ``HeartbeatActor`` 接口的强类型 HTTP 调用。"""

    async def heartbeat(self) -> dict[str, object]:
        """发送 SDK 心跳并返回 Actor 提供的调度参数。"""
        response = await self._request_with_actor_jwt(
            "POST",
            "v1/client/heartbeat",
            json={"sdk": "pytrio", "sdk_version": self.configuration.version},
            headers={"Accept": "application/json"},
        )
        try:
            data = response.json()
            if not isinstance(data, dict):
                raise ActorAPIError(
                    "Actor heartbeat response must be a JSON object",
                    code="actor.invalid_response",
                    details={"type": type(data).__name__},
                    operation="actor.heartbeat",
                )
        except ActorAPIError as error:
            self._record_response_error(error)
            raise
        except Exception as e:  # noqa: BLE001 - invalid remote JSON becomes a domain error
            error = ActorAPIError(
                str(e) or "Failed to parse Actor heartbeat response",
                code="actor.invalid_response",
                hint="Failed to parse the Actor heartbeat response.",
                operation="actor.heartbeat",
            )
            self._record_response_error(error)
            raise error from None
        return data
