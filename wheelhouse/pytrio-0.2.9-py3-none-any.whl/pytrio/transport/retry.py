"""执行异步 HTTP 请求的统一重试策略。"""

import asyncio
import random
import time
from collections.abc import Awaitable, Callable

import httpx

RETRYABLE_STATUS_CODES = frozenset({408, 429, 500, 502, 503, 504})
RETRYABLE_EXCEPTIONS = (
    httpx.ConnectError,
    httpx.ReadError,
    httpx.RemoteProtocolError,
    httpx.PoolTimeout,
    httpx.WriteError,
    httpx.TimeoutException,
)


def request_error_message(error: httpx.RequestError) -> str:
    """生成保留网络失败阶段和底层原因的用户错误摘要。"""
    if isinstance(error, httpx.ConnectTimeout):
        return "Connection timed out"
    if isinstance(error, httpx.ReadTimeout):
        return "Response read timed out"

    raw_message = str(error)
    if isinstance(error, httpx.ConnectError):
        message = "Connection failed"
        return f"{message}. {raw_message}" if raw_message else message
    if isinstance(error, httpx.ReadError):
        message = "Response read failed"
        return f"{message}. {raw_message}" if raw_message else message
    return raw_message or "Request failed"


def is_retryable_response(response: httpx.Response) -> bool:
    """返回响应是否应由通用 HTTP 策略重试。"""
    return response.status_code in RETRYABLE_STATUS_CODES


async def request_with_retries(
    request: Callable[[], Awaitable[httpx.Response]],
    *,
    max_attempts: int,
    initial_delay: float,
    multiplier: float,
    max_delay: float,
    jitter: float,
    should_retry_response: Callable[[httpx.Response], bool] = is_retryable_response,
) -> httpx.Response:
    """按指数退避策略重试瞬时网络错误和服务端状态码。

    Args:
        request: 执行一次异步 HTTP 请求的闭包。
        max_attempts: 包含首次请求在内的最大尝试次数。
        initial_delay: 首次重试基础等待秒数。
        multiplier: 每次失败后的等待倍率。
        max_delay: 基础等待秒数上限。
        jitter: 在基础等待上增加的随机比例上限。
        should_retry_response: 判断响应是否由通用重试层处理的函数。

    Returns:
        首个结束重试流程的 HTTP 响应。

    Raises:
        httpx.RequestError: 最后一次请求仍发生可重试网络错误。
    """
    attempts = max(1, max_attempts)
    delay = initial_delay
    for attempt in range(1, attempts + 1):
        try:
            response = await request()
        except RETRYABLE_EXCEPTIONS:
            if attempt == attempts:
                raise
            await _sleep(delay, jitter)
            delay = min(delay * multiplier, max_delay)
            continue

        if should_retry_response(response) and attempt < attempts:
            await _sleep(delay, jitter)
            delay = min(delay * multiplier, max_delay)
            continue
        return response

    raise RuntimeError("unreachable retry state")


async def request_with_retry_timeout(
    request: Callable[[], Awaitable[httpx.Response]],
    *,
    retry_timeout: float,
    initial_delay: float,
    multiplier: float,
    max_delay: float,
    jitter: float,
    should_retry_response: Callable[[httpx.Response], bool] = is_retryable_response,
) -> httpx.Response:
    """首次可重试失败后，在恢复窗口内重试瞬时网络错误和服务端状态码。

    首次请求使用完整业务 timeout 且不消耗恢复窗口。首次可重试失败发生后开始计时；
    deadline 前已经开始的重试仍按自身 HTTP timeout 自然结束。
    """
    try:
        response = await request()
    except RETRYABLE_EXCEPTIONS as error:
        last_response = None
        last_error: httpx.RequestError | None = error
    else:
        if not should_retry_response(response):
            return response
        last_response = response
        last_error = None

    deadline = time.monotonic() + max(0.0, retry_timeout)
    delay = initial_delay
    while True:
        if not await _sleep_before_retry_deadline(delay, jitter, deadline):
            if last_response is not None:
                return last_response
            if last_error is not None:
                raise last_error
            raise RuntimeError("unreachable retry deadline state")
        delay = min(delay * multiplier, max_delay)
        try:
            response = await request()
        except RETRYABLE_EXCEPTIONS as error:
            last_response = None
            last_error = error
            continue

        if not should_retry_response(response):
            return response
        last_response = response
        last_error = None


async def _sleep_before_retry_deadline(
    delay: float, jitter: float, deadline: float
) -> bool:
    remaining = deadline - time.monotonic()
    if remaining <= 0.0:
        return False
    factor = 1 + random.uniform(0, max(0, jitter))
    sleep_seconds = min(max(0.0, delay * factor), remaining)
    if sleep_seconds > 0.0:
        await asyncio.sleep(sleep_seconds)
    return time.monotonic() < deadline


async def _sleep(delay: float, jitter: float) -> None:
    if delay <= 0:
        return
    factor = 1 + random.uniform(0, max(0, jitter))
    await asyncio.sleep(delay * factor)
