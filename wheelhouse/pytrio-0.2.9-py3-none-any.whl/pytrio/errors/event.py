"""定义 Actor 事件执行与轮询错误。"""

from pytrio.errors.base import EMPTY_ERROR_DETAILS, PyTrioError


class EventError(PyTrioError):
    """Actor 训练事件错误基类。"""

    def __init__(
        self,
        message: str,
        *,
        code: str = "event.error",
        hint: str = "",
        details: dict[str, object] = EMPTY_ERROR_DETAILS,
        status_code: int = 0,
        retryable: bool = False,
        operation: str = "",
        request_id: str = "",
        task_cuid: str = "",
        event_cuid: str = "",
        actor_cuid: str = "",
    ) -> None:
        super().__init__(
            message,
            code=code,
            hint=hint,
            details=details,
            source="event",
            status_code=status_code,
            retryable=retryable,
            operation=operation,
            request_id=request_id,
            task_cuid=task_cuid,
            event_cuid=event_cuid,
            actor_cuid=actor_cuid,
        )


class EventPollingError(EventError):
    """事件在允许的轮询次数内没有到达终态。"""

    def __init__(
        self,
        event_cuid: str,
        message: str,
        *,
        details: dict[str, object] = EMPTY_ERROR_DETAILS,
    ) -> None:
        super().__init__(
            f"Polling event {event_cuid} failed: {message}",
            code="event.polling_failed",
            details=details,
            operation="actor.event.poll",
            event_cuid=event_cuid,
        )
        self.event_cuid: str = event_cuid


class EventFailedError(EventError):
    """Actor 事件以失败终态结束。"""

    def __init__(
        self,
        event_cuid: str,
        code: str,
        message: str,
        *,
        task_cuid: str = "",
    ) -> None:
        super().__init__(
            message,
            code=code,
            operation="actor.event.result",
            event_cuid=event_cuid,
            task_cuid=task_cuid,
        )
        self.event_cuid: str = event_cuid
        self.event_message: str = message
