"""定义 Actor 调用产生的领域错误。"""

from pytrio.errors.base import EMPTY_ERROR_DETAILS, PyTrioError


class ActorError(PyTrioError):
    """Actor 领域错误基类。"""

    def __init__(
        self,
        message: str,
        *,
        code: str = "actor.error",
        hint: str = "",
        details: dict[str, object] = EMPTY_ERROR_DETAILS,
        status_code: int = 0,
        retryable: bool = False,
        operation: str = "",
        server: str = "",
        request_id: str = "",
        task_cuid: str = "",
        event_cuid: str = "",
        actor_cuid: str = "",
    ):
        super().__init__(
            message,
            code=code,
            hint=hint,
            details=details,
            source="actor",
            status_code=status_code,
            retryable=retryable,
            operation=operation,
            server=server,
            request_id=request_id,
            task_cuid=task_cuid,
            event_cuid=event_cuid,
            actor_cuid=actor_cuid,
        )


class ActorAPIError(ActorError):
    """Actor HTTP API 返回的结构化错误。"""

    def __init__(
        self,
        message: str,
        *,
        status_code: int = 0,
        code: str = "actor.request_failed",
        details: dict[str, object] = EMPTY_ERROR_DETAILS,
        hint: str = "",
        retryable: bool = False,
        operation: str = "",
        server: str = "",
        request_id: str = "",
        actor_cuid: str = "",
        event_cuid: str = "",
    ):
        super().__init__(
            message,
            code=code or "actor.request_failed",
            details=details,
            hint=hint,
            status_code=status_code,
            retryable=retryable,
            operation=operation,
            server=server,
            request_id=request_id,
            actor_cuid=actor_cuid,
            event_cuid=event_cuid,
        )


class ActorEventSubmitError(ActorAPIError):
    """Actor 拒绝或无法接收事件的错误。"""

    def __init__(
        self,
        message: str,
        *,
        status_code: int = 0,
        code: str = "actor.request_failed",
        details: dict[str, object] = EMPTY_ERROR_DETAILS,
        hint: str = "",
        retryable: bool = False,
        operation: str = "actor.event.submit",
        server: str = "",
        request_id: str = "",
        actor_cuid: str = "",
        event_cuid: str = "",
    ):
        super().__init__(
            message,
            status_code=status_code,
            code=code,
            details=details,
            hint=hint,
            retryable=retryable,
            operation=operation,
            server=server,
            request_id=request_id,
            actor_cuid=actor_cuid,
            event_cuid=event_cuid,
        )


class ActorEventGetError(ActorAPIError):
    """Actor 事件状态查询失败错误。"""

    def __init__(
        self,
        message: str,
        *,
        status_code: int = 0,
        code: str = "actor.request_failed",
        details: dict[str, object] = EMPTY_ERROR_DETAILS,
        hint: str = "",
        retryable: bool = False,
        operation: str = "actor.event.get",
        server: str = "",
        request_id: str = "",
        actor_cuid: str = "",
        event_cuid: str = "",
    ):
        super().__init__(
            message,
            status_code=status_code,
            code=code,
            details=details,
            hint=hint,
            retryable=retryable,
            operation=operation,
            server=server,
            request_id=request_id,
            actor_cuid=actor_cuid,
            event_cuid=event_cuid,
        )
