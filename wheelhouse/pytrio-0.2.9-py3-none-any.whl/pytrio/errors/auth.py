"""定义认证流程产生的领域错误。"""

from pytrio.errors.base import EMPTY_ERROR_DETAILS, PyTrioError


class AuthError(PyTrioError):
    """SDK 认证和凭据配置错误。"""

    def __init__(
        self,
        message: str,
        *,
        code: str = "auth.failed",
        hint: str = "",
        details: dict[str, object] = EMPTY_ERROR_DETAILS,
        status_code: int = 0,
        retryable: bool = False,
        operation: str = "",
        server: str = "",
        request_id: str = "",
        task_cuid: str = "",
        event_cuid: str = "",
        actor_cuid: str = "",
    ):
        super().__init__(
            message,
            code=code,
            hint=hint,
            details=details,
            source="auth",
            status_code=status_code,
            retryable=retryable,
            operation=operation,
            server=server,
            request_id=request_id,
            task_cuid=task_cuid,
            event_cuid=event_cuid,
            actor_cuid=actor_cuid,
        )
