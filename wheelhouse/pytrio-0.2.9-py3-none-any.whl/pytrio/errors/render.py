"""将结构化 SDK 错误渲染为用户消息。"""

from __future__ import annotations

from pytrio.errors.base import PyTrioError


def render_error(error: BaseException, *, prefix: str = "") -> str:
    """将异常渲染为完整的终端文本。

    Args:
        error: 待呈现的异常。
        prefix: 每一输出行使用的前缀。

    Returns:
        可直接写入日志或终端的多行文本。
    """
    if not isinstance(error, PyTrioError):
        return prefix + str(error)

    lines = [prefix + "[Error] " + error.message]
    if error.hint:
        lines.append(prefix + "[Hint] " + error.hint)
    source = error.source
    if error.server:
        source = f"{source}({error.server})" if source else error.server
    request = " -> ".join(value for value in (error.operation, source) if value)
    if request:
        lines.append(prefix + "[Request] " + request)
    context = [
        value
        for value in (
            error.request_id,
            error.task_cuid,
            error.actor_cuid,
            error.event_cuid,
        )
        if value
    ]
    if context:
        lines.append(prefix + "[Context] " + ", ".join(context))
    if error.details:
        lines.append(prefix + "[Details] " + repr(error.details))
    return "\n".join(lines)
