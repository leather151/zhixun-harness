"""定义 Control 调用与兼容性检查错误。"""

from pytrio.errors.base import EMPTY_ERROR_DETAILS, PyTrioError


class ControlError(PyTrioError):
    """Control 领域错误基类。"""


class SDKCompatibilityError(ControlError):
    """Control 兼容性策略阻止当前 SDK 版本运行。"""

    def __init__(
        self,
        message: str,
        *,
        details: dict[str, object] = EMPTY_ERROR_DETAILS,
        hint: str = "",
        operation: str = "sdk.bootstrap",
        server: str = "",
    ):
        super().__init__(
            message,
            code="sdk.compatibility_blocked",
            details=details,
            hint=hint,
            source="control",
            operation=operation,
            server=server,
        )


class ControlAPIError(ControlError):
    """Control HTTP API 返回的结构化错误。"""

    def __init__(
        self,
        message: str,
        *,
        status_code: int = 0,
        code: str = "control.request_failed",
        details: dict[str, object] = EMPTY_ERROR_DETAILS,
        hint: str = "",
        retryable: bool = False,
        operation: str = "",
        server: str = "",
        request_id: str = "",
        task_cuid: str = "",
    ):
        super().__init__(
            message,
            code=code or "control.request_failed",
            details=details,
            hint=hint,
            source="control",
            status_code=status_code,
            retryable=retryable,
            operation=operation,
            server=server,
            request_id=request_id,
            task_cuid=task_cuid,
        )
