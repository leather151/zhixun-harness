"""定义协议和配置校验错误。"""

from pytrio.errors.base import EMPTY_ERROR_DETAILS, PyTrioError


class ProtocolError(PyTrioError):
    """服务端响应或 wire 数据违反协议契约。"""


class PyTrioProtocolError(ProtocolError):
    """Control 与 Actor 正式协议错误基类。"""


class PayloadSchemaNotFinalizedError(PyTrioProtocolError):
    """服务端载荷 schema 尚未确定时由占位 builder 抛出的错误。"""


class ConfigurationError(PyTrioError):
    """SDK 配置值违反领域约束。"""

    def __init__(
        self,
        message: str,
        *,
        code: str = "configuration.error",
        hint: str = "",
        details: dict[str, object] = EMPTY_ERROR_DETAILS,
        status_code: int = 0,
        retryable: bool = False,
        operation: str = "",
        server: str = "",
        request_id: str = "",
        task_cuid: str = "",
        event_cuid: str = "",
        actor_cuid: str = "",
    ):
        super().__init__(
            message,
            code=code,
            hint=hint,
            details=details,
            source="sdk",
            status_code=status_code,
            retryable=retryable,
            operation=operation,
            server=server,
            request_id=request_id,
            task_cuid=task_cuid,
            event_cuid=event_cuid,
            actor_cuid=actor_cuid,
        )
