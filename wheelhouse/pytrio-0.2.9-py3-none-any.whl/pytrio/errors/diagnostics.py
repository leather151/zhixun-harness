"""将 SDK 错误转换为结构化诊断信息。"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Diagnostic:
    """面向用户呈现的结构化错误诊断。"""

    hint: str = ""
    retryable: bool = False


_KNOWN_CODES: dict[str, Diagnostic] = {
    "billing_insufficient_balance": Diagnostic(
        hint=(
            "Your workspace balance is insufficient or overdue. Add credits or "
            "ask a workspace admin to resolve billing before retrying."
        ),
        retryable=False,
    ),
    "too_many_requests": Diagnostic(
        hint=(
            "The service is busy or rate limited. Retry after a short delay "
            "or reduce concurrency."
        ),
        retryable=True,
    ),
    "actor_capacity_exceeded": Diagnostic(
        hint=(
            "Server remained at capacity until the wait timeout. Retry later "
            "or increase actor_capacity_wait_timeout_seconds to wait longer."
        ),
        retryable=True,
    ),
    "service_unavailable": Diagnostic(
        hint="A Trio service dependency is temporarily unavailable. Retry later.",
        retryable=True,
    ),
    "auth_service_unavailable": Diagnostic(
        hint="Authentication is temporarily unavailable. Retry later.",
        retryable=True,
    ),
    "no_available_actor": Diagnostic(
        hint="No available runner for this model. Retry later or choose another supported model.",
        retryable=True,
    ),
    "model_not_found": Diagnostic(
        hint=(
            "The requested model is not published or not visible to this workspace. "
            "Choose a supported model and retry."
        ),
        retryable=False,
    ),
    "api_key_expired": Diagnostic(
        hint="Create or use a non-expired API key, then retry.",
        retryable=False,
    ),
    "api_key_revoked": Diagnostic(
        hint="This API key was revoked. Create or use another API key.",
        retryable=False,
    ),
    "api_key_disabled": Diagnostic(
        hint=(
            "This API key was disabled. Ask a workspace admin to enable it or "
            "create another key."
        ),
        retryable=False,
    ),
    "unauthorized": Diagnostic(
        hint="Make sure your API key is valid and has access to this Trio environment.",
        retryable=False,
    ),
    "forbidden": Diagnostic(
        hint="The credentials are valid but do not have permission for this operation.",
        retryable=False,
    ),
    "validation_failed": Diagnostic(
        hint="Check the request arguments and retry with valid values.",
        retryable=False,
    ),
    "checkpoint_invalid_type": Diagnostic(
        hint=(
            "The checkpoint type does not match the requested run type. Use "
            "Train checkpoints for training. Sampling accepts compatible Train "
            "or Sampler checkpoints."
        ),
        retryable=False,
    ),
    "invalid_request_body": Diagnostic(
        hint="The request body could not be parsed. Check the SDK version and request payload.",
        retryable=False,
    ),
    "invalid_query_params": Diagnostic(
        hint="Check the query parameters and retry with valid values.",
        retryable=False,
    ),
    "invalid_path_params": Diagnostic(
        hint="Check the resource identifier in the request path.",
        retryable=False,
    ),
    "actor_disabled": Diagnostic(
        hint="The selected compute actor was disabled. Retry later or contact support.",
        retryable=True,
    ),
    "runner_disabled": Diagnostic(
        hint="The selected runner was disabled. Retry later or contact support.",
        retryable=True,
    ),
    "internal_error": Diagnostic(
        hint=(
            "The service hit an internal error. Retry if it is safe; include "
            "the code and task or event id when contacting support."
        ),
        retryable=True,
    ),
    "unknown": Diagnostic(
        hint=(
            "The service returned an unknown error. Include the code and task "
            "or event id when contacting support."
        ),
        retryable=True,
    ),
    "database_error": Diagnostic(
        hint="The service hit a storage error. Retry later.",
        retryable=True,
    ),
    "control.request_failed": Diagnostic(
        hint=(
            "The Control request failed after retries. Check network "
            "connectivity and the configured base URL."
        ),
        retryable=True,
    ),
    "actor.request_failed": Diagnostic(
        hint="The Actor request failed after retries. Retry later or check network connectivity.",
        retryable=True,
    ),
    "training.run_broken": Diagnostic(
        hint=(
            "The training run coordinator is no longer safe to use. Create a "
            "new training client and retry."
        ),
        retryable=False,
    ),
    "training.run_loop_mismatch": Diagnostic(
        hint=(
            "SDK internals crossed event loops. This should not happen in "
            "normal use; please report the issue."
        ),
        retryable=False,
    ),
    "sampling.run_loop_mismatch": Diagnostic(
        hint=(
            "SDK internals crossed event loops. This should not happen in "
            "normal use; please report the issue."
        ),
        retryable=False,
    ),
}

_RETRYABLE_STATUS_CODES = {408, 429, 500, 502, 503, 504}


def diagnose(
    *,
    code: str = "",
    status_code: int = 0,
    source: str = "",
) -> Diagnostic:
    """根据稳定错误码或 HTTP 状态推导用户提示和可重试性。

    Args:
        code: SDK 或服务端稳定错误码。
        status_code: HTTP 状态码；非 HTTP 错误使用 ``0``。
        source: 错误来源，用于生成对应服务提示。

    Returns:
        最精确可用的诊断规则；未知错误返回空诊断。
    """
    normalized = code.strip()
    # 精确错误码拥有最高优先级；领域前缀为新错误码提供统一行为，HTTP 状态规则处理
    # 服务端未返回稳定错误码的情况。
    known = _KNOWN_CODES.get(normalized)
    if known:
        return known

    if normalized.startswith("validation."):
        return Diagnostic(
            hint="Check the SDK method arguments and retry with valid values.",
            retryable=False,
        )
    if normalized.startswith("auth."):
        return Diagnostic(
            hint="Check authentication configuration and retry with valid credentials.",
            retryable=False,
        )
    if normalized.startswith("dependency."):
        return Diagnostic(
            hint="Install the missing optional dependency, then retry.",
            retryable=False,
        )

    service = "Trio"
    if source == "control":
        service = "Trio Control"
    elif source == "actor":
        service = "Trio Actor"

    hint = ""
    if status_code == 0:
        return Diagnostic()
    if status_code == 400:
        hint = "Check the request arguments and retry with valid values."
    elif status_code == 401:
        hint = "Check that your API key or session credential is valid."
    elif status_code == 403:
        hint = "The credential is valid but lacks permission for this operation."
    elif status_code == 404:
        hint = "The requested resource was not found or is not accessible."
    elif status_code == 408:
        hint = f"{service} timed out while handling the request. Retry later."
    elif status_code == 409:
        hint = "The resource is in a conflicting state. Refresh the resource state before retrying."
    elif status_code == 429:
        hint = (
            "The service is rate limited or busy. Retry after a short delay or "
            "reduce concurrency."
        )
    elif 500 <= status_code <= 599:
        hint = f"{service} hit a temporary service error. Retry later."

    return Diagnostic(
        hint=hint,
        retryable=status_code in _RETRYABLE_STATUS_CODES,
    )
