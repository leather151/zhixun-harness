"""定义 SDK 错误基类与公共错误属性。"""

from pytrio.errors.diagnostics import diagnose

EMPTY_ERROR_DETAILS: dict[str, object] = {}


class PyTrioError(Exception):
    """携带稳定错误码、操作上下文和诊断字段的 SDK 错误基类。

    Args:
        message: 面向用户的错误摘要。
        code: 可供程序判断的稳定错误码。
        hint: 解决建议；空值时从诊断规则推导。
        details: 服务端或校验器提供的结构化详情。
        source: ``control``、``actor`` 或其他错误来源。
        status_code: HTTP 状态码。
        retryable: 调用方是否可以安全重试。
        operation: 失败的逻辑操作或 HTTP method/path。
        server: 失败请求的服务端地址。
        request_id: 服务端请求追踪 ID。
        task_cuid: 关联训练或采样任务 ID。
        event_cuid: 关联 Actor 事件 ID。
        actor_cuid: 关联 Actor ID。
    """

    def __init__(
        self,
        message: str,
        *,
        code: str = "pytrio.error",
        hint: str = "",
        details: dict[str, object] = EMPTY_ERROR_DETAILS,
        source: str = "",
        status_code: int = 0,
        retryable: bool = False,
        operation: str = "",
        server: str = "",
        request_id: str = "",
        task_cuid: str = "",
        event_cuid: str = "",
        actor_cuid: str = "",
    ) -> None:
        self.message: str = str(message)
        self.code: str = str(code or "pytrio.error")
        self.details: dict[str, object] = dict(details)
        self.source: str = source
        self.status_code: int = status_code
        self.operation: str = operation

        self.server: str = server
        self.request_id: str = request_id
        self.task_cuid: str = task_cuid
        self.event_cuid: str = event_cuid
        self.actor_cuid: str = actor_cuid

        diagnostic = diagnose(
            code=self.code,
            status_code=status_code,
            source=source,
        )
        self.hint: str = hint or diagnostic.hint
        self.retryable: bool = retryable or diagnostic.retryable

        super().__init__(self.message)

    def __str__(self) -> str:
        parts = [self.message]
        if self.hint:
            parts.append(f"Hint: {self.hint}")

        source = self.source
        if self.server:
            source = f"{source}({self.server})" if source else self.server
        request = " -> ".join(value for value in (self.operation, source) if value)
        if request:
            parts.append(f"Request: {request}")
        context = [
            value
            for value in (
                self.request_id,
                self.task_cuid,
                self.actor_cuid,
                self.event_cuid,
            )
            if value
        ]
        if context:
            parts.append(f"Context: {', '.join(context)}")
        if self.details:
            parts.append(f"Details: {self.details!r}")
        return " | ".join(parts)

    def diagnostic_fields(self) -> dict[str, object]:
        """返回适合结构化日志记录的非空诊断字段。"""
        fields: dict[str, object] = {
            "message": self.message,
            "code": self.code,
        }
        optional_fields: dict[str, object] = {
            "hint": self.hint,
            "source": self.source,
            "operation": self.operation,
            "server": self.server,
            "request_id": self.request_id,
            "task_cuid": self.task_cuid,
            "event_cuid": self.event_cuid,
            "actor_cuid": self.actor_cuid,
            "details": self.details,
        }
        for key, value in optional_fields.items():
            if value and value != {}:
                fields[key] = value
        if self.status_code > 0:
            fields["status_code"] = self.status_code
        fields["retryable"] = self.retryable
        return fields


class ValidationError(PyTrioError):
    """用户输入不满足 SDK 领域约束。"""

    def __init__(
        self,
        message: str,
        *,
        code: str = "validation.failed",
        hint: str = "",
        details: dict[str, object] = EMPTY_ERROR_DETAILS,
        status_code: int = 0,
        retryable: bool = False,
        operation: str = "",
        server: str = "",
        request_id: str = "",
        task_cuid: str = "",
        event_cuid: str = "",
        actor_cuid: str = "",
    ):
        super().__init__(
            message,
            code=code,
            hint=hint,
            details=details,
            source="sdk",
            status_code=status_code,
            retryable=retryable,
            operation=operation,
            server=server,
            request_id=request_id,
            task_cuid=task_cuid,
            event_cuid=event_cuid,
            actor_cuid=actor_cuid,
        )


class DependencyError(PyTrioError):
    """可选运行时依赖缺失或不可用。"""

    def __init__(
        self,
        message: str,
        *,
        code: str = "dependency.missing",
        hint: str = "",
        details: dict[str, object] = EMPTY_ERROR_DETAILS,
        status_code: int = 0,
        retryable: bool = False,
        operation: str = "",
        server: str = "",
        request_id: str = "",
        task_cuid: str = "",
        event_cuid: str = "",
        actor_cuid: str = "",
    ):
        super().__init__(
            message,
            code=code,
            hint=hint,
            details=details,
            source="sdk",
            status_code=status_code,
            retryable=retryable,
            operation=operation,
            server=server,
            request_id=request_id,
            task_cuid=task_cuid,
            event_cuid=event_cuid,
            actor_cuid=actor_cuid,
        )
