"""格式化并输出 SDK 日志与错误消息。"""

from __future__ import annotations

import logging
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Literal, TypeAlias

import click

from pytrio.errors.render import render_error

LogLevel: TypeAlias = Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
LogFieldValue: TypeAlias = str | int | float | bool


@dataclass(frozen=True)
class LogField:
    """用户日志中的标签和值。"""

    label: str
    value: LogFieldValue


LogFields: TypeAlias = Sequence[LogField]

EMPTY_LOG_FIELDS: LogFields = ()
LOG_RECORD_FIELDS_ATTR = "trio_fields"
LOG_RECORD_HINT_ATTR = "trio_hint"
LOG_LINE_PREFIX = "trio: "

_LEVEL_COLORS: Mapping[str, str] = {
    "DEBUG": "cyan",
    "INFO": "blue",
    "WARNING": "yellow",
    "ERROR": "red",
    "CRITICAL": "bright_red",
}

_LEVEL_NUMBERS: Mapping[LogLevel, int] = {
    "DEBUG": logging.DEBUG,
    "INFO": logging.INFO,
    "WARNING": logging.WARNING,
    "ERROR": logging.ERROR,
    "CRITICAL": logging.CRITICAL,
}


def level_color(level: str) -> str:
    return _LEVEL_COLORS.get(level.upper(), "blue")


def _normalize_level(level: str) -> LogLevel:
    normalized = level.upper()
    if normalized == "DEBUG":
        return "DEBUG"
    if normalized == "WARNING":
        return "WARNING"
    if normalized == "ERROR":
        return "ERROR"
    if normalized == "CRITICAL":
        return "CRITICAL"
    return "INFO"


def strict_log_level(level: str) -> LogLevel:
    normalized = level.upper()
    if normalized == "DEBUG":
        return "DEBUG"
    if normalized == "INFO":
        return "INFO"
    if normalized == "WARNING":
        return "WARNING"
    if normalized == "ERROR":
        return "ERROR"
    if normalized == "CRITICAL":
        return "CRITICAL"
    raise ValueError(f"Unsupported log level: {level}")


def is_stderr_level(level: str) -> bool:
    return _LEVEL_NUMBERS[_normalize_level(level)] >= logging.WARNING


def _format_prefixed_line(text: str, *, level: str) -> str:
    color = level_color(level)
    return click.style(LOG_LINE_PREFIX, fg=color, bold=True) + click.style(
        text,
        fg=color,
    )


def _format_continuation_line(text: str, *, level: str) -> str:
    color = level_color(level)
    return click.style(" " * len(LOG_LINE_PREFIX), fg=color, bold=True) + click.style(
        text,
        fg=color,
    )


def _format_fields(fields: LogFields, *, level: str) -> str:
    rendered_fields: list[str] = []
    for field in fields:
        if isinstance(field.value, str) and not field.value:
            continue
        rendered_fields.append(f"{field.label}={field.value}")
    if not rendered_fields:
        return ""
    return _format_continuation_line(", ".join(rendered_fields), level=level)


def format_log_message(
    message: str,
    *,
    level: str = "INFO",
    fields: LogFields = EMPTY_LOG_FIELDS,
    hint: str = "",
) -> str:
    rendered_lines = [_format_prefixed_line(message, level=level)]
    if hint:
        rendered_lines.append(_format_continuation_line(f"Hint: {hint}", level=level))
    rendered_fields = _format_fields(fields, level=level)
    if rendered_fields:
        rendered_lines.append(rendered_fields)
    return "\n".join(rendered_lines)


def emit(
    level: LogLevel,
    message: str,
    *,
    fields: LogFields = EMPTY_LOG_FIELDS,
    hint: str = "",
) -> None:
    click.echo(
        format_log_message(message, level=level, fields=fields, hint=hint),
        err=is_stderr_level(level),
    )


def log_user_message(
    logger: logging.Logger,
    level: LogLevel,
    message: str,
    *,
    fields: LogFields = EMPTY_LOG_FIELDS,
    hint: str = "",
) -> None:
    logger.log(
        _LEVEL_NUMBERS[level],
        message,
        extra={
            LOG_RECORD_FIELDS_ATTR: fields,
            LOG_RECORD_HINT_ATTR: hint,
        },
    )


PROMPT_PREFIX = click.style("trio: ", fg=level_color("INFO"), bold=True)


def format_error(error: BaseException) -> str:
    rendered_error = render_error(error, prefix="trio: ")
    rendered_lines: list[str] = []
    prefix = "trio: "
    for line in rendered_error.splitlines():
        if line.startswith(prefix):
            rendered_lines.append(
                _format_prefixed_line(line[len(prefix) :], level="ERROR")
            )
        else:
            rendered_lines.append(click.style(line, fg=level_color("ERROR")))
    return "\n".join(rendered_lines)


def log_message(message: str) -> None:
    emit("INFO", message)


def log_error(error: BaseException) -> None:
    click.echo(format_error(error), err=True)
