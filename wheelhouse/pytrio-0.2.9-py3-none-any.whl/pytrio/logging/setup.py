"""配置 SDK 日志级别、处理器和输出格式。"""

import logging
from collections.abc import Mapping
from pathlib import Path
from typing import cast

import click

from pytrio.config.config import configuration
from pytrio.logging.render import (
    EMPTY_LOG_FIELDS,
    LOG_RECORD_FIELDS_ATTR,
    LOG_RECORD_HINT_ATTR,
    LogFields,
    LogLevel,
    format_log_message,
    is_stderr_level,
)

logger: logging.Logger = logging.getLogger("pytrio")
_LOG_LEVEL_VALUES: dict[LogLevel, int] = {
    "DEBUG": logging.DEBUG,
    "INFO": logging.INFO,
    "WARNING": logging.WARNING,
    "ERROR": logging.ERROR,
    "CRITICAL": logging.CRITICAL,
}


class TrioConsoleHandler(logging.Handler):
    """使用 Trio CLI 前缀呈现面向用户的 SDK 日志。"""

    def __init__(self, *, level: int = logging.INFO):
        super().__init__(level=level)
        self.setFormatter(logging.Formatter("%(message)s"))

    def emit(self, record: logging.LogRecord) -> None:
        try:
            message = self.format(record)
            record_attributes: Mapping[str, object] = vars(record)
            fields = cast(
                LogFields,
                record_attributes.get(LOG_RECORD_FIELDS_ATTR, EMPTY_LOG_FIELDS),
            )
            hint = cast(str, record_attributes.get(LOG_RECORD_HINT_ATTR, ""))
            click.echo(
                format_log_message(
                    message,
                    level=record.levelname,
                    fields=fields,
                    hint=hint,
                ),
                err=is_stderr_level(record.levelname),
            )
        except Exception:  # noqa: BLE001 - logging handlers must contain emit failures
            self.handleError(record)


def setup_logging() -> None:
    """安装 SDK 默认的用户控制台日志处理器。"""
    logger_level = _LOG_LEVEL_VALUES[configuration.log_level]
    logger.setLevel(logger_level)
    logger.propagate = False
    console_handler_level = logger_level
    console_handlers = [
        handler
        for handler in logger.handlers
        if isinstance(handler, TrioConsoleHandler)
    ]
    if console_handlers:
        for handler in console_handlers:
            handler.setLevel(console_handler_level)
        return
    logger.addHandler(TrioConsoleHandler(level=console_handler_level))


def configure_error_file_logging(
    path: str | Path | None = None, *, level: int = logging.ERROR
) -> None:
    """为应用显式启用 SDK 错误文件日志。"""
    setup_logging()
    log_path = Path(path) if path is not None else configuration.error_log_path
    log_path.parent.mkdir(parents=True, exist_ok=True)
    resolved = str(log_path)
    for handler in logger.handlers:
        if (
            isinstance(handler, logging.FileHandler)
            and handler.baseFilename == resolved
        ):
            return

    formatter = logging.Formatter(
        "trio: [%(asctime)s - %(name)s:%(lineno)d - %(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    error_file_handler = logging.FileHandler(resolved, mode="a", encoding="utf-8")
    error_file_handler.setLevel(level)
    error_file_handler.setFormatter(formatter)
    logger.addHandler(error_file_handler)
