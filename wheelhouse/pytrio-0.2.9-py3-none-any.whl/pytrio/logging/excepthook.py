"""安装面向终端用户的未捕获异常呈现器。"""

from __future__ import annotations

import sys
from types import TracebackType

from pytrio.errors.base import PyTrioError
from pytrio.logging.render import log_error
from pytrio.runtime.service import cancel_active_service_runtimes

_previous_excepthook = sys.__excepthook__


def pytrio_excepthook(
    exc_type: type[BaseException],
    exc: BaseException,
    traceback: TracebackType,
) -> None:
    if isinstance(exc, KeyboardInterrupt):
        cancel_active_service_runtimes()
    if isinstance(exc, PyTrioError):
        _previous_excepthook(exc_type, exc, traceback)
        sys.stderr.write("\n")
        log_error(exc)
        return
    _previous_excepthook(exc_type, exc, traceback)


def install_pretty_excepthook() -> None:
    global _previous_excepthook

    current_hook = sys.excepthook
    if current_hook is pytrio_excepthook:
        return
    if current_hook is not sys.__excepthook__:
        return

    _previous_excepthook = current_hook
    sys.excepthook = pytrio_excepthook
