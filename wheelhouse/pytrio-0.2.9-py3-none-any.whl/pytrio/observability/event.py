"""Encode lightweight operation records for the fixed telemetry HTTP contract."""

from __future__ import annotations

import json
import math
import platform
import secrets
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import TypeAlias

from pytrio._version import __version__

SERVICE_NAME = "pytrio-sdk"
SCHEMA_VERSION = 1
MAX_ATTRIBUTE_STRING_LENGTH = 2_048

TelemetryScalar: TypeAlias = str | int | float | bool


@dataclass(frozen=True, slots=True)
class OperationRecord:
    """One immutable operation snapshot queued by a business thread."""

    operation: str
    status: str
    attributes: Mapping[str, TelemetryScalar]
    recorded_at: datetime


@dataclass(frozen=True, slots=True)
class RuntimeMetadata:
    sdk_version: str
    python_version: str
    python_implementation: str
    os_type: str
    os_release: str
    arch: str

    def as_dict(self) -> dict[str, str]:
        return {
            "sdk_version": self.sdk_version,
            "python_version": self.python_version,
            "python_implementation": self.python_implementation,
            "os_type": self.os_type,
            "os_release": self.os_release,
            "arch": self.arch,
        }


def runtime_metadata() -> RuntimeMetadata:
    return RuntimeMetadata(
        sdk_version=__version__,
        python_version=platform.python_version(),
        python_implementation=platform.python_implementation(),
        os_type=platform.system().lower() or "unknown",
        os_release=platform.release(),
        arch=platform.machine(),
    )


class TelemetryBatchEncoder:
    """Serialize records to the established ``/api/telemetry/event`` body."""

    def __init__(
        self,
        *,
        user_cuid: str,
        workspace_cuid: str,
        runtime: RuntimeMetadata,
    ) -> None:
        self._user_cuid: str = user_cuid
        self._workspace_cuid: str = workspace_cuid
        self._runtime: RuntimeMetadata = runtime

    def encode(self, records: list[OperationRecord]) -> bytes:
        runtime_payload = self._runtime.as_dict()
        events: list[dict[str, object]] = []
        for record in records:
            attributes = _safe_attributes(record.attributes)
            event: dict[str, object] = {
                "schema_version": SCHEMA_VERSION,
                "event_id": secrets.token_hex(16),
                "event_type": "operation",
                "service_name": SERVICE_NAME,
                "operation": record.operation,
                "status": record.status or "ok",
                "timestamp": _to_iso(record.recorded_at),
                "user_cuid": self._user_cuid,
                "workspace_cuid": self._workspace_cuid,
                "runtime": runtime_payload,
                "attributes": attributes,
            }
            duration_ms = attributes.get("duration_ms")
            if isinstance(duration_ms, int) and not isinstance(duration_ms, bool):
                event["duration_ms"] = duration_ms
            error_type = attributes.get("error")
            if record.status != "ok" or isinstance(error_type, str):
                retryable = attributes.get("error.retryable")
                event["error"] = {
                    "type": error_type if isinstance(error_type, str) else "",
                    "message": _string_attribute(attributes, "error.message"),
                    "code": _string_attribute(attributes, "error.code"),
                    "server": _string_attribute(attributes, "error.server"),
                    "retryable": retryable if isinstance(retryable, bool) else None,
                }
            events.append(event)

        payload: dict[str, object] = {
            "schema_version": SCHEMA_VERSION,
            "service_name": SERVICE_NAME,
            "user_cuid": self._user_cuid,
            "workspace_cuid": self._workspace_cuid,
            "runtime": runtime_payload,
            "events": events,
        }
        return json.dumps(
            payload,
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode("utf-8")


def validate_encoded_batch(payload: bytes, *, workspace_cuid: str) -> bool:
    """Validate the stable batch envelope before replaying local bytes."""

    try:
        decoded: object = json.loads(payload, parse_constant=_reject_json_constant)
    except (UnicodeError, ValueError):
        return False
    if not isinstance(decoded, dict):
        return False
    if decoded.get("schema_version") != SCHEMA_VERSION:
        return False
    if decoded.get("service_name") != SERVICE_NAME:
        return False
    user_cuid = decoded.get("user_cuid")
    if not isinstance(user_cuid, str) or not user_cuid:
        return False
    if decoded.get("workspace_cuid") != workspace_cuid:
        return False
    if not isinstance(decoded.get("runtime"), dict):
        return False
    events = decoded.get("events")
    if not isinstance(events, list):
        return False
    return all(
        isinstance(event, dict)
        and event.get("schema_version") == SCHEMA_VERSION
        and event.get("service_name") == SERVICE_NAME
        and event.get("user_cuid") == user_cuid
        and event.get("workspace_cuid") == workspace_cuid
        for event in events
    )


def _safe_attributes(
    values: Mapping[str, TelemetryScalar],
) -> dict[str, TelemetryScalar]:
    safe: dict[str, TelemetryScalar] = {}
    for key, value in values.items():
        if isinstance(value, str):
            safe[key] = value[:MAX_ATTRIBUTE_STRING_LENGTH]
        elif isinstance(value, bool | int) or math.isfinite(value):
            safe[key] = value
    return safe


def _string_attribute(
    attributes: Mapping[str, TelemetryScalar],
    key: str,
) -> str:
    value = attributes.get(key)
    return value if isinstance(value, str) else ""


def _to_iso(value: datetime) -> str:
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _reject_json_constant(value: str) -> object:
    raise ValueError(f"invalid JSON constant: {value}")
