"""Lightweight SDK observability events."""
