"""HTTP delivery for the fixed Trio telemetry endpoint."""

from __future__ import annotations

from dataclasses import dataclass

import httpx

TELEMETRY_EVENT_PATH = "/api/telemetry/event"
MAX_DELIVERY_ERROR_LENGTH = 512


@dataclass(frozen=True, slots=True)
class SendResult:
    ok: bool
    retryable: bool = False
    retry_after_seconds: int = 0
    error: str = ""
    status_code: int = 0


class TelemetryTransport:
    """Send already encoded batches without interpreting their event fields."""

    def __init__(self, *, base_url: str, api_key: str) -> None:
        self._client: httpx.AsyncClient = httpx.AsyncClient(timeout=2.0)
        self._url: str = f"{base_url.rstrip('/')}{TELEMETRY_EVENT_PATH}"
        self._headers: dict[str, str] = {
            "X-API-Key": api_key,
            "Authorization": f"Bearer {api_key}",
            "content-type": "application/json",
        }

    async def send(self, payload: bytes) -> SendResult:
        try:
            response = await self._client.post(
                self._url,
                content=payload,
                headers=self._headers,
            )
        except httpx.HTTPError as exc:
            return SendResult(
                ok=False,
                retryable=True,
                error=str(exc)[:MAX_DELIVERY_ERROR_LENGTH],
            )
        if 200 <= response.status_code < 300:
            return SendResult(ok=True, status_code=response.status_code)
        retryable = response.status_code in {408, 425, 429} or (
            500 <= response.status_code < 600
        )
        return SendResult(
            ok=False,
            retryable=retryable,
            retry_after_seconds=_parse_retry_after(response.headers.get("Retry-After")),
            error=(f"HTTP {response.status_code}: {response.reason_phrase}")[
                :MAX_DELIVERY_ERROR_LENGTH
            ],
            status_code=response.status_code,
        )

    async def aclose(self) -> None:
        await self._client.aclose()


def _parse_retry_after(value: str | None) -> int:
    if value is None:
        return 0
    try:
        return max(0, int(value))
    except ValueError:
        return 0
