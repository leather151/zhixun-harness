"""Small emission interface shared by instrumented SDK components."""

from __future__ import annotations

from collections.abc import Mapping
from datetime import datetime
from typing import Protocol

from pytrio.observability.event import TelemetryScalar


class TelemetryEmitter(Protocol):
    """Non-blocking, no-throw telemetry boundary for business code."""

    def emit(
        self,
        operation: str,
        *,
        status: str = "ok",
        attributes: Mapping[str, TelemetryScalar] | None = None,
        now: datetime | None = None,
    ) -> None: ...

    def close(self) -> None: ...


class NoopTelemetryEmitter:
    def emit(
        self,
        operation: str,
        *,
        status: str = "ok",
        attributes: Mapping[str, TelemetryScalar] | None = None,
        now: datetime | None = None,
    ) -> None:
        return

    def close(self) -> None:
        return


NOOP_TELEMETRY_EMITTER = NoopTelemetryEmitter()
