"""Versioned, destination-scoped file spool for failed telemetry batches."""

from __future__ import annotations

import base64
import json
import logging
import math
import os
import secrets
import time
from dataclasses import dataclass
from pathlib import Path

from pytrio.observability.event import validate_encoded_batch

logger = logging.getLogger(__name__)

SPOOL_VERSION = 1
_CLAIM_SUFFIX = ".inflight"
_TEMP_SUFFIX = ".tmp"
_CLAIM_TTL_SECONDS = 5 * 60
_MAX_PAYLOAD_BYTES = 2 * 1024 * 1024
_MAX_ERROR_LENGTH = 512


@dataclass(frozen=True, slots=True)
class BufferedBatch:
    claimed_path: Path
    ready_path: Path
    payload: bytes
    attempts: int
    created_at: float


class TelemetryFileSpool:
    """Persist encoded request bodies without storing authentication secrets."""

    def __init__(
        self,
        *,
        root: Path,
        destination_key: str,
        workspace_cuid: str,
        max_disk_bytes: int,
        ttl_hours: int,
    ) -> None:
        self.root: Path = root
        self.destination_key: str = destination_key
        self.workspace_cuid: str = workspace_cuid
        self.max_disk_bytes: int = max(1, max_disk_bytes)
        self.ttl_seconds: int = max(1, ttl_hours) * 3600
        self.root.mkdir(mode=0o700, parents=True, exist_ok=True)
        os.chmod(self.root, 0o700)
        self._recover(time.time())
        self._prune()

    def put(
        self,
        *,
        payload: bytes,
        retry_after_seconds: int,
        last_error: str = "",
    ) -> Path:
        if not validate_encoded_batch(payload, workspace_cuid=self.workspace_cuid):
            raise ValueError("telemetry payload does not match the event contract")
        if len(payload) > _MAX_PAYLOAD_BYTES:
            raise ValueError("telemetry payload exceeds the local spool limit")
        now = time.time()
        path = self.root / f"{int(now * 1000)}-{secrets.token_hex(8)}.json"
        self._write_record(
            path,
            payload=payload,
            created_at=now,
            next_attempt_at=now + max(1, retry_after_seconds),
            attempts=0,
            last_error=last_error,
        )
        self._prune()
        return path

    def due(self, *, limit: int) -> list[BufferedBatch]:
        now = time.time()
        self._recover(now)
        batches: list[BufferedBatch] = []
        for ready_path in sorted(self.root.glob("*.json")):
            if len(batches) >= max(0, limit):
                break
            claimed_path = self._claim(ready_path, now)
            if claimed_path is None:
                continue
            batch = self._read_claim(claimed_path, ready_path, now)
            if batch is not None:
                batches.append(batch)
        return batches

    def mark_failed(
        self,
        batch: BufferedBatch,
        *,
        retry_after_seconds: int,
        last_error: str,
    ) -> None:
        now = time.time()
        self._write_record(
            batch.ready_path,
            payload=batch.payload,
            created_at=batch.created_at,
            next_attempt_at=now + max(1, retry_after_seconds),
            attempts=batch.attempts + 1,
            last_error=last_error,
        )
        self.delete(batch.claimed_path)
        self._prune()

    def delete(self, path: Path) -> None:
        try:
            path.unlink()
        except FileNotFoundError:
            pass

    def _read_claim(
        self,
        claimed_path: Path,
        ready_path: Path,
        now: float,
    ) -> BufferedBatch | None:
        record = self._read_object(claimed_path)
        if record is None:
            self.delete(claimed_path)
            return None
        version = _strict_int(record.get("spool_version"))
        destination_key = record.get("destination_key")
        created_at = _finite_number(record.get("created_at"))
        next_attempt_at = _finite_number(record.get("next_attempt_at"))
        attempts = _strict_int(record.get("attempts"))
        payload_text = record.get("payload_base64")
        if (
            version != SPOOL_VERSION
            or destination_key != self.destination_key
            or created_at is None
            or next_attempt_at is None
            or attempts is None
            or attempts < 0
            or not isinstance(payload_text, str)
        ):
            self.delete(claimed_path)
            return None
        if now - created_at > self.ttl_seconds:
            self.delete(claimed_path)
            return None
        if next_attempt_at > now:
            self._release_claim(claimed_path, ready_path)
            return None
        try:
            payload = base64.b64decode(payload_text, validate=True)
        except ValueError:
            self.delete(claimed_path)
            return None
        if len(payload) > _MAX_PAYLOAD_BYTES or not validate_encoded_batch(
            payload,
            workspace_cuid=self.workspace_cuid,
        ):
            self.delete(claimed_path)
            return None
        return BufferedBatch(
            claimed_path=claimed_path,
            ready_path=ready_path,
            payload=payload,
            attempts=attempts,
            created_at=created_at,
        )

    def _read_object(self, path: Path) -> dict[object, object] | None:
        try:
            decoded: object = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError):
            logger.debug("Discarding corrupt telemetry spool file %s", path)
            return None
        if not isinstance(decoded, dict):
            logger.debug("Discarding invalid telemetry spool file %s", path)
            return None
        return decoded

    def _write_record(
        self,
        path: Path,
        *,
        payload: bytes,
        created_at: float,
        next_attempt_at: float,
        attempts: int,
        last_error: str,
    ) -> None:
        record: dict[str, object] = {
            "spool_version": SPOOL_VERSION,
            "destination_key": self.destination_key,
            "created_at": created_at,
            "next_attempt_at": next_attempt_at,
            "attempts": attempts,
            "last_error": last_error[:_MAX_ERROR_LENGTH],
            "payload_base64": base64.b64encode(payload).decode("ascii"),
        }
        encoded = json.dumps(
            record,
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode("utf-8")
        temp_path = self.root / f".{path.name}.{secrets.token_hex(8)}{_TEMP_SUFFIX}"
        descriptor = os.open(
            temp_path,
            os.O_WRONLY | os.O_CREAT | os.O_EXCL,
            0o600,
        )
        try:
            with os.fdopen(descriptor, "wb") as stream:
                stream.write(encoded)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temp_path, path)
            _fsync_directory(self.root)
        except OSError:
            self.delete(temp_path)
            raise

    def _claim(self, path: Path, now: float) -> Path | None:
        claimed_path = path.with_name(
            f"{path.name}.{int(now * 1000)}-{os.getpid()}-"
            f"{secrets.token_hex(4)}{_CLAIM_SUFFIX}"
        )
        try:
            os.replace(path, claimed_path)
        except FileNotFoundError:
            return None
        return claimed_path

    def _release_claim(self, claimed_path: Path, ready_path: Path) -> None:
        try:
            os.replace(claimed_path, ready_path)
        except FileNotFoundError:
            pass

    def _recover(self, now: float) -> None:
        for temp_path in self.root.glob(f"*{_TEMP_SUFFIX}"):
            modified_at = _modified_at(temp_path)
            if modified_at is None or now - modified_at > _CLAIM_TTL_SECONDS:
                self.delete(temp_path)
        for claimed_path in self.root.glob(f"*{_CLAIM_SUFFIX}"):
            claimed_at = _claim_timestamp(claimed_path)
            if claimed_at is None:
                self.delete(claimed_path)
                continue
            if now - claimed_at <= _CLAIM_TTL_SECONDS:
                continue
            ready_name = claimed_path.name.split(".json.", 1)[0] + ".json"
            self._release_claim(claimed_path, self.root / ready_name)

    def _prune(self) -> None:
        files: list[tuple[Path, int, float]] = []
        total = 0
        for path in self.root.iterdir():
            if not path.is_file():
                continue
            try:
                stat = path.stat()
            except FileNotFoundError:
                continue
            total += stat.st_size
            if path.name.endswith(".json"):
                files.append((path, stat.st_size, stat.st_mtime))
        files.sort(key=lambda item: item[2])
        while total > self.max_disk_bytes and files:
            path, size, _ = files.pop(0)
            self.delete(path)
            total -= size


def _strict_int(value: object) -> int | None:
    return value if isinstance(value, int) and not isinstance(value, bool) else None


def _finite_number(value: object) -> float | None:
    if isinstance(value, bool) or not isinstance(value, int | float):
        return None
    number = float(value)
    return number if math.isfinite(number) else None


def _claim_timestamp(path: Path) -> float | None:
    try:
        claim = path.name.rsplit(".json.", 1)[1]
        timestamp_ms = claim.split("-", 1)[0]
        return int(timestamp_ms) / 1000
    except (IndexError, ValueError):
        return None


def _modified_at(path: Path) -> float | None:
    try:
        return path.stat().st_mtime
    except FileNotFoundError:
        return None


def _fsync_directory(path: Path) -> None:
    try:
        descriptor = os.open(path, os.O_RDONLY)
    except OSError:
        return
    try:
        os.fsync(descriptor)
    except OSError:
        pass
    finally:
        os.close(descriptor)
