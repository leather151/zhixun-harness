"""Public switches and safe internal entry points for SDK telemetry."""

from __future__ import annotations

import atexit
import logging
import threading
import weakref
from collections.abc import Mapping
from datetime import datetime
from pathlib import Path

from pytrio.config.config import configuration, normalize_base_url
from pytrio.errors.base import PyTrioError
from pytrio.observability.emitter import (
    NOOP_TELEMETRY_EMITTER,
    TelemetryEmitter,
)
from pytrio.observability.event import TelemetryScalar
from pytrio.observability.runtime import (
    TelemetryContext,
    TelemetryRuntime,
    TelemetryRuntimeStartResult,
)

logger = logging.getLogger(__name__)

_lock = threading.Lock()
_enabled = True
_runtimes: weakref.WeakSet[TelemetryRuntime] = weakref.WeakSet()
_atexit_registered = False


def configure_observability(*, enabled: bool = True) -> None:
    """Enable or disable telemetry for subsequently created ServiceClients.

    Existing runtimes keep the setting captured when they were created.
    """

    global _enabled
    with _lock:
        _enabled = enabled


def create_observability_runtime(
    *,
    api_key: str,
    user_cuid: str,
    workspace_cuid: str,
    base_url: str,
    buffer_home: Path | None = None,
) -> TelemetryEmitter:
    """Create an isolated runtime, or a no-op emitter on any setup failure."""

    with _lock:
        enabled = _enabled
    if not enabled:
        return NOOP_TELEMETRY_EMITTER
    try:
        runtime = TelemetryRuntime(
            context=TelemetryContext(
                api_key=api_key,
                user_cuid=user_cuid,
                workspace_cuid=workspace_cuid,
                base_url=normalize_base_url(base_url),
                buffer_home=Path(configuration.home)
                if buffer_home is None
                else buffer_home,
            )
        )
        start_result = runtime.start()
    except Exception:
        logger.debug("Telemetry runtime is unavailable", exc_info=True)
        return NOOP_TELEMETRY_EMITTER
    if start_result is not TelemetryRuntimeStartResult.READY:
        logger.debug("Telemetry runtime is unavailable: %s", start_result.name)
        return NOOP_TELEMETRY_EMITTER
    with _lock:
        _runtimes.add(runtime)
        _ensure_atexit_shutdown_registered_locked()
    return runtime


def record_operation(
    emitter: TelemetryEmitter | None,
    operation: str,
    *,
    status: str = "ok",
    attributes: Mapping[str, TelemetryScalar] | None = None,
    now: datetime | None = None,
) -> None:
    """Submit an event through a no-throw, non-blocking emitter."""

    if emitter is None:
        return
    try:
        emitter.emit(
            operation,
            status=status,
            attributes=attributes,
            now=now,
        )
    except Exception:
        logger.debug("Telemetry event was dropped", exc_info=True)


def error_attributes(exc: BaseException) -> dict[str, TelemetryScalar]:
    """Extract bounded diagnostic scalars without serializing arbitrary details."""

    attributes: dict[str, TelemetryScalar] = {
        "error": type(exc).__name__,
        "error.message": str(exc),
    }
    if isinstance(exc, PyTrioError):
        attributes["error.message"] = exc.message
        attributes["error.code"] = exc.code
        attributes["error.retryable"] = exc.retryable
        if exc.hint:
            attributes["error.hint"] = exc.hint
        if exc.source:
            attributes["error.source"] = exc.source
        if exc.operation:
            attributes["error.operation"] = exc.operation
        if exc.server:
            attributes["error.server"] = exc.server
        if exc.status_code > 0:
            attributes["status_code"] = exc.status_code
        if exc.request_id:
            attributes["request_id"] = exc.request_id
        if exc.task_cuid:
            attributes["task_cuid"] = exc.task_cuid
        if exc.event_cuid:
            attributes["event_cuid"] = exc.event_cuid
        if exc.actor_cuid:
            attributes["actor_cuid"] = exc.actor_cuid
    return attributes


def shutdown_observability() -> None:
    """Best-effort close every telemetry runtime currently alive in this process.

    This does not disable telemetry; a later ServiceClient can create a new runtime.
    """

    with _lock:
        runtimes = list(_runtimes)
    for runtime in runtimes:
        runtime.close()


def _ensure_atexit_shutdown_registered_locked() -> None:
    global _atexit_registered
    if _atexit_registered:
        return
    atexit.register(shutdown_observability)
    _atexit_registered = True


__all__ = [
    "configure_observability",
    "shutdown_observability",
]
