"""Per-ServiceRuntime telemetry queue, delivery worker and replay lifecycle."""

from __future__ import annotations

import asyncio
import hashlib
import logging
import queue
import re
import threading
from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum, auto
from pathlib import Path
from time import monotonic

from pytrio.observability.event import (
    OperationRecord,
    TelemetryBatchEncoder,
    TelemetryScalar,
    runtime_metadata,
)
from pytrio.observability.spool import TelemetryFileSpool
from pytrio.observability.transport import SendResult, TelemetryTransport
from pytrio.runtime import background_worker

logger = logging.getLogger(__name__)

_WORKSPACE_PATTERN = re.compile(r"^[A-Za-z0-9_-]+$")


@dataclass(frozen=True, slots=True)
class TelemetryContext:
    api_key: str = field(repr=False)
    user_cuid: str
    workspace_cuid: str
    base_url: str
    buffer_home: Path

    @property
    def destination_key(self) -> str:
        identity = f"{self.base_url}\n{self.workspace_cuid}".encode()
        return hashlib.sha256(identity).hexdigest()

    @property
    def spool_root(self) -> Path:
        endpoint_hash = hashlib.sha256(self.base_url.encode("utf-8")).hexdigest()[:16]
        return (
            self.buffer_home
            / ".pytrio"
            / "telemetry-events"
            / "v1"
            / endpoint_hash
            / self.workspace_cuid
        )


@dataclass(frozen=True, slots=True)
class TelemetryRuntimeSettings:
    max_disk_bytes: int = 10 * 1024 * 1024
    ttl_hours: int = 24
    retry_after_seconds: int = 5
    replay_interval_seconds: float = 10.0
    replay_max_batch_files: int = 100
    max_queue_size: int = 10_000
    batch_size: int = 100
    flush_interval_seconds: float = 5.0
    startup_timeout_seconds: float = 1.0
    shutdown_timeout_seconds: float = 2.0


class TelemetryRuntimeStartResult(Enum):
    READY = auto()
    FAILED = auto()
    TIMED_OUT = auto()


class _TelemetryRuntimeState(Enum):
    NEW = auto()
    STARTING = auto()
    RUNNING = auto()
    CLOSING = auto()
    CLOSED = auto()
    FAILED = auto()
    ABANDONED = auto()


class TelemetryRuntime:
    """Own one destination and one worker; business threads only enqueue."""

    def __init__(
        self,
        *,
        context: TelemetryContext,
        settings: TelemetryRuntimeSettings | None = None,
    ) -> None:
        if not context.api_key:
            raise ValueError("telemetry API key is required")
        if not _WORKSPACE_PATTERN.fullmatch(context.user_cuid):
            raise ValueError("user CUID contains unsafe characters")
        if not _WORKSPACE_PATTERN.fullmatch(context.workspace_cuid):
            raise ValueError("workspace CUID contains unsafe path characters")
        self._context: TelemetryContext = context
        self._settings: TelemetryRuntimeSettings = (
            settings or TelemetryRuntimeSettings()
        )
        self._records: queue.Queue[OperationRecord] = queue.Queue(
            maxsize=max(1, self._settings.max_queue_size)
        )
        self._state_lock: threading.Lock = threading.Lock()
        self._state: _TelemetryRuntimeState = _TelemetryRuntimeState.NEW
        self._startup_finished: threading.Event = threading.Event()
        self._closing: threading.Event = threading.Event()
        self._stopped: threading.Event = threading.Event()
        self._shutdown_deadline: float = 0.0
        self._worker: background_worker.BackgroundWorkerHandle | None = None

    def start(self) -> TelemetryRuntimeStartResult:
        should_start_worker = False
        with self._state_lock:
            if self._state is _TelemetryRuntimeState.RUNNING:
                return TelemetryRuntimeStartResult.READY
            if self._state is _TelemetryRuntimeState.FAILED:
                return TelemetryRuntimeStartResult.FAILED
            if self._state is _TelemetryRuntimeState.ABANDONED:
                return TelemetryRuntimeStartResult.TIMED_OUT
            if self._state in {
                _TelemetryRuntimeState.CLOSING,
                _TelemetryRuntimeState.CLOSED,
            }:
                return TelemetryRuntimeStartResult.FAILED
            if self._state is _TelemetryRuntimeState.NEW:
                self._state = _TelemetryRuntimeState.STARTING
                should_start_worker = True

        if should_start_worker:
            try:
                worker = background_worker.start(self._worker_entrypoint)
            except Exception:
                logger.debug("Telemetry worker could not be started", exc_info=True)
                with self._state_lock:
                    self._state = _TelemetryRuntimeState.FAILED
                self._startup_finished.set()
                self._stopped.set()
                return TelemetryRuntimeStartResult.FAILED
            with self._state_lock:
                self._worker = worker

        timeout = max(0.0, self._settings.startup_timeout_seconds)
        if not self._startup_finished.wait(timeout=timeout):
            with self._state_lock:
                # The worker mutates state while this thread waits; static narrowing
                # cannot model the cross-thread transition.
                if self._state is _TelemetryRuntimeState.RUNNING:  # pyright: ignore[reportUnnecessaryComparison]
                    return TelemetryRuntimeStartResult.READY
                if self._state is _TelemetryRuntimeState.FAILED:  # pyright: ignore[reportUnnecessaryComparison]
                    return TelemetryRuntimeStartResult.FAILED
                if self._state is _TelemetryRuntimeState.STARTING:
                    self._state = _TelemetryRuntimeState.ABANDONED
                    self._closing.set()
            logger.debug(
                "Telemetry worker startup timed out after %.3f seconds",
                timeout,
            )
            return TelemetryRuntimeStartResult.TIMED_OUT

        with self._state_lock:
            # The worker publishes its terminal startup state before setting the event.
            if self._state is _TelemetryRuntimeState.RUNNING:  # pyright: ignore[reportUnnecessaryComparison]
                return TelemetryRuntimeStartResult.READY
            if self._state is _TelemetryRuntimeState.ABANDONED:  # pyright: ignore[reportUnnecessaryComparison]
                return TelemetryRuntimeStartResult.TIMED_OUT
            return TelemetryRuntimeStartResult.FAILED

    def emit(
        self,
        operation: str,
        *,
        status: str = "ok",
        attributes: Mapping[str, TelemetryScalar] | None = None,
        now: datetime | None = None,
    ) -> None:
        try:
            record = OperationRecord(
                operation=operation,
                status=status,
                attributes=dict(attributes or {}),
                recorded_at=now or datetime.now(tz=timezone.utc),
            )
            with self._state_lock:
                if self._state is not _TelemetryRuntimeState.RUNNING:
                    return
                self._records.put_nowait(record)
        except (MemoryError, queue.Full):
            logger.debug("Dropping telemetry event because its queue is unavailable")

    def close(self) -> None:
        wait_for_worker = False
        with self._state_lock:
            if self._state is _TelemetryRuntimeState.NEW:
                self._state = _TelemetryRuntimeState.CLOSED
                self._startup_finished.set()
                self._stopped.set()
                return
            if self._state is _TelemetryRuntimeState.CLOSED:
                return
            if self._state in {
                _TelemetryRuntimeState.ABANDONED,
                _TelemetryRuntimeState.CLOSING,
            }:
                return
            if self._state is _TelemetryRuntimeState.FAILED:
                wait_for_worker = not self._stopped.is_set()
            else:
                self._state = _TelemetryRuntimeState.CLOSING
                wait_for_worker = True
            timeout = max(0.0, self._settings.shutdown_timeout_seconds)
            self._shutdown_deadline = monotonic() + timeout
            self._closing.set()
            self._startup_finished.set()
            worker = self._worker
        if wait_for_worker and (worker is None or not worker.is_current()):
            self._stopped.wait(timeout=timeout)

    def _worker_entrypoint(self) -> None:
        asyncio.run(self._worker_entrypoint_async())

    async def _worker_entrypoint_async(self) -> None:
        """Own telemetry's AsyncClient and delivery loop on this worker loop."""
        transport: TelemetryTransport | None = None
        try:
            encoder = TelemetryBatchEncoder(
                user_cuid=self._context.user_cuid,
                workspace_cuid=self._context.workspace_cuid,
                runtime=runtime_metadata(),
            )
            transport = self._create_transport()
            spool = self._create_spool()
            with self._state_lock:
                if self._state is not _TelemetryRuntimeState.STARTING:
                    return
                self._state = _TelemetryRuntimeState.RUNNING
            self._startup_finished.set()
            await self._worker_loop(encoder, transport, spool)
        except BaseException:
            logger.debug("Telemetry worker failed", exc_info=True)
            with self._state_lock:
                if self._state in {
                    _TelemetryRuntimeState.STARTING,
                    _TelemetryRuntimeState.RUNNING,
                }:
                    self._state = _TelemetryRuntimeState.FAILED
        finally:
            if transport is not None:
                try:
                    await transport.aclose()
                except Exception:
                    logger.debug("Telemetry transport close failed", exc_info=True)
            with self._state_lock:
                if self._state in {
                    _TelemetryRuntimeState.RUNNING,
                    _TelemetryRuntimeState.CLOSING,
                    _TelemetryRuntimeState.ABANDONED,
                }:
                    self._state = _TelemetryRuntimeState.CLOSED
                elif self._state is _TelemetryRuntimeState.STARTING:
                    self._state = _TelemetryRuntimeState.FAILED
            self._startup_finished.set()
            self._stopped.set()

    async def _worker_loop(
        self,
        encoder: TelemetryBatchEncoder,
        transport: TelemetryTransport | None,
        spool: TelemetryFileSpool | None,
    ) -> None:
        pending: list[OperationRecord] = []
        pending_since = monotonic()
        replay_interval = max(0.1, self._settings.replay_interval_seconds)
        next_replay = monotonic() + replay_interval
        replay_budget = 0
        while True:
            closing = self._closing.is_set()
            replay_due = not closing and monotonic() >= next_replay
            was_empty = not pending
            self._collect_available(
                pending,
                block=not closing and not replay_due,
            )
            if was_empty and pending:
                pending_since = monotonic()
            now = monotonic()
            if pending and (
                closing
                or len(pending) >= max(1, self._settings.batch_size)
                or now - pending_since
                >= max(0.1, self._settings.flush_interval_seconds)
            ):
                batch_size = max(1, self._settings.batch_size)
                batch = pending[:batch_size]
                del pending[:batch_size]
                await self._deliver(
                    encoder,
                    transport,
                    spool,
                    batch,
                    allow_online=self._may_send_online(),
                )
                pending_since = monotonic()
                now = monotonic()
            if not closing and now >= next_replay:
                if replay_budget <= 0:
                    replay_budget = max(
                        0,
                        self._settings.replay_max_batch_files,
                    )
                replayed = replay_budget > 0 and await self._replay_one(
                    transport, spool
                )
                if replayed:
                    replay_budget -= 1
                if replayed and replay_budget > 0:
                    next_replay = monotonic()
                else:
                    replay_budget = 0
                    next_replay = monotonic() + replay_interval
            if closing and not pending and self._records.empty():
                break

    def _collect_available(
        self,
        pending: list[OperationRecord],
        *,
        block: bool,
    ) -> None:
        capacity = max(1, self._settings.batch_size) - len(pending)
        if capacity <= 0:
            return
        if block:
            try:
                pending.append(self._records.get(timeout=0.1))
                capacity -= 1
            except queue.Empty:
                return
        while capacity > 0:
            try:
                pending.append(self._records.get_nowait())
            except queue.Empty:
                break
            capacity -= 1

    async def _deliver(
        self,
        encoder: TelemetryBatchEncoder,
        transport: TelemetryTransport | None,
        spool: TelemetryFileSpool | None,
        records: list[OperationRecord],
        *,
        allow_online: bool,
    ) -> None:
        try:
            payload = encoder.encode(records)
        except (MemoryError, TypeError, ValueError):
            logger.debug(
                "Dropping telemetry batch that could not be encoded", exc_info=True
            )
            return
        if transport is not None and allow_online:
            result = await transport.send(payload)
        else:
            result = SendResult(
                ok=False,
                retryable=True,
                error="telemetry transport unavailable",
            )
        if result.ok or not result.retryable or spool is None:
            return
        try:
            spool.put(
                payload=payload,
                retry_after_seconds=(
                    result.retry_after_seconds or self._settings.retry_after_seconds
                ),
                last_error=result.error or str(result.status_code),
            )
        except (OSError, ValueError):
            logger.debug("Failed to spool telemetry batch", exc_info=True)

    async def _replay_one(
        self,
        transport: TelemetryTransport | None,
        spool: TelemetryFileSpool | None,
    ) -> bool:
        if transport is None or spool is None:
            return False
        try:
            batches = spool.due(limit=1)
        except OSError:
            logger.debug("Failed to scan telemetry spool", exc_info=True)
            return False
        if not batches:
            return False
        batch = batches[0]
        result = await transport.send(batch.payload)
        try:
            if result.ok or not result.retryable:
                spool.delete(batch.claimed_path)
            else:
                spool.mark_failed(
                    batch,
                    retry_after_seconds=(
                        result.retry_after_seconds
                        or min(
                            300,
                            self._settings.retry_after_seconds
                            * (2 ** min(batch.attempts, 6)),
                        )
                    ),
                    last_error=result.error or str(result.status_code),
                )
        except OSError:
            logger.debug("Failed to update telemetry spool batch", exc_info=True)
        return True

    def _may_send_online(self) -> bool:
        if not self._closing.is_set():
            return True
        return monotonic() < self._shutdown_deadline

    def _create_transport(self) -> TelemetryTransport | None:
        try:
            return TelemetryTransport(
                base_url=self._context.base_url,
                api_key=self._context.api_key,
            )
        except Exception:
            logger.debug("Telemetry HTTP transport is unavailable", exc_info=True)
            return None

    def _create_spool(self) -> TelemetryFileSpool | None:
        try:
            return TelemetryFileSpool(
                root=self._context.spool_root,
                destination_key=self._context.destination_key,
                workspace_cuid=self._context.workspace_cuid,
                max_disk_bytes=self._settings.max_disk_bytes,
                ttl_hours=self._settings.ttl_hours,
            )
        except (OSError, ValueError):
            logger.debug("Telemetry file spool is unavailable", exc_info=True)
            return None
