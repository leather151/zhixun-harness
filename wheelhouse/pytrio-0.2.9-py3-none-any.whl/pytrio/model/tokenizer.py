"""按模型名称加载并缓存 tokenizer。"""

import importlib
import logging

from pytrio.errors.base import DependencyError

sdk_logger = logging.getLogger("pytrio")


def get_tokenizer(model_id: str):
    """从本地缓存或模型仓库加载基础模型 tokenizer。

    Args:
        model_id: ModelScope 或 Hugging Face canonical 模型 ID。

    Returns:
        模型仓库提供的 tokenizer 对象。

    Raises:
        DependencyError: ModelScope 与 Transformers 均未安装。
    """
    try:
        modelscope = importlib.import_module("modelscope")
        modelscope_logger = importlib.import_module("modelscope.utils.logger")
        AutoTokenizer = modelscope.AutoTokenizer
        backend_logger = modelscope_logger.get_logger()
    except ImportError:
        try:
            transformers = importlib.import_module("transformers")
            AutoTokenizer = transformers.AutoTokenizer
            backend_logger = None
        except ImportError:
            raise DependencyError(
                "Detected missing tokenizer backend. Install 'modelscope' or "
                "Hugging Face 'transformers' to load tokenizers.",
                code="dependency.missing_tokenizer_backend",
            ) from None

    old_level = backend_logger.level if backend_logger is not None else 0

    try:
        if backend_logger is not None:
            backend_logger.setLevel("ERROR")
        return AutoTokenizer.from_pretrained(model_id, local_files_only=True)
    except Exception:  # noqa: BLE001 - any local load failure permits remote fallback
        sdk_logger.info(f"Tokenizer not found locally, downloading: {model_id}")
        tokenizer = AutoTokenizer.from_pretrained(model_id, local_files_only=False)
        return tokenizer
    finally:
        if backend_logger is not None:
            backend_logger.setLevel(old_level)
