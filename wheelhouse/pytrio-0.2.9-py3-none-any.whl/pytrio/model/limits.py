"""定义模型在训练与采样阶段的容量限制。"""

from dataclasses import dataclass


@dataclass(frozen=True)
class TrainingLimits:
    """模型训练请求的 batch、token 和序列容量。"""

    max_batch_size: int | None
    max_tokens_per_request: int | None
    max_seq_len: int | None


@dataclass(frozen=True)
class SamplingLimits:
    """模型采样请求的 batch、token 和序列容量。"""

    max_batch_size: int | None
    max_tokens_per_request: int | None
    max_seq_len: int | None


@dataclass(frozen=True)
class ModelLimits:
    """同一模型的训练与采样容量集合。"""

    training: TrainingLimits
    sampling: SamplingLimits
