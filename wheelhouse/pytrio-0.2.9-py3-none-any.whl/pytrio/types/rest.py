"""定义 Control 元数据与 checkpoint 公共响应。"""

from datetime import datetime
from typing import Literal

from pytrio.types.base import BaseModel


class Cursor(BaseModel):
    """Control 列表接口的分页位置。

    Attributes:
        offset: 当前页起始偏移。
        limit: 当前页请求数量。
        total_count: 符合条件的记录总数。
    """

    offset: int
    limit: int
    total_count: int


CheckpointType = Literal["training", "sampler"]
CheckpointDownloadSourceKind = Literal["object_storage", "actor"]
CheckpointDownloadStatus = Literal["LOCAL", "SYNCING", "READY"]


class Checkpoint(BaseModel):
    """用户可访问的 checkpoint 元数据。

    Attributes:
        checkpoint_id: checkpoint 稳定 ID。
        checkpoint_type: 训练状态或采样权重类型。
        time: checkpoint 创建时间。
        path: 可用于恢复或采样的资源 URI。
        size_bytes: 已知的资源字节数。
        public: checkpoint 是否公开可访问。
        expires_at: 临时 checkpoint 的过期时间。
    """

    checkpoint_id: str
    checkpoint_type: CheckpointType
    time: datetime
    path: str
    size_bytes: int | None = None
    public: bool = False
    expires_at: datetime | None = None


class CheckpointsListResponse(BaseModel):
    """checkpoint 列表及可选分页游标。

    Attributes:
        checkpoints: 当前查询返回的 checkpoint。
        cursor: Control 返回的分页位置；全量聚合结果没有游标。
    """

    checkpoints: list[Checkpoint]
    cursor: Cursor | None = None


class TrainingRun(BaseModel):
    """训练任务及其最近 checkpoint 元数据。

    Attributes:
        training_run_id: 训练任务稳定 ID。
        base_model: 任务使用的基础模型。
        model_owner: 模型归属工作区。
        is_lora: 是否为 LoRA 训练任务。
        corrupted: 服务端是否将任务标记为损坏。
        lora_rank: LoRA rank。
        last_request_time: 最近一次训练请求时间。
        last_checkpoint: 最近一次完整训练状态。
        last_sampler_checkpoint: 最近一次采样权重。
        user_metadata: 创建任务时附带的用户元数据。
    """

    training_run_id: str
    base_model: str
    model_owner: str
    is_lora: bool
    corrupted: bool = False
    lora_rank: int | None = None
    last_request_time: datetime
    last_checkpoint: Checkpoint | None = None
    last_sampler_checkpoint: Checkpoint | None = None
    user_metadata: dict[str, object] | None = None


class TrainingRunsResponse(BaseModel):
    """训练任务分页结果。

    Attributes:
        training_runs: 当前页训练任务。
        cursor: 当前分页位置。
    """

    training_runs: list[TrainingRun]
    cursor: Cursor


class CheckpointArchiveUrlResponse(BaseModel):
    """checkpoint 归档下载地址。

    Attributes:
        url: 预签名下载 URL。
        expires: URL 过期时间。
    """

    url: str
    expires: datetime


class CheckpointDownloadSource(BaseModel):
    """可刷新的 checkpoint 下载源。

    Attributes:
        checkpoint_id: checkpoint 稳定 ID。
        url: 当前下载 URL。
        expires: URL 过期时间。
        source: 数据来源于对象存储或 Actor。
        checkpoint_status: checkpoint 在服务端的同步状态。
        tls_cert_pem: Actor HTTPS 连接的信任证书。
        tls_not_after: Actor TLS 证书过期时间。
    """

    checkpoint_id: str
    url: str
    expires: datetime
    source: CheckpointDownloadSourceKind
    checkpoint_status: CheckpointDownloadStatus
    tls_cert_pem: str | None
    tls_not_after: datetime | None


class CheckpointDownloadResult(BaseModel):
    """checkpoint 本地下载结果。

    Attributes:
        checkpoint_id: checkpoint 稳定 ID。
        path: 本地文件路径。
        bytes_written: 本次调用写入的字节数。
        file_size_bytes: 下载完成后的本地文件大小。
        status_code: 最终 HTTP 响应状态码。
        resumed: 本次调用是否续传已有文件。
    """

    checkpoint_id: str
    path: str
    bytes_written: int
    file_size_bytes: int
    status_code: int
    resumed: bool


class GetSessionResponse(BaseModel):
    """服务会话关联的训练与采样任务。

    Attributes:
        training_run_ids: 会话创建的训练任务 ID。
        sampler_ids: 会话创建的采样任务 ID。
    """

    training_run_ids: list[str]
    sampler_ids: list[str]


class ListSessionsResponse(BaseModel):
    """当前工作区的服务会话 ID 列表。

    Attributes:
        sessions: 服务会话 ID。
    """

    sessions: list[str]


class GetSamplerResponse(BaseModel):
    """采样任务元数据。

    Attributes:
        sampler_id: 采样任务稳定 ID。
        base_model: 采样器使用的基础模型。
        model_path: 采样器加载的权重 URI。
    """

    sampler_id: str
    base_model: str
    model_path: str | None = None
