"""把多个已经提交的物理请求 Future 收敛为一个逻辑操作 Future。

逻辑 Future 管理调用者观察到的聚合状态，源 Future 的生命周期由 session 管理。Actor
事件提交后持续执行并由 session 收敛终态。
"""

import threading
from concurrent.futures import CancelledError
from concurrent.futures import Future as ConcurrentFuture
from typing import TypeVar

from pytrio.types.future.api_future import APIFuture

T = TypeVar("T")


def collect_api_futures(futures: list[APIFuture[T]]) -> APIFuture[list[T]]:
    """按源 Future 顺序收集结果，并把首个失败传播到逻辑 Future。"""
    if not futures:
        raise ValueError("at least one future is required")

    collected: ConcurrentFuture[list[T]] = ConcurrentFuture()
    # ConcurrentFuture 的 callback 可能来自不同线程；锁同时保护结果表和唯一
    # 一次的终态写入。索引表用于解耦“完成顺序”和“提交顺序”。
    results: dict[int, T] = {}
    lock = threading.Lock()

    def resolve(index: int, source: ConcurrentFuture[T]) -> None:
        with lock:
            if collected.done():
                return
            if source.cancelled():
                collected.cancel()
                return
            try:
                results[index] = source.result()
            except CancelledError:
                collected.cancel()
                return
            # Future semantics require propagating every source terminal exception.
            except BaseException as error:  # noqa: BLE001
                collected.set_exception(error)
                return
            if len(results) == len(futures):
                collected.set_result(
                    [results[position] for position in range(len(futures))]
                )

    for future_index, future in enumerate(futures):
        future._future.add_done_callback(
            lambda source, index=future_index: resolve(index, source)
        )

    # collected 的取消作用于逻辑操作；源事件继续完成并由 session 回收资源。
    return APIFuture(collected)
