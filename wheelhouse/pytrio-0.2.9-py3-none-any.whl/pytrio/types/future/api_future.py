"""定义可映射、可等待的 SDK 异步结果。"""

import asyncio
import weakref
from collections.abc import Callable, Generator
from concurrent.futures import CancelledError
from concurrent.futures import Future as ConcurrentFuture
from typing import Generic, TypeVar

T = TypeVar("T")
U = TypeVar("U")
V = TypeVar("V")


class APIFuture(Generic[T]):
    """表示已提交 SDK 操作的线程安全异步结果。

    ``APIFuture`` 同时支持阻塞 ``result`` 和 ``await``；``map`` 创建派生结果并保留
    源操作的取消传播关系。

    Args:
        future: SDK 运行时提交的 concurrent future。
    """

    def __init__(self, future: ConcurrentFuture[T]) -> None:
        self._future: ConcurrentFuture[T] = future

    @staticmethod
    def completed(value: V) -> "APIFuture[V]":
        """创建已经成功完成的结果。

        Args:
            value: future 持有的结果。

        Returns:
            已完成的 API future。
        """
        f: ConcurrentFuture[V] = ConcurrentFuture()
        f.set_result(value)
        return APIFuture(f)

    def result(self, timeout: float | None = None) -> T:
        """阻塞等待并返回操作结果。

        Args:
            timeout: 最大等待秒数，``None`` 表示持续等待。

        Returns:
            SDK 操作结果。

        Raises:
            TimeoutError: 操作未在超时时间内完成。
            BaseException: 操作执行期间记录的异常。
        """
        return self._future.result(timeout=timeout)

    def done(self) -> bool:
        """返回操作是否已经进入终态。

        Returns:
            future 成功、失败或取消时为 ``True``。
        """
        return self._future.done()

    def exception(self, timeout: float | None = None) -> BaseException | None:
        """等待并返回操作异常。

        Args:
            timeout: 最大等待秒数，``None`` 表示持续等待。

        Returns:
            失败异常；成功完成时为 ``None``。
        """
        return self._future.exception(timeout=timeout)

    def cancel(self) -> bool:
        """请求取消尚未开始的操作。

        Returns:
            取消请求生效时为 ``True``。
        """
        return self._future.cancel()

    def map(self, transform: Callable[[T], U]) -> "APIFuture[U]":
        """将成功结果转换为新的 API future。

        Args:
            transform: 接收源结果并返回派生结果的同步函数。

        Returns:
            传播源终态并应用转换函数的 API future。
        """
        source_future = self._future
        source_ref = weakref.ref(source_future)
        mapped_future: ConcurrentFuture[U] = ConcurrentFuture()
        pending_transform: Callable[[T], U] | None = transform

        def resolve(source: ConcurrentFuture[T]) -> None:
            nonlocal pending_transform
            if source.cancelled():
                mapped_future.cancel()
                pending_transform = None
                return
            if mapped_future.done():
                pending_transform = None
                return
            try:
                if pending_transform is None:
                    return
                mapped_future.set_result(pending_transform(source.result()))
            except CancelledError:
                mapped_future.cancel()
            # Future semantics require propagating every source terminal exception.
            except BaseException as error:  # noqa: BLE001
                if not mapped_future.done():
                    mapped_future.set_exception(error)
            finally:
                pending_transform = None

        def cancel_source(mapped: ConcurrentFuture[U]) -> None:
            nonlocal pending_transform
            if mapped.cancelled():
                pending_transform = None
                source = source_ref()
                if source is not None:
                    source.cancel()

        source_future.add_done_callback(resolve)
        mapped_future.add_done_callback(cancel_source)
        return APIFuture(mapped_future)

    def __await__(self) -> Generator[object, None, T]:
        wrapped = asyncio.wrap_future(self._future)
        return wrapped.__await__()
