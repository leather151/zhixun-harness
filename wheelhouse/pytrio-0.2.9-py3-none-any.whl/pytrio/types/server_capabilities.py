"""定义服务端模型能力与容量响应。"""

from pytrio.types.base import BaseModel


class ModelOperationCapabilities(BaseModel):
    """一种模型操作的可用性和容量限制。

    Attributes:
        available: 当前工作区是否可使用该操作。
        max_batch_size: 单次请求的最大样本数。
        max_tokens_per_request: 单次请求的最大有效 token 数。
        max_seq_len: 单条样本的最大序列长度。
    """

    available: bool
    """Whether the operation is currently available for this model."""

    max_batch_size: int | None
    """Maximum batch size, or ``None`` when the server has no known limit."""

    max_tokens_per_request: int | None
    """Maximum tokens accepted by one request, if reported."""

    max_seq_len: int | None
    """Maximum sequence length accepted by the operation, if reported."""


class SupportedModel(BaseModel):
    """Trio 服务端提供的单个模型能力。

    Attributes:
        model_name: Client 工厂接受的稳定模型 ID。
        max_context_length: 模型上下文长度。
        training: 训练操作的可用性和容量。
        sampling: 采样操作的可用性和容量。
    """

    model_name: str
    """Stable model ID accepted by training and sampling client factories."""

    max_context_length: int | None
    """Model context length, or ``None`` when it is not specified."""

    training: ModelOperationCapabilities
    """Training availability and limits."""

    sampling: ModelOperationCapabilities
    """Sampling availability and limits."""


class GetServerCapabilitiesResponse(BaseModel):
    """Control 当前报告的模型目录及逐操作容量。

    Attributes:
        supported_models: 当前工作区可见的模型能力列表。
    """

    supported_models: list[SupportedModel]
    """Models available on the current Trio server."""
