"""定义训练状态保存结果。"""

from typing import Literal

from pytrio.types.base import BaseModel


class SaveWeightsResponse(BaseModel):
    """训练状态保存结果。

    Attributes:
        path: 服务端保存 checkpoint 的 URI。
        model: checkpoint 所属的基础模型。
        size: checkpoint 的字节数。
        type: 保存结果类型，固定为 ``save-checkpoint``。
    """

    path: str
    """服务端保存 checkpoint 的 URI。"""

    model: str
    """checkpoint 所属的基础模型。"""

    size: int
    """checkpoint 的字节数。"""

    type: Literal["save-checkpoint"] = "save-checkpoint"
    """保存结果类型，固定为 ``save-checkpoint``。"""
