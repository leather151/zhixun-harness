"""定义采样权重保存结果。"""

from typing import Literal

from pytrio.types.base import BaseModel


class SaveWeightsForSamplerResponse(BaseModel):
    """采样权重保存结果。

    Attributes:
        path: 服务端保存权重的 URI。
        model: 权重所属的基础模型。
        size: 权重文件的字节数。
        type: 保存结果类型，固定为 ``save-weights``。
    """

    path: str
    """服务端保存权重的 URI。"""

    model: str
    """权重所属的基础模型。"""

    size: int
    """权重文件的字节数。"""

    type: Literal["save-weights"] = "save-weights"
    """保存结果类型，固定为 ``save-weights``。"""
