"""定义单条训练样本及损失输入。"""

from pydantic import model_validator

from pytrio.types.base import BaseModel
from pytrio.types.forward.model_input import ModelInput
from pytrio.types.forward.tensor_data import TensorData


class Datum(BaseModel):
    """一条训练样本及其损失函数输入。

    Attributes:
        model_input: 输入模型的 token 序列。
        loss_fn_inputs: 按损失函数契约命名的强类型张量。
    """

    model_input: ModelInput
    """输入模型的 token 序列。"""

    loss_fn_inputs: dict[str, TensorData]
    """按损失函数契约命名的强类型张量。"""

    @model_validator(mode="before")
    @classmethod
    def convert_tensordata(cls, data: object) -> object:
        """在用户输入边界把 loss 张量统一转换为 ``TensorData``。"""
        if not isinstance(data, dict):
            return data

        loss_fn_inputs = data.get("loss_fn_inputs")
        if not isinstance(loss_fn_inputs, dict):
            return data

        converted: dict[str, TensorData] = {}
        for key, value in loss_fn_inputs.items():
            converted[key] = TensorData.model_validate(value)

        return {
            **data,
            "loss_fn_inputs": converted,
        }
