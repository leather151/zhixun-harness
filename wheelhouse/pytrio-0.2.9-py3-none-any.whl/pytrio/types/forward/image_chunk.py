"""定义模型输入使用的内联图像片段。"""

import base64
from typing import ClassVar, Literal

from pydantic import ConfigDict, Field, field_serializer, field_validator

from pytrio.types.base import BaseModel


class ImageChunk(BaseModel):
    """一张按顺序嵌入模型输入的 PNG 或 JPEG 图像。

    ``expected_tokens`` 仅供本地长度估算使用。服务端始终根据实际图像尺寸重新
    计算视觉 token，因此它不能用来绕过服务端的容量或图片限制。
    """

    model_config: ClassVar[ConfigDict] = ConfigDict(extra="forbid", frozen=True)

    data: bytes = Field(min_length=1)
    format: Literal["png", "jpeg"]
    expected_tokens: int | None = Field(default=None, gt=0)
    type: Literal["image"] = "image"

    @field_validator("data", mode="before")
    @classmethod
    def _decode_base64_json_data(cls, value: object) -> object:
        """将 JSON 字符串解析为图像原始字节，保留 Python bytes 直接构造语义。"""
        if not isinstance(value, str):
            return value
        try:
            return base64.b64decode(value, validate=True)
        except ValueError as error:
            raise ValueError("image data must be standard base64") from error

    @field_serializer("data", when_used="json")
    def _encode_base64_json_data(self, value: bytes) -> str:
        """以跨语言一致的标准 Base64 编码图像字节。"""
        return base64.b64encode(value).decode("ascii")
