"""定义前向与反向调用结果。"""

from pydantic import Field

from pytrio.types.base import BaseModel
from pytrio.types.forward.loss_fn_output import LossFnOutput


class ForwardBackwardOutput(BaseModel):
    """一次逻辑前向或反向调用的结果。

    Attributes:
        loss_fn_outputs: 与输入样本顺序一致的逐样本损失输出。
        metrics: 逻辑 batch 聚合后的训练指标。
        debug: Trainer 返回的调试信息。
    """

    loss_fn_outputs: list[LossFnOutput]
    """与输入样本顺序一致的逐样本损失输出。"""

    metrics: dict[str, float]
    """逻辑 batch 聚合后的训练指标。"""

    debug: dict[str, object] = Field(default_factory=dict)
    """Trainer 返回的调试信息。"""
