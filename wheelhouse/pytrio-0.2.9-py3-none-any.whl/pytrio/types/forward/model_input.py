"""定义按 Tinker 语义排列的模型输入片段。"""

from typing import Annotated

from pydantic import Field

from pytrio.types.base import BaseModel
from pytrio.types.forward.encoded_text_chunk import EncodedTextChunk
from pytrio.types.forward.image_chunk import ImageChunk

ModelInputChunk = Annotated[
    EncodedTextChunk | ImageChunk,
    Field(discriminator="type"),
]


class ModelInput(BaseModel):
    """由一个或多个编码片段组成的模型输入。

    Attributes:
        chunks: 按输入顺序排列的编码文本和内联图像片段。
    """

    chunks: list[ModelInputChunk]

    @classmethod
    def from_ints(cls, tokens: list[int]) -> "ModelInput":
        """从一段 token ID 构造模型输入。

        Args:
            tokens: tokenizer 生成的 token ID。

        Returns:
            包含单个编码片段的模型输入。
        """
        return cls(chunks=[EncodedTextChunk(tokens=tokens)])

    def to_ints(self) -> list[int]:
        """按片段顺序展开全部文本 token ID。

        Returns:
            合并后的 token ID 列表。

        Raises:
            ValueError: 输入含有不能表示为 token ID 的图像片段。
        """
        tokens: list[int] = []
        for chunk in self.chunks:
            if isinstance(chunk, ImageChunk):
                raise ValueError(  # noqa: TRY004 - valid input has no integer representation
                    "model input contains image chunks and cannot be converted to token IDs"
                )
            tokens.extend(chunk.tokens)
        return tokens

    def tolist(self) -> list[int]:
        """按列表形式返回全部 token ID。

        Returns:
            合并后的 token ID 列表。
        """
        return self.to_ints()

    @property
    def length(self) -> int:
        """返回全部片段的 token 总数。

        Returns:
            token 总数。
        """
        return len(self)

    def __len__(self) -> int:
        total = 0
        for chunk in self.chunks:
            if isinstance(chunk, EncodedTextChunk):
                total += len(chunk)
                continue
            if chunk.expected_tokens is None:
                raise ValueError(
                    "image chunks require expected_tokens to calculate model input length"
                )
            total += chunk.expected_tokens
        return total

    @property
    def has_images(self) -> bool:
        """返回输入中是否存在内联图像。"""
        return any(isinstance(chunk, ImageChunk) for chunk in self.chunks)

    @property
    def is_empty(self) -> bool:
        """返回输入是否既没有 token 也没有图像。"""
        return not any(
            isinstance(chunk, ImageChunk) or len(chunk.tokens) > 0
            for chunk in self.chunks
        )
