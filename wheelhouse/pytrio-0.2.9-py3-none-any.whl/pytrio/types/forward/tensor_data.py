"""定义用户侧强类型张量数据。"""

from typing import TYPE_CHECKING, Literal

import numpy as np
from pydantic import Field, model_validator

from pytrio.types.base import BaseModel

if TYPE_CHECKING:
    import torch  # pyright: ignore[reportMissingImports] - optional dependency


class TensorData(BaseModel):
    """可跨 SDK 边界校验和序列化的数值张量。

    数据以一维列表存储，``shape`` 保存逻辑维度；模型校验会统一浮点和整数精度。

    Attributes:
        data: 按行优先顺序展开的数值。
        dtype: Actor 训练协议支持的数据类型。
        shape: 张量逻辑维度。
    """

    data: list[float] | list[int]

    dtype: Literal["float32", "int64"]

    shape: list[int] = Field(default_factory=list)

    @model_validator(mode="before")
    @classmethod
    def convert_input(cls, value: object) -> object:
        """将 PyTorch、NumPy 或数值列表收窄为显式张量字段。"""
        if isinstance(value, cls):
            return value

        try:
            import torch  # pyright: ignore[reportMissingImports] - optional dependency

            if isinstance(value, torch.Tensor):
                return cls.from_torch(value).model_dump()
        except ImportError:
            pass

        if isinstance(value, np.ndarray):
            return cls.from_numpy(value).model_dump()

        if isinstance(value, list):
            arr = np.asarray(value)

            if arr.dtype.kind not in ("i", "u", "f"):
                raise ValueError("Only numeric lists are allowed for TensorData")

            dtype: Literal["float32", "int64"]
            if arr.dtype.kind == "f":
                arr = arr.astype(np.float32)
                dtype = "float32"
            else:
                arr = arr.astype(np.int64)
                dtype = "int64"

            return {
                "data": arr.reshape(-1).tolist(),
                "dtype": dtype,
                "shape": list(arr.shape),
            }

        return value

    @model_validator(mode="after")
    def validate_tensor_data(self) -> "TensorData":
        """校验 shape 元素数并归一化声明 dtype 的数值。"""
        # 未声明 shape 的一维 data 仍按向量推断；显式 ``shape=[]`` 则表示
        # rank-0 tensor，供只保留在本地的自定义 loss 输入使用。
        if "shape" not in self.model_fields_set:
            self.shape = [len(self.data)]

        if any(dim < 0 for dim in self.shape):
            raise ValueError("Negative dimensions are not allowed in shape")

        expected = 1
        for dim in self.shape:
            expected *= dim

        if expected != len(self.data):
            raise ValueError(
                f"Unexpected data length {len(self.data)} for shape {self.shape} (expected {expected})"
            )

        if self.dtype == "float32":
            self.data = [float(x) for x in self.data]
        else:
            normalized: list[int] = []
            for x in self.data:
                if isinstance(x, float) and not x.is_integer():
                    raise ValueError(
                        f"Expected integer values for dtype 'int64', got float {x}"
                    )
                normalized.append(int(x))
            self.data = normalized

        return self

    @classmethod
    def from_numpy(cls, array: np.ndarray) -> "TensorData":
        """从 NumPy 数组构造张量数据。

        Args:
            array: 整数或浮点 NumPy 数组。

        Returns:
            归一化为 ``int64`` 或 ``float32`` 的张量数据。

        Raises:
            ValueError: 数组 dtype 不属于整数或浮点类型。
        """
        if np.issubdtype(array.dtype, np.floating):
            array = array.astype(np.float32)
            dtype: Literal["float32", "int64"] = "float32"
        elif np.issubdtype(array.dtype, np.integer):
            array = array.astype(np.int64)
            dtype = "int64"
        else:
            raise ValueError(f"Unsupported numpy dtype for TensorData: {array.dtype}")

        return cls(
            data=array.reshape(-1).tolist(),
            dtype=dtype,
            shape=list(array.shape),
        )

    def to_numpy(self) -> np.ndarray:
        """按声明的 dtype 和 shape 恢复 NumPy 数组。

        Returns:
            具有逻辑 shape 的 NumPy 数组。
        """
        if self.dtype == "float32":
            numpy_dtype = np.float32
        elif self.dtype == "int64":
            numpy_dtype = np.int64
        else:
            raise ValueError(f"Unsupported TensorDtype: {self.dtype}")

        return np.array(self.data, dtype=numpy_dtype).reshape(self.shape)

    @classmethod
    def from_torch(cls, tensor: "torch.Tensor") -> "TensorData":
        """从 PyTorch 张量构造张量数据。

        Args:
            tensor: 任意设备上的整数或浮点张量。

        Returns:
            移动到 CPU 并归一化精度后的张量数据。

        Raises:
            ImportError: 当前环境没有安装 PyTorch。
        """
        try:
            import torch  # pyright: ignore[reportMissingImports] - optional dependency
        except ImportError as e:
            raise ImportError(
                "Detected missing 'torch'. This operation requires it. "
                f"Install via 'pip install torch'. Error details: {e}"
            )

        if tensor.dtype.is_floating_point:
            tensor = tensor.to(torch.float32)
            dtype: Literal["float32", "int64"] = "float32"
        else:
            tensor = tensor.to(torch.int64)
            dtype = "int64"

        return cls(
            data=tensor.detach().cpu().reshape(-1).tolist(),
            dtype=dtype,
            shape=list(tensor.shape),
        )

    def tolist(self) -> list[object]:
        """返回张量的一维序列化数据。

        Returns:
            按行优先顺序展开的数值列表。
        """
        return list(self.data)

    def __len__(self) -> int:
        return len(self.data)
