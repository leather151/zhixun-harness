"""定义带编码 token 的文本片段。"""

from typing import Literal

from pytrio.types.base import BaseModel


class EncodedTextChunk(BaseModel):
    """一段已经编码的模型输入。

    Attributes:
        tokens: tokenizer 生成的 token ID。
        type: 文本片段类型，固定为 ``encoded_text``。
    """

    tokens: list[int]
    type: Literal["encoded_text"] = "encoded_text"

    def to_ints(self) -> list[int]:
        """返回 token ID 的独立列表。

        Returns:
            与片段顺序一致的 token ID。
        """
        return list(self.tokens)

    @property
    def length(self) -> int:
        """返回片段包含的 token 数。

        Returns:
            token 数量。
        """
        return len(self)

    def __len__(self) -> int:
        return len(self.tokens)
