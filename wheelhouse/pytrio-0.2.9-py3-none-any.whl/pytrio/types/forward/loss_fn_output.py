"""定义自定义损失函数的返回契约。"""

from pytrio.types.forward.tensor_data import TensorData

LossFnOutput = dict[str, TensorData]
