"""定义采样参数。"""

from collections.abc import Sequence

from pytrio.types.base import BaseModel


class SamplingParams(BaseModel):
    """控制生成行为的采样参数。

    Attributes:
        max_tokens: 单条序列最多生成的 token 数。
        seed: 采样随机种子。
        stop: 终止字符串、字符串列表或 token ID 列表。
        temperature: logits 温度。
        top_k: 每步保留的最高概率 token 数，``-1`` 表示不限制。
        top_p: nucleus sampling 的累计概率阈值。
    """

    max_tokens: int | None = None
    """单条序列最多生成的 token 数。"""

    seed: int | None = None
    """采样随机种子。"""

    stop: str | Sequence[str] | Sequence[int] | None = None
    """终止字符串、字符串列表或 token ID 列表。"""

    temperature: float = 1
    """logits 温度。"""

    top_k: int = -1
    """每步保留的最高概率 token 数，``-1`` 表示不限制。"""

    top_p: float = 1
    """nucleus sampling 的累计概率阈值。"""
