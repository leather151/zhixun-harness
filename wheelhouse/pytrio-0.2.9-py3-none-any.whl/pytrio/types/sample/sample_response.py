"""定义采样调用结果。"""

from typing import Literal

from pydantic import Field

from pytrio.types.base import BaseModel
from pytrio.types.sample.sample_sequence import SampleSequence


class SampleResponse(BaseModel):
    """一次逻辑采样调用的结果。

    Attributes:
        sequences: 服务端生成的候选序列。
        prompt_logprobs: 各 prompt token 的对数概率。
        topk_prompt_logprobs: 各 prompt token 的 top-k 候选及其对数概率。
        input_tokens: Actor 按文本和真实图像尺寸重算的输入 token 总数。
        output_tokens: 本次调用生成的 token 总数。
        type: 响应类型，固定为 ``sample``。
    """

    sequences: list[SampleSequence]
    """服务端生成的候选序列。"""

    prompt_logprobs: list[float | None] = Field(default_factory=list)
    """各 prompt token 的对数概率。"""

    topk_prompt_logprobs: list[list[tuple[int, float]] | None] = Field(
        default_factory=list
    )
    """各 prompt token 的 top-k 候选及其对数概率。"""

    input_tokens: int = 0
    """Actor 按文本与实际图像尺寸重算的输入 token 总数。"""

    output_tokens: int = 0
    """本次调用生成的 token 总数。"""

    type: Literal["sample"] = "sample"
    """响应类型，固定为 ``sample``。"""
