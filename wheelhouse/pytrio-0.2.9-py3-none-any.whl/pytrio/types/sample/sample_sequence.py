"""定义单条生成序列。"""

from pytrio.types.base import BaseModel


class SampleSequence(BaseModel):
    """采样器生成的一条候选序列。

    Attributes:
        stop_reason: 生成终止原因。
        tokens: 生成的 token ID。
        text: 请求文本输出时返回的解码文本。
        logprobs: 各生成 token 的对数概率。
    """

    stop_reason: str
    """生成终止原因。"""

    tokens: list[int]
    """生成的 token ID。"""

    text: str | None = None
    """请求文本输出时返回的解码文本。"""

    logprobs: list[float]
    """各生成 token 的对数概率。"""
