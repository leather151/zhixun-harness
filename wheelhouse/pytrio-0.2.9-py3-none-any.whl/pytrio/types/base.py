"""定义用户类型共享的 Pydantic 配置。"""

from typing import ClassVar

from pydantic import BaseModel as PydanticBaseModel
from pydantic import ConfigDict


class BaseModel(PydanticBaseModel):
    """统一用户类型的校验和可变性配置。"""

    model_config: ClassVar[ConfigDict] = ConfigDict(
        extra="forbid",
        frozen=False,
    )
