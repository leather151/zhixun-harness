"""定义 Adam 优化器参数。"""

from pytrio.types.base import BaseModel


class AdamParams(BaseModel):
    """AdamW 优化器参数。

    Attributes:
        learning_rate: 学习率。
        beta1: 一阶矩估计的指数衰减率。
        beta2: 二阶矩估计的指数衰减率。
        eps: 数值稳定项。
        weight_decay: 权重衰减系数。
        grad_clip_norm: 全局梯度裁剪范数，``0.0`` 表示关闭裁剪。
    """

    learning_rate: float = 0.0001
    """学习率。"""

    beta1: float = 0.9
    """一阶矩估计的指数衰减率。"""

    beta2: float = 0.95
    """二阶矩估计的指数衰减率。"""

    eps: float = 1e-12
    """数值稳定项。"""

    weight_decay: float = 0.0
    """权重衰减系数。"""

    grad_clip_norm: float = 0.0
    """全局梯度裁剪范数，``0.0`` 表示关闭裁剪。"""
