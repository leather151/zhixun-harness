"""定义优化步骤结果。"""

from pytrio.types.base import BaseModel


class OptimStepResponse(BaseModel):
    """一次优化步骤的结果。

    Attributes:
        metrics: Trainer 返回的优化器指标。
    """

    metrics: dict[str, float]
    """Trainer 返回的优化器指标。"""
