"""解析并维护 SDK 当前生效的运行配置。"""

import warnings
from collections.abc import Sequence
from pathlib import Path
from typing import ClassVar
from urllib.parse import urlsplit, urlunsplit

from pydantic import BaseModel, ConfigDict, Field, field_validator

from pytrio._version import __version__
from pytrio.config.environment import read_environment_configuration
from pytrio.config.models import (
    DEFAULT_ENV,
    EnvironmentInfo,
    EnvironmentRemoveResult,
    EnvironmentState,
    ProfileConfig,
    is_valid_environment_name,
    normalized_environment_name,
)
from pytrio.config.repository import ConfigRepository
from pytrio.config.urls import (
    CONTROL_API_PATH,
    DEFAULT_BASE_URL,
    normalize_service_base_url,
)
from pytrio.errors.auth import AuthError
from pytrio.errors.base import PyTrioError
from pytrio.errors.protocol import ConfigurationError
from pytrio.logging.render import LogLevel, strict_log_level


def normalize_base_url(base_url: str) -> str:
    """归一化面向用户展示和持久化的 Trio 服务根地址。

    Args:
        base_url: Trio 服务根地址或以 ``/api`` 结尾的 Control 地址。

    Returns:
        移除 Control API 后缀和末尾斜杠的服务根地址。
    """
    return normalize_service_base_url(base_url)


def control_api_url(base_url: str | None = None) -> str:
    """从服务根地址生成 Control API 地址。

    Args:
        base_url: 指定的服务根地址；未提供时读取当前配置。

    Returns:
        以 ``/api`` 结尾的 Control API 地址。
    """
    service_url = normalize_base_url(base_url or configuration.base_url)
    parsed = urlsplit(service_url)
    path = parsed.path.rstrip("/")
    api_path = f"{path}{CONTROL_API_PATH}" if path else CONTROL_API_PATH
    return urlunsplit((parsed.scheme, parsed.netloc, api_path, "", ""))


class Configuration(BaseModel):
    """SDK 进程级运行配置。

    配置对象在 Client 创建时提供连接、重试、队列和日志参数；已经创建的运行时持有
    自己的异步 HTTP 连接和协程调度状态。
    """

    model_config: ClassVar[ConfigDict] = ConfigDict(
        validate_assignment=True, extra="forbid"
    )

    active_env: str = Field(default=DEFAULT_ENV)
    """Current Trio server profile. Empty string means the default profile."""

    base_url: str = Field(default=DEFAULT_BASE_URL)
    """Base URL for the PyTrio service."""

    request_timeout_seconds: int = Field(default=30, ge=1)
    """Default request timeout in seconds."""

    retry_max_attempts: int = Field(default=3, ge=1)
    """Maximum HTTP attempts for transient errors."""

    retry_initial_delay_seconds: float = Field(default=1.0, ge=0)
    """Initial HTTP retry delay in seconds."""

    retry_multiplier: float = Field(default=2.0, ge=0)
    """HTTP retry backoff multiplier."""

    retry_max_delay_seconds: float = Field(default=30.0, ge=0)
    """Maximum HTTP retry delay in seconds."""

    retry_jitter_ratio: float = Field(default=0.1, ge=0)
    """HTTP retry jitter ratio."""

    training_retry_timeout_seconds: float = Field(default=15 * 60, ge=0)
    """Maximum continuous Actor training request failure time in seconds."""

    control_retry_timeout_seconds: float = Field(default=15 * 60, ge=0)
    """Maximum continuous Control request failure time in seconds."""

    sampling_retry_timeout_seconds: float = Field(default=15 * 60, ge=0)
    """Maximum continuous Actor sampling request failure time in seconds."""

    actor_capacity_poll_interval_seconds: float = Field(default=30.0, gt=0)
    """Base interval between Control Actor-capacity polls in seconds."""

    actor_capacity_poll_jitter_ratio: float = Field(default=0.1, ge=0)
    """Positive random jitter ratio applied to Actor-capacity poll intervals."""

    actor_capacity_wait_timeout_seconds: float = Field(default=60 * 60, ge=0)
    """Maximum time spent waiting for Control Actor capacity in seconds."""

    sampling_timeout_seconds: int = Field(default=4 * 60 * 60, ge=1)
    """Maximum total time for a sampling HTTP request in seconds."""

    sampling_first_chunk_timeout_seconds: float = Field(default=60 * 60, gt=0)
    """Maximum time to wait for the first non-empty sampling response chunk."""

    sampling_chunk_idle_timeout_seconds: float = Field(default=60 * 60, gt=0)
    """Maximum interval between non-empty sampling response chunks."""

    actor_event_submit_timeout_seconds: int = Field(default=30, ge=1)
    """Actor event submit timeout in seconds."""

    actor_event_polling_timeout_seconds: int = Field(default=65, ge=1)
    """Actor event polling timeout in seconds."""

    training_event_max_in_flight: int = Field(default=16, ge=1)
    """Maximum submitted training events waiting for terminal resolution."""

    training_event_queue_capacity: int = Field(default=64, ge=1)
    """Maximum SDK-local training events waiting to be submitted."""

    sampling_request_max_in_flight: int = Field(default=16, ge=1)
    """Maximum sampling requests waiting for terminal resolution."""

    sampling_request_queue_capacity: int = Field(default=64, ge=1)
    """Maximum SDK-local sampling requests waiting to be submitted."""

    actor_heartbeat_enabled: bool = Field(default=True)
    """Whether SDK-created clients send run-scoped heartbeats."""

    actor_heartbeat_interval_seconds: float = Field(default=60.0, ge=1)
    """Fallback run heartbeat interval in seconds."""

    actor_heartbeat_max_in_flight: int = Field(default=2, ge=1)
    """Maximum concurrent run heartbeat Actor HTTP coroutines."""

    actor_http_max_connections: int = Field(default=100, ge=1)
    """Maximum HTTP connections per ServiceClient actor endpoint/TLS registry entry."""

    actor_http_max_keepalive_connections: int = Field(default=20, ge=1)
    """Maximum idle HTTP connections per ServiceClient actor endpoint/TLS registry entry."""

    log_level: LogLevel = Field(default="INFO")
    """Minimum SDK user-facing console logging level."""

    home: str = Field(default=str(Path.home()))
    """Home directory used for local SDK files."""

    version: str = Field(default=__version__)
    """SDK version."""

    @field_validator("active_env")
    @classmethod
    def validate_active_env(cls, value: str) -> str:
        return normalized_environment_name(str(value))

    @property
    def root_path(self) -> Path:
        """返回 SDK 本地根目录。"""
        return Path(self.home) / ".pytrio"

    @property
    def root_config_path(self) -> Path:
        """返回默认环境配置文件路径。"""
        return self.root_path / "config.toml"

    @property
    def env_state_path(self) -> Path:
        """返回当前环境选择状态文件路径。"""
        return self.root_path / "env.toml"

    @property
    def envs_path(self) -> Path:
        """返回命名环境目录。"""
        return self.root_path / "envs"

    @property
    def prefix_path(self) -> Path:
        """返回当前环境拥有的文件目录。"""
        if self.active_env == DEFAULT_ENV:
            return self.root_path
        return self.envs_path / self.active_env

    @property
    def config_path(self) -> Path:
        """返回当前环境配置文件路径。"""
        return self.prefix_path / "config.toml"

    @property
    def notices_path(self) -> Path:
        """返回当前环境的平台通知状态目录。"""
        return self.prefix_path / "notices"

    @property
    def error_log_path(self) -> Path:
        """返回 SDK 本地错误日志路径。"""
        return self.root_path / "error.log"


class AuthState(BaseModel):
    """当前环境加载出的认证状态及延迟呈现的配置错误。"""

    model_config: ClassVar[ConfigDict] = ConfigDict(
        validate_assignment=True, arbitrary_types_allowed=True
    )

    api_key: str = ""
    """API key loaded from the local SDK config."""

    config_error: PyTrioError | None = None
    """Deferred error from loading the local SDK config."""


configuration = Configuration()
auth_state = AuthState()


def _repository() -> ConfigRepository:
    return ConfigRepository(configuration.root_path)


def _auth_config_error(path: Path, error: Exception) -> AuthError:
    if isinstance(error, OSError):
        return AuthError(
            f"Failed to read config file {path}: {error}",
            code="auth.read_config_failed",
        )
    if isinstance(error, AuthError):
        return error
    return AuthError(
        f"Invalid config file {path}: {error}",
        code="auth.invalid_config",
    )


def save_profile(name: str, profile: ProfileConfig) -> ProfileConfig:
    """归一化环境名称并持久化配置。"""
    return _repository().save_profile(normalize_env_name(name), profile)


def _effective_base_url(profile: ProfileConfig) -> str:
    if profile.base_url is None:
        return DEFAULT_BASE_URL
    return profile.base_url


def normalize_env_name(name: str | None) -> str:
    """将默认环境别名和命名环境收窄为规范名称。"""
    if name is None:
        return DEFAULT_ENV
    try:
        return normalized_environment_name(name)
    except ValueError:
        raise ConfigurationError(
            f"Invalid server profile name: {name}",
            code="configuration.invalid_environment",
            hint="Use letters, numbers, underscore, or hyphen.",
        ) from None


def display_env_name(name: str) -> str:
    """返回适合 CLI 展示的环境名称。"""
    env_name = normalize_env_name(name)
    if env_name == DEFAULT_ENV:
        return "(default)"
    return env_name


def profile_exists(name: str | None) -> bool:
    """返回指定环境是否存在持久化配置。"""
    return _repository().profile_exists(normalize_env_name(name))


def load_active_env() -> None:
    """从环境状态文件加载当前环境名称。"""
    configuration.active_env = DEFAULT_ENV
    try:
        state = _repository().load_environment_state()
        if state is not None:
            configuration.active_env = state.active_env
    except Exception as e:  # noqa: BLE001 - repository errors become AuthError
        raise _auth_config_error(configuration.env_state_path, e) from None


def set_active_env(name: str | None) -> None:
    """持久化并发布当前环境名称。"""
    env_name = normalize_env_name(name)
    _repository().save_environment_state(EnvironmentState(active_env=env_name))
    configuration.active_env = env_name


def _write_env_base_url(name: str, base_url: str) -> None:
    env_name = normalize_env_name(name)
    current = _repository().load_profile(env_name)
    if current is None:
        current = ProfileConfig()
    updated = ProfileConfig(
        api_key=current.api_key,
        base_url=normalize_base_url(base_url),
    )
    save_profile(env_name, updated)


def use_env(
    name: str | None = None,
    *,
    base_url: str | None = None,
) -> EnvironmentInfo:
    """切换当前环境，并可在同一操作中创建或更新服务地址。

    Args:
        name: 环境名称；``None`` 表示默认环境。
        base_url: 环境使用的 Trio 服务根地址。

    Returns:
        切换后当前环境的配置摘要。

    Raises:
        ConfigurationError: 环境名称无效或目标环境不存在。
        AuthError: 环境配置无法持久化。
    """
    env_name = normalize_env_name(name)
    if env_name != DEFAULT_ENV and not profile_exists(env_name) and base_url is None:
        raise ConfigurationError(
            f"Server profile {env_name} does not exist",
            code="configuration.env_not_found",
            hint="Create it with `trio env use "
            + env_name
            + " --base-url <url>` first.",
        )
    if base_url is not None:
        try:
            _write_env_base_url(env_name, base_url)
        except Exception as e:
            if isinstance(e, PyTrioError):
                raise
            raise AuthError(
                f"Failed to save config file: {e}",
                code="auth.save_config_failed",
            ) from None
    set_active_env(env_name)
    load_login_config()
    return current_env_info()


def remove_env(name: str | None) -> EnvironmentRemoveResult:
    """删除命名环境，并在删除当前环境时切回默认环境。"""
    env_name = normalize_env_name(name)
    if env_name == DEFAULT_ENV:
        raise ConfigurationError(
            "Cannot remove the default server profile",
            code="configuration.invalid_environment",
        )
    prefix = _repository().environment_path(env_name)
    if not _repository().environment_exists(env_name):
        raise ConfigurationError(
            f"Server profile {env_name} does not exist",
            code="configuration.env_not_found",
        )
    switched_to_default = configuration.active_env == env_name
    if switched_to_default:
        set_active_env(DEFAULT_ENV)
        load_login_config()
    try:
        _repository().delete_environment(env_name)
    except OSError as e:
        raise AuthError(
            f"Failed to delete server profile {env_name}: {e}",
            code="auth.delete_config_failed",
        ) from None
    return EnvironmentRemoveResult(
        name=env_name,
        removed_path=prefix,
        switched_to_default=switched_to_default,
    )


def _env_info(name: str) -> EnvironmentInfo:
    """读取环境展示信息，并把配置读取失败保留在结果中。"""
    env_name = normalize_env_name(name)
    path = _repository().profile_path(env_name)
    if not profile_exists(env_name):
        default_base_url = DEFAULT_BASE_URL if env_name == DEFAULT_ENV else ""
        return EnvironmentInfo(
            name=env_name,
            config_path=path,
            base_url=default_base_url,
            logged_in=False,
            current=configuration.active_env == env_name,
        )
    try:
        profile = _repository().inspect_profile(env_name)
        if profile is None:
            raise AuthError(
                f"Profile {env_name or '(default)'} disappeared while loading",
                code="auth.read_config_failed",
            )
    except Exception as e:  # noqa: BLE001 - preserve config read failure in result
        error = _auth_config_error(path, e)
        return EnvironmentInfo(
            name=env_name,
            config_path=path,
            base_url="",
            logged_in=False,
            current=configuration.active_env == env_name,
            config_error=error,
        )
    base_url = _effective_base_url(profile)
    return EnvironmentInfo(
        name=env_name,
        config_path=path,
        base_url=base_url,
        logged_in=profile.has_credentials,
        current=configuration.active_env == env_name,
    )


def list_envs() -> Sequence[EnvironmentInfo]:
    """返回默认环境、有效命名环境和当前环境的有序摘要。"""
    names: list[str] = [DEFAULT_ENV]
    for name in sorted(_repository().profile_names()):
        if is_valid_environment_name(name) and profile_exists(name):
            names.append(name)
    if configuration.active_env not in names:
        names.append(configuration.active_env)
    return [_env_info(name) for name in names]


def current_env_info() -> EnvironmentInfo:
    """返回当前环境的配置摘要。"""
    return _env_info(configuration.active_env)


def clear_login_config() -> None:
    """清空进程内认证凭据和延迟配置错误。"""
    auth_state.api_key = ""
    auth_state.config_error = None


def clear_current_login_config() -> None:
    """清除当前环境凭据，并保留命名环境的服务地址。"""
    repository = _repository()
    env_name = configuration.active_env
    if not profile_exists(env_name):
        clear_login_config()
        return

    if env_name == DEFAULT_ENV:
        try:
            repository.delete_profile(env_name)
        except OSError as e:
            raise AuthError(
                f"Failed to delete config file: {e}",
                code="auth.delete_config_failed",
            ) from None
        clear_login_config()
        return

    try:
        profile = repository.load_profile(env_name)
        if profile is None:
            clear_login_config()
            return
        repository.save_profile(
            env_name,
            ProfileConfig(
                base_url=profile.base_url,
            ),
        )
        configuration.base_url = _effective_base_url(profile)
    except Exception as e:
        if isinstance(e, PyTrioError):
            raise
        raise AuthError(
            f"Failed to update config file: {e}",
            code="auth.save_config_failed",
        ) from None
    clear_login_config()


def set_login_profile(profile: ProfileConfig) -> None:
    """把已验证环境配置发布到当前进程状态。"""
    auth_state.api_key = profile.api_key
    auth_state.config_error = None
    configuration.base_url = _effective_base_url(profile)


def load_login_config() -> None:
    """从持久化环境状态加载进程当前地址、凭据和延迟错误。"""
    # 加载过程先发布无凭据的默认状态；文件错误保存在 auth_state，真正发起认证时由
    # ensure_login 统一转换为用户可见失败。
    clear_login_config()
    configuration.base_url = DEFAULT_BASE_URL
    try:
        load_active_env()
    except AuthError as e:
        auth_state.config_error = e
        return

    env_name = configuration.active_env
    repository = _repository()
    if not profile_exists(env_name):
        return
    try:
        profile = repository.load_profile(env_name)
        if profile is None:
            return
    except Exception as e:  # noqa: BLE001 - publish config error to auth state
        auth_state.config_error = _auth_config_error(configuration.config_path, e)
        return
    configuration.base_url = _effective_base_url(profile)
    if profile.has_credentials:
        set_login_profile(profile)


def load_env_config(name: str | None) -> None:
    """加载指定环境到进程状态，不改变持久化的当前环境选择。"""
    clear_login_config()
    configuration.base_url = DEFAULT_BASE_URL
    env_name = normalize_env_name(name)
    repository = _repository()
    if env_name != DEFAULT_ENV and not profile_exists(env_name):
        auth_state.config_error = ConfigurationError(
            f"Server profile {env_name} does not exist",
            code="configuration.env_not_found",
            hint="Create it with `trio env use "
            + env_name
            + " --base-url <url>` first.",
        )
        configuration.active_env = env_name
        return

    configuration.active_env = env_name
    if not profile_exists(env_name):
        return
    try:
        profile = repository.load_profile(env_name)
        if profile is None:
            return
    except Exception as e:  # noqa: BLE001 - publish config error to auth state
        auth_state.config_error = _auth_config_error(configuration.config_path, e)
        return
    configuration.base_url = _effective_base_url(profile)
    if profile.has_credentials:
        set_login_profile(profile)


def configure(
    *,
    api_key: str | None = None,
    base_url: str | None = None,
    request_timeout_seconds: int | None = None,
    retry_max_attempts: int | None = None,
    retry_initial_delay_seconds: float | None = None,
    retry_multiplier: float | None = None,
    retry_max_delay_seconds: float | None = None,
    retry_jitter_ratio: float | None = None,
    training_retry_timeout_seconds: float | None = None,
    control_retry_timeout_seconds: float | None = None,
    sampling_retry_timeout_seconds: float | None = None,
    actor_capacity_poll_interval_seconds: float | None = None,
    actor_capacity_poll_jitter_ratio: float | None = None,
    actor_capacity_wait_timeout_seconds: float | None = None,
    sampling_timeout_seconds: int | None = None,
    sampling_first_chunk_timeout_seconds: float | None = None,
    sampling_chunk_idle_timeout_seconds: float | None = None,
    actor_event_submit_timeout_seconds: int | None = None,
    actor_event_polling_timeout_seconds: int | None = None,
    training_event_max_in_flight: int | None = None,
    training_event_queue_capacity: int | None = None,
    sampling_request_max_in_flight: int | None = None,
    sampling_request_queue_capacity: int | None = None,
    actor_heartbeat_enabled: bool | None = None,
    actor_heartbeat_interval_seconds: float | None = None,
    actor_heartbeat_max_in_flight: int | None = None,
    log_level: LogLevel | None = None,
    home: str | None = None,
    env: str | None = None,
    **unknown_options: object,
) -> None:
    """更新后续 Client 使用的进程级 SDK 配置。

    地址、超时和异步并发容量在创建 ``ServiceClient`` 时进入对应运行时，调用方应在创建
    根 Client 前完成配置。

    Args:
        api_key: 当前进程使用的 API Key。
        base_url: Trio 服务根地址；末尾的 ``/api`` 和斜杠会被归一化。
        request_timeout_seconds: 新建 Client 的默认请求超时秒数。
        retry_max_attempts: 瞬时 HTTP 错误的最大请求次数。
        retry_initial_delay_seconds: 首次重试等待秒数。
        retry_multiplier: 重试退避倍率。
        retry_max_delay_seconds: 单次重试最大等待秒数。
        retry_jitter_ratio: 重试等待时间的随机扰动比例。
        training_retry_timeout_seconds: Actor 训练请求连续失败的最长重试秒数。
        control_retry_timeout_seconds: Control 请求连续失败的最长重试秒数。
        sampling_retry_timeout_seconds: Actor 采样请求连续失败的最长重试秒数。
        actor_capacity_poll_interval_seconds: Control Actor 容量轮询的基础间隔秒数。
        actor_capacity_poll_jitter_ratio: Actor 容量轮询间隔的正向随机扰动比例。
        actor_capacity_wait_timeout_seconds: 等待 Control Actor 可用容量的最长秒数。
        sampling_timeout_seconds: 采样请求超时秒数。
        sampling_first_chunk_timeout_seconds: 采样响应首个非空 body chunk 的等待秒数。
        sampling_chunk_idle_timeout_seconds: 采样响应相邻非空 body chunk 的最大间隔。
        actor_event_submit_timeout_seconds: Actor 事件提交超时秒数。
        actor_event_polling_timeout_seconds: Actor 单次事件查询超时秒数。
        training_event_max_in_flight: 等待终态的训练事件上限。
        training_event_queue_capacity: SDK 本地等待提交的训练事件上限。
        sampling_request_max_in_flight: 等待完成的采样请求上限。
        sampling_request_queue_capacity: SDK 本地等待提交的采样请求上限。
        actor_heartbeat_enabled: 是否为训练任务发送 Actor 心跳。
        actor_heartbeat_interval_seconds: Actor 未指定周期时使用的心跳间隔秒数。
        actor_heartbeat_max_in_flight: Actor 心跳 HTTP 协程的最大并发数。
        log_level: 面向用户的最低控制台日志级别。
        home: SDK 本地文件使用的主目录。
        env: 仅对当前进程生效的 Trio 环境名称；``default`` 和
            ``(default)`` 表示默认环境。
        **unknown_options: 未识别的配置项；这些配置项不会生效，并会逐项发出警告。
    """
    for option in sorted(unknown_options):
        warnings.warn(
            f"Unknown configuration option {option!r} was ignored.",
            category=UserWarning,
            stacklevel=2,
        )

    if home is not None:
        configuration.home = home
        configuration.base_url = DEFAULT_BASE_URL
        if env is None:
            load_login_config()
        else:
            load_env_config(env)
    elif env is not None:
        load_env_config(env)
    if api_key is not None:
        auth_state.api_key = api_key.strip()
    if base_url is not None:
        configuration.base_url = normalize_base_url(base_url)
    if request_timeout_seconds is not None:
        configuration.request_timeout_seconds = request_timeout_seconds
    if retry_max_attempts is not None:
        configuration.retry_max_attempts = retry_max_attempts
    if retry_initial_delay_seconds is not None:
        configuration.retry_initial_delay_seconds = retry_initial_delay_seconds
    if retry_multiplier is not None:
        configuration.retry_multiplier = retry_multiplier
    if retry_max_delay_seconds is not None:
        configuration.retry_max_delay_seconds = retry_max_delay_seconds
    if retry_jitter_ratio is not None:
        configuration.retry_jitter_ratio = retry_jitter_ratio
    if training_retry_timeout_seconds is not None:
        configuration.training_retry_timeout_seconds = training_retry_timeout_seconds
    if control_retry_timeout_seconds is not None:
        configuration.control_retry_timeout_seconds = control_retry_timeout_seconds
    if sampling_retry_timeout_seconds is not None:
        configuration.sampling_retry_timeout_seconds = sampling_retry_timeout_seconds
    if actor_capacity_poll_interval_seconds is not None:
        configuration.actor_capacity_poll_interval_seconds = (
            actor_capacity_poll_interval_seconds
        )
    if actor_capacity_poll_jitter_ratio is not None:
        configuration.actor_capacity_poll_jitter_ratio = (
            actor_capacity_poll_jitter_ratio
        )
    if actor_capacity_wait_timeout_seconds is not None:
        configuration.actor_capacity_wait_timeout_seconds = (
            actor_capacity_wait_timeout_seconds
        )
    if sampling_timeout_seconds is not None:
        configuration.sampling_timeout_seconds = sampling_timeout_seconds
    if sampling_first_chunk_timeout_seconds is not None:
        configuration.sampling_first_chunk_timeout_seconds = (
            sampling_first_chunk_timeout_seconds
        )
    if sampling_chunk_idle_timeout_seconds is not None:
        configuration.sampling_chunk_idle_timeout_seconds = (
            sampling_chunk_idle_timeout_seconds
        )
    if actor_event_submit_timeout_seconds is not None:
        configuration.actor_event_submit_timeout_seconds = (
            actor_event_submit_timeout_seconds
        )
    if actor_event_polling_timeout_seconds is not None:
        configuration.actor_event_polling_timeout_seconds = (
            actor_event_polling_timeout_seconds
        )
    if training_event_max_in_flight is not None:
        configuration.training_event_max_in_flight = training_event_max_in_flight
    if training_event_queue_capacity is not None:
        configuration.training_event_queue_capacity = training_event_queue_capacity
    if sampling_request_max_in_flight is not None:
        configuration.sampling_request_max_in_flight = sampling_request_max_in_flight
    if sampling_request_queue_capacity is not None:
        configuration.sampling_request_queue_capacity = sampling_request_queue_capacity
    if actor_heartbeat_enabled is not None:
        configuration.actor_heartbeat_enabled = actor_heartbeat_enabled
    if actor_heartbeat_interval_seconds is not None:
        configuration.actor_heartbeat_interval_seconds = (
            actor_heartbeat_interval_seconds
        )
    if actor_heartbeat_max_in_flight is not None:
        configuration.actor_heartbeat_max_in_flight = actor_heartbeat_max_in_flight
    if log_level is not None:
        configuration.log_level = strict_log_level(log_level)


def _apply_environment_configuration() -> None:
    """把进程环境变量作为导入期间的一次 ``configure`` 覆写。"""
    try:
        environment = read_environment_configuration()
        configure(
            env=environment.env,
            api_key=environment.api_key,
            base_url=environment.base_url,
            log_level=environment.log_level,
        )
    except ValueError as error:
        raise ConfigurationError(
            f"Invalid PyTrio environment configuration: {error}",
            code="configuration.invalid_environment",
        ) from error


load_login_config()
_apply_environment_configuration()
