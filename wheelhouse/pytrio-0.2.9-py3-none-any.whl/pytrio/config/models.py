"""定义持久化配置与环境状态的领域模型。"""

import re
from dataclasses import dataclass
from pathlib import Path

from pytrio.errors.base import PyTrioError

DEFAULT_ENV: str = ""
DEFAULT_ENV_ALIASES: frozenset[str] = frozenset({"default", "(default)"})
_ENVIRONMENT_NAME_PATTERN = re.compile(r"^[A-Za-z0-9_-]+$")


def is_valid_environment_name(value: str) -> bool:
    return not value or (
        value not in DEFAULT_ENV_ALIASES
        and _ENVIRONMENT_NAME_PATTERN.fullmatch(value) is not None
    )


def normalized_environment_name(value: str) -> str:
    name = value.strip()
    if name in DEFAULT_ENV_ALIASES:
        return DEFAULT_ENV
    if is_valid_environment_name(name):
        return name
    raise ValueError(
        "environment name must use letters, numbers, underscore, or hyphen"
    )


@dataclass(frozen=True)
class ProfileConfig:
    """单个 Trio 环境保存的服务地址与 API Key。"""

    api_key: str = ""
    base_url: str | None = None

    @property
    def has_credentials(self) -> bool:
        return bool(self.api_key)


@dataclass(frozen=True)
class EnvironmentState:
    """SDK 当前选中的环境名称。"""

    active_env: str = ""


@dataclass(frozen=True)
class EnvironmentInfo:
    """命令行展示的环境配置摘要。"""

    name: str
    config_path: Path
    base_url: str
    logged_in: bool
    current: bool
    config_error: PyTrioError | None = None


@dataclass(frozen=True)
class EnvironmentRemoveResult:
    """删除环境后生效的环境选择。"""

    name: str
    removed_path: Path
    switched_to_default: bool
