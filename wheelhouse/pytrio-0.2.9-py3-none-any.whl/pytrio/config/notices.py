"""持久化当前 SDK 环境已经取得展示权的平台通知。"""

from __future__ import annotations

import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote

_NOTICE_STATE_VERSION = 1
_JSON_SUFFIX = ".json"
_MAX_FILENAME_BYTES = 240


def _notice_filename(release_no: str) -> str:
    """把发布编号编码为可逆且不会产生路径层级的 JSON 文件名。"""
    encoded = quote(release_no, safe="")
    filename = f"{encoded}{_JSON_SUFFIX}"
    if encoded and len(filename.encode("utf-8")) <= _MAX_FILENAME_BYTES:
        return filename
    digest = hashlib.sha256(release_no.encode("utf-8")).hexdigest()
    return f"{digest}{_JSON_SUFFIX}"


class LocalNoticeStore:
    """用独立 JSON marker 为跨进程的平台通知提供原子展示权。"""

    def __init__(self, root: Path) -> None:
        self._root: Path = root

    def claim(self, release_no: str) -> bool:
        """原子取得通知展示权；已有 marker 时返回 ``False``。"""
        path = self._root / _notice_filename(release_no)
        record: dict[str, object] = {
            "state_version": _NOTICE_STATE_VERSION,
            "release_no": release_no,
            "first_seen_at": datetime.now(timezone.utc).isoformat(),
        }
        encoded = json.dumps(
            record,
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode("utf-8")

        self._root.mkdir(mode=0o700, parents=True, exist_ok=True)
        try:
            descriptor = os.open(
                path,
                os.O_WRONLY | os.O_CREAT | os.O_EXCL,
                0o600,
            )
        except FileExistsError:
            return False

        try:
            with os.fdopen(descriptor, "wb") as stream:
                descriptor = -1
                stream.write(encoded)
                stream.flush()
                os.fsync(stream.fileno())
        except OSError:
            if descriptor >= 0:
                os.close(descriptor)
            path.unlink(missing_ok=True)
            raise
        return True
