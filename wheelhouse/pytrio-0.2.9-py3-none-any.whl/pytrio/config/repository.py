"""以目录和 TOML 文件组织 SDK 配置仓库。"""

import json
from collections.abc import Mapping
from pathlib import Path

from pytrio.config.models import (
    EnvironmentState,
    ProfileConfig,
    normalized_environment_name,
)
from pytrio.config.storage import ConfigDecodeError, ConfigStorage
from pytrio.config.urls import DEFAULT_BASE_URL, normalize_service_base_url
from pytrio.errors.auth import AuthError

_LEGACY_BASE_URL = "https://pytrio.cn"


def _toml_string(value: str) -> str:
    return json.dumps(value)


def _string(data: Mapping[str, object], key: str) -> str:
    if key not in data:
        return ""
    value = data[key]
    if not isinstance(value, str):
        raise AuthError(
            f"Invalid config file, field {key} must be a string",
            code="auth.invalid_config",
        )
    return value.strip()


class ConfigRepository:
    """拥有一个 SDK 主目录下的配置读写规则。

    Repository 定义环境名称到文件路径的映射。读取时只在发现未知字段时清洗并重写
    配置；运行时覆写值不经过 Repository，因此不会被持久化。
    """

    def __init__(self, root: Path, storage: ConfigStorage | None = None) -> None:
        self._root: Path = root
        self._storage: ConfigStorage = ConfigStorage() if storage is None else storage

    @property
    def environment_state_path(self) -> Path:
        return self._root / "env.toml"

    @property
    def environments_path(self) -> Path:
        return self._root / "envs"

    def environment_path(self, name: str) -> Path:
        return self.environments_path / name

    def profile_path(self, name: str) -> Path:
        if not name:
            return self._root / "config.toml"
        return self.environment_path(name) / "config.toml"

    def profile_exists(self, name: str) -> bool:
        return self._storage.exists(self.profile_path(name))

    def environment_exists(self, name: str) -> bool:
        return self._storage.exists(self.environment_path(name))

    def profile_names(self) -> tuple[str, ...]:
        directories = self._storage.directories(self.environments_path)
        return tuple(path.name for path in directories)

    def _read(self, path: Path) -> Mapping[str, object] | None:
        try:
            return self._storage.read(path)
        except ConfigDecodeError as error:
            raise AuthError(
                f"Invalid config file {path}: {error}",
                code="auth.invalid_config",
            ) from None
        except OSError as error:
            raise AuthError(
                f"Failed to read config file {path}: {error}",
                code="auth.read_config_failed",
            ) from None

    def _parse_profile(self, data: Mapping[str, object]) -> ProfileConfig:
        base_url: str | None = None
        if "base_url" in data:
            normalized_base_url = normalize_service_base_url(_string(data, "base_url"))
            if normalized_base_url == _LEGACY_BASE_URL:
                normalized_base_url = DEFAULT_BASE_URL
            if normalized_base_url != DEFAULT_BASE_URL:
                base_url = normalized_base_url
        return ProfileConfig(
            api_key=_string(data, "api_key"),
            base_url=base_url,
        )

    @staticmethod
    def _has_unknown_profile_fields(data: Mapping[str, object]) -> bool:
        return bool(set(data) - {"api_key", "base_url"})

    def load_profile(self, name: str) -> ProfileConfig | None:
        """加载环境配置；仅在存在未知字段时清洗写回。"""
        data = self._read(self.profile_path(name))
        if data is None:
            return None
        profile = self._parse_profile(data)
        if self._has_unknown_profile_fields(data):
            return self.save_profile(name, profile)
        return profile

    def inspect_profile(self, name: str) -> ProfileConfig | None:
        """读取环境配置而不触发规范化写回。"""
        data = self._read(self.profile_path(name))
        return None if data is None else self._parse_profile(data)

    def save_profile(self, name: str, profile: ProfileConfig) -> ProfileConfig:
        """归一化并保存指定环境的服务地址和凭据。"""
        base_url: str | None = None
        if profile.base_url is not None:
            normalized_base_url = normalize_service_base_url(profile.base_url)
            if normalized_base_url == _LEGACY_BASE_URL:
                normalized_base_url = DEFAULT_BASE_URL
            if normalized_base_url != DEFAULT_BASE_URL:
                base_url = normalized_base_url
        current = ProfileConfig(
            api_key=profile.api_key.strip(),
            base_url=base_url,
        )
        lines: list[str] = []
        if current.has_credentials:
            lines.append(f"api_key = {_toml_string(current.api_key)}")
        if current.base_url is not None:
            lines.append(f"base_url = {_toml_string(current.base_url)}")
        self._write(self.profile_path(name), "\n".join(lines) + ("\n" if lines else ""))
        return current

    def load_environment_state(self) -> EnvironmentState | None:
        """加载当前环境选择；仅在存在未知字段时清洗写回。"""
        data = self._read(self.environment_state_path)
        if data is None:
            return None
        try:
            active_env = normalized_environment_name(_string(data, "active_env"))
        except ValueError as error:
            raise AuthError(
                "Invalid config file "
                + str(self.environment_state_path)
                + ", active_env is not valid",
                code="auth.invalid_config",
            ) from error
        state = EnvironmentState(active_env=active_env)
        if set(data) - {"active_env"}:
            return self.save_environment_state(state)
        return state

    def save_environment_state(self, state: EnvironmentState) -> EnvironmentState:
        try:
            active_env = normalized_environment_name(state.active_env)
        except ValueError as error:
            raise AuthError(
                "Invalid config file "
                + str(self.environment_state_path)
                + ", active_env is not valid",
                code="auth.invalid_config",
            ) from error
        current = EnvironmentState(active_env=active_env)
        content = f"active_env = {_toml_string(current.active_env)}\n"
        self._write(self.environment_state_path, content)
        return current

    def _write(self, path: Path, content: str) -> None:
        try:
            self._storage.write(path, content)
        except OSError as error:
            raise AuthError(
                f"Failed to save config file {path}: {error}",
                code="auth.save_config_failed",
            ) from None

    def delete_profile(self, name: str) -> None:
        self._storage.delete(self.profile_path(name))

    def delete_environment(self, name: str) -> None:
        self._storage.delete_tree(self.environment_path(name))
