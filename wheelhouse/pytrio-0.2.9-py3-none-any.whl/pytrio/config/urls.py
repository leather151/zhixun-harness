"""归一化 SDK 服务端基础地址。"""

from urllib.parse import urlsplit, urlunsplit

DEFAULT_BASE_URL = "https://pytrio.com"
CONTROL_API_PATH = "/api"


def normalize_service_base_url(base_url: str) -> str:
    parsed = urlsplit(base_url.strip().rstrip("/"))
    path = parsed.path.rstrip("/")
    if path == CONTROL_API_PATH or path.endswith(CONTROL_API_PATH):
        path = path[: -len(CONTROL_API_PATH)]
    return urlunsplit((parsed.scheme, parsed.netloc, path, "", "")).rstrip("/")
