"""集中读取 SDK 支持的进程环境变量。"""

import os
from collections.abc import Mapping
from dataclasses import dataclass
from enum import Enum

from pytrio.logging.render import LogLevel, strict_log_level


class EnvironmentVariable(str, Enum):
    """SDK 支持的进程环境变量名称。"""

    PYTRIO_API_KEY = "PYTRIO_API_KEY"
    PYTRIO_BASE_URL = "PYTRIO_BASE_URL"
    PYTRIO_ENV = "PYTRIO_ENV"
    PYTRIO_LOG_LEVEL = "PYTRIO_LOG_LEVEL"


@dataclass(frozen=True)
class EnvironmentConfiguration:
    """可等效传递给 ``configure`` 的环境变量配置。"""

    api_key: str | None = None
    base_url: str | None = None
    env: str | None = None
    log_level: LogLevel | None = None


def _read_optional(
    environ: Mapping[str, str],
    variable: EnvironmentVariable,
) -> str | None:
    value = environ.get(variable.value)
    if value is None:
        return None
    normalized = value.strip()
    return normalized or None


def _read_log_level(environ: Mapping[str, str]) -> LogLevel | None:
    value = _read_optional(environ, EnvironmentVariable.PYTRIO_LOG_LEVEL)
    if value is None:
        return None
    return strict_log_level(value)


def read_environment_configuration(
    environ: Mapping[str, str] | None = None,
) -> EnvironmentConfiguration:
    """读取并规范化当前进程提供的 Trio 配置。"""
    source = os.environ if environ is None else environ
    return EnvironmentConfiguration(
        api_key=_read_optional(source, EnvironmentVariable.PYTRIO_API_KEY),
        base_url=_read_optional(source, EnvironmentVariable.PYTRIO_BASE_URL),
        env=_read_optional(source, EnvironmentVariable.PYTRIO_ENV),
        log_level=_read_log_level(source),
    )
