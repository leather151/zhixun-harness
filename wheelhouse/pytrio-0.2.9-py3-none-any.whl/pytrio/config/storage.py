"""提供配置文件的原子读写与目录操作。"""

import os
import shutil
import tempfile
from collections.abc import Mapping
from pathlib import Path

import tomli as tomllib


class ConfigDecodeError(Exception):
    """配置文件无法解析为 TOML table。"""


class ConfigStorage:
    """拥有 TOML 文件系统 I/O 和原子替换操作。"""

    def read(self, path: Path) -> Mapping[str, object] | None:
        """读取 TOML 根 table，文件不存在时返回 ``None``。"""
        if not path.exists():
            return None
        try:
            with open(path, "rb") as f:
                parsed = tomllib.load(f)
        except tomllib.TOMLDecodeError as error:
            raise ConfigDecodeError(str(error)) from error
        return parsed

    def write(self, path: Path, content: str) -> None:
        """在目标目录写入临时文件并原子替换配置文件。"""
        path.parent.mkdir(parents=True, exist_ok=True)
        descriptor, temporary_name = tempfile.mkstemp(
            dir=path.parent,
            prefix=f".{path.name}.",
            suffix=".tmp",
        )
        temporary_path = Path(temporary_name)
        try:
            # 临时文件先完成 flush 和 fsync，再通过同目录 os.replace 发布；读取方只会
            # 观察到旧版本或完整新版本。
            with os.fdopen(descriptor, "w", encoding="utf-8") as f:
                descriptor = -1
                _ = f.write(content)
                f.flush()
                os.fsync(f.fileno())
            os.replace(temporary_path, path)
        finally:
            if descriptor >= 0:
                os.close(descriptor)
            temporary_path.unlink(missing_ok=True)

    def delete(self, path: Path) -> None:
        path.unlink(missing_ok=True)

    def delete_tree(self, path: Path) -> None:
        shutil.rmtree(path)

    def exists(self, path: Path) -> bool:
        return path.exists()

    def directories(self, path: Path) -> tuple[Path, ...]:
        if not path.exists():
            return ()
        return tuple(child for child in path.iterdir() if child.is_dir())
