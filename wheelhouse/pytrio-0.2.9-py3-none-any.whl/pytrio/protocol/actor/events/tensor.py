"""定义 Actor 训练协议使用的张量载荷。"""

from collections.abc import Sequence
from typing import Literal

import numpy as np
from pydantic import Field, field_validator, model_validator

from pytrio.protocol.base import ProtocolModel

WireTensorEncoding = Literal["raw", "raw_le"]


class WireTensorData(ProtocolModel):
    """携带 dtype、shape 和原始字节的协议 tensor。

    协议层验证 wire tensor 的完整性，adapter 接收完整载荷并转换为用户
    ``TensorData``。字节长度错误在协议边界报告。
    """

    dtype: str
    shape: list[int] = Field(min_length=1)
    encoding: WireTensorEncoding
    data: bytes

    @field_validator("shape")
    @classmethod
    def validate_shape(cls, value: list[int]) -> list[int]:
        if any(dim <= 0 for dim in value):
            raise ValueError("wire tensor shape dimensions must be positive")
        return value

    @model_validator(mode="after")
    def validate_data(self) -> "WireTensorData":
        if len(self.data) == 0:
            raise ValueError("wire tensor data cannot be empty")
        try:
            dtype = np.dtype(self.dtype)
        except TypeError:
            raise ValueError(f"unsupported wire tensor dtype: {self.dtype}") from None
        # shape × dtype.itemsize 是 MessagePack 二进制载荷的唯一合法长度。这里同时覆盖
        # SDK 发出的请求 tensor 和 Actor 返回的 loss output tensor。
        expected_bytes = dtype.itemsize
        for dimension in self.shape:
            expected_bytes *= dimension
        if len(self.data) != expected_bytes:
            raise ValueError(
                f"wire tensor byte length {len(self.data)} does not match "
                f"shape {self.shape} and dtype {self.dtype} ({expected_bytes})"
            )
        return self

    @classmethod
    def from_numpy(cls, array: np.ndarray) -> "WireTensorData":
        """将 NumPy 数组规范化为 Actor wire tensor。

        整数统一为 ``uint8`` 或小端 ``int64``，浮点统一为小端 ``float32``。
        """
        normalized = np.ascontiguousarray(array)
        dtype: str
        if np.issubdtype(normalized.dtype, np.floating):
            normalized = normalized.astype("<f4", copy=False)
            encoding: WireTensorEncoding = "raw_le"
            dtype = normalized.dtype.str
        elif np.issubdtype(normalized.dtype, np.integer):
            if normalized.dtype.itemsize <= 1:
                normalized = normalized.astype("u1", copy=False)
                encoding = "raw"
                dtype = "u1"
            else:
                normalized = normalized.astype("<i8", copy=False)
                encoding = "raw_le"
                dtype = normalized.dtype.str
        else:
            raise ValueError(f"Unsupported numpy dtype for wire tensor: {array.dtype}")

        return cls(
            dtype=dtype,
            shape=list(normalized.shape),
            encoding=encoding,
            data=normalized.tobytes(order="C"),
        )

    @classmethod
    def from_sequence(
        cls,
        data: Sequence[object],
        *,
        dtype: Literal["int32", "int64", "float32", "uint8"] = "int32",
        shape: list[int] | None = None,
    ) -> "WireTensorData":
        """按显式 wire dtype 和可选 shape 编码数值序列。"""
        numpy_dtype: str
        if dtype == "float32":
            numpy_dtype = "<f4"
        elif dtype == "uint8":
            numpy_dtype = "u1"
        elif dtype == "int64":
            numpy_dtype = "<i8"
        else:
            numpy_dtype = "<i4"
        array = np.asarray(data, dtype=np.dtype(numpy_dtype))
        if shape is not None:
            array = array.reshape(shape)
        return cls.from_numpy(array)

    def to_wire_value(self) -> dict[str, object]:
        return self.model_dump(mode="python")

    def to_numpy(self) -> np.ndarray:
        """在协议完整性已验证后创建零拷贝 numpy 视图，供 adapter 做类型转换。"""
        return np.frombuffer(self.data, dtype=np.dtype(self.dtype)).reshape(self.shape)
