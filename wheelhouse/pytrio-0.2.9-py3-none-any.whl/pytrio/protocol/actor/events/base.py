"""定义 Actor 事件载荷的序列化基类。"""

from typing import ClassVar

from pytrio.protocol.actor.events.event import EventType
from pytrio.protocol.base import ProtocolModel


class ProtocolPayload(ProtocolModel):
    """支持递归转换为 MessagePack wire 值的事件载荷基类。"""

    event_types: ClassVar[tuple[EventType, ...]] = ()

    def to_wire_value(self) -> dict[str, object]:
        return self.model_dump(mode="python", exclude_none=True)
