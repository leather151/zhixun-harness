"""维护 Actor 事件类型与载荷模型的编解码映射。"""

import msgpack

from pytrio.errors.protocol import PayloadSchemaNotFinalizedError
from pytrio.protocol.actor.events.base import ProtocolPayload
from pytrio.protocol.actor.events.event import EventType
from pytrio.protocol.actor.events.trainer.end_run import TrainerEndRunPayload
from pytrio.protocol.actor.events.trainer.forward import TrainerForwardBackwardPayload
from pytrio.protocol.actor.events.trainer.init_run import TrainerInitRunPayload
from pytrio.protocol.actor.events.trainer.optimize_step import (
    TrainerOptimizeStepPayload,
)
from pytrio.protocol.actor.events.trainer.save import TrainerSavePayload

PAYLOAD_MODELS: dict[EventType, type[ProtocolPayload]] = {}
for payload_model in (
    TrainerInitRunPayload,
    TrainerForwardBackwardPayload,
    TrainerOptimizeStepPayload,
    TrainerSavePayload,
    TrainerEndRunPayload,
):
    for event_type in payload_model.event_types:
        PAYLOAD_MODELS[event_type] = payload_model


def payload_model_for_event(event_type: EventType) -> type[ProtocolPayload]:
    """返回事件类型唯一对应的载荷模型。"""
    try:
        return PAYLOAD_MODELS[event_type]
    except KeyError:
        raise PayloadSchemaNotFinalizedError(
            f"{event_type.value} payload schema is not registered"
        ) from None


def payload_to_wire_value(
    event_type: EventType,
    payload: ProtocolPayload | dict[str, object],
) -> dict[str, object]:
    """校验事件类型与载荷类型匹配并转换为 wire 字段。"""
    payload_model = payload_model_for_event(event_type)
    if isinstance(payload, ProtocolPayload):
        if not isinstance(payload, payload_model):
            raise TypeError(
                f"{event_type.value} expects {payload_model.__name__}, "
                f"got {type(payload).__name__}"
            )
        return payload.to_wire_value()
    return payload_model.model_validate(payload).to_wire_value()


def decode_payload(event_type: EventType, raw: bytes) -> ProtocolPayload:
    """按事件类型解码并校验 MessagePack 载荷。"""
    payload_model = payload_model_for_event(event_type)
    data = msgpack.unpackb(raw, raw=False)
    return payload_model.model_validate(data)
