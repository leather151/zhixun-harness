"""定义 Actor 事件信封、状态和响应模型。"""

import re
import secrets
import time
from enum import Enum
from typing import Literal, TypeAlias, cast

import msgpack
from pydantic import Field, field_validator

from pytrio.protocol.base import ProtocolModel, ProtocolResponseModel

EVENT_PROTOCOL_VERSION = 1
EVENT_ID_ALPHABET = "0123456789abcdefghjkmnpqrstvwxyz"
EVENT_ID_PATTERN = re.compile(r"^event_[0-9a-hjkmnp-tv-z]{12}$")


class EventType(str, Enum):
    """SDK 支持提交的 Actor 事件类型。"""

    TRAINER_INIT_RUN = "trainer.init_run"
    TRAINER_FORWARD = "trainer.forward"
    TRAINER_FORWARD_BACKWARD = "trainer.forward_backward"
    TRAINER_OPTIMIZE_STEP = "trainer.optimize_step"
    TRAINER_SAVE_STATE = "trainer.save_state"
    TRAINER_SAVE_WEIGHTS = "trainer.save_weights"
    TRAINER_END_RUN = "trainer.end_run"


class EventStatus(str, Enum):
    """Actor 事件执行生命周期状态。"""

    ACCEPTED = "accepted"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"


class EventMetadata(ProtocolModel):
    """事件身份、任务归属和顺序元数据。"""

    index: int = Field(ge=1)
    step: int
    timestamp: int
    sdk: str
    sdk_version: str
    run_id: str


class EventEnvelope(ProtocolModel):
    """提交到 Actor 的完整事件信封。"""

    version: int = EVENT_PROTOCOL_VERSION
    event_id: str
    type: EventType
    metadata: EventMetadata
    payload: dict[str, object]

    @field_validator("event_id")
    @classmethod
    def validate_event_id(cls, value: str) -> str:
        if not EVENT_ID_PATTERN.match(value):
            raise ValueError("event_id must match event_[0-9a-hjkmnp-tv-z]{12}")
        return value


class EventUsage(ProtocolResponseModel):
    """Actor 事件消耗的 token 与耗时统计。"""

    input_tokens: int
    output_tokens: int
    train_tokens: int = 0


class EventError(ProtocolResponseModel):
    """Actor 事件失败终态携带的错误信息。"""

    code: str
    message: str


class EventResponseBase(ProtocolResponseModel):
    """所有 Actor 事件状态响应的公共字段。"""

    version: int
    event_id: str
    type: EventType


class EventAcceptedResponse(EventResponseBase):
    """Actor 已接收但尚未运行的事件响应。"""

    status: Literal[EventStatus.ACCEPTED]


class EventRunningResponse(EventResponseBase):
    """Actor 正在执行事件的响应。"""

    status: Literal[EventStatus.RUNNING]


class EventSucceededResponse(EventResponseBase):
    """Actor 成功完成事件的终态响应。"""

    status: Literal[EventStatus.SUCCEEDED]
    result: dict[str, object] = Field(default_factory=dict)
    usage: EventUsage


class EventFailedResponse(EventResponseBase):
    """Actor 执行事件失败的终态响应。"""

    status: Literal[EventStatus.FAILED]
    error: EventError
    usage: EventUsage


EventResponse: TypeAlias = (
    EventAcceptedResponse
    | EventRunningResponse
    | EventSucceededResponse
    | EventFailedResponse
)

_EVENT_RESPONSE_MODELS: dict[EventStatus, type[EventResponseBase]] = {
    EventStatus.ACCEPTED: EventAcceptedResponse,
    EventStatus.RUNNING: EventRunningResponse,
    EventStatus.SUCCEEDED: EventSucceededResponse,
    EventStatus.FAILED: EventFailedResponse,
}


def generate_event_id() -> str:
    """生成符合 Actor 协议格式的随机事件 ID。"""
    suffix = "".join(secrets.choice(EVENT_ID_ALPHABET) for _ in range(12))
    return f"event_{suffix}"


def current_timestamp_ms() -> int:
    return int(time.time() * 1000)


def build_event_envelope(
    event_type: EventType,
    payload: dict[str, object],
    metadata: EventMetadata,
    *,
    event_id: str | None = None,
) -> EventEnvelope:
    """把事件类型、载荷和顺序元数据封装为可提交信封。"""
    return EventEnvelope(
        event_id=event_id or generate_event_id(),
        type=event_type,
        metadata=metadata,
        payload=payload,
    )


def pack_event_envelope(envelope: EventEnvelope) -> bytes:
    """将已校验事件信封编码为 MessagePack 字节。"""
    raw = envelope.model_dump(mode="python", exclude_none=True)
    raw["type"] = envelope.type.value
    return cast(bytes, msgpack.packb(raw, use_bin_type=True))


def parse_event_response(data: dict[str, object]) -> EventResponse:
    """按状态判别字段校验 Actor 事件响应。"""
    status = EventStatus(data["status"])
    return cast(EventResponse, _EVENT_RESPONSE_MODELS[status].model_validate(data))


def unpack_event_response(raw: bytes) -> EventResponse:
    """解码 MessagePack map 并校验为事件响应判别联合。"""
    data = msgpack.unpackb(raw, raw=False)
    if not isinstance(data, dict):
        # Malformed wire payloads use the protocol's existing ValueError contract.
        raise ValueError("event response must be a MessagePack map")  # noqa: TRY004
    return parse_event_response(data)
