"""定义 Actor Trainer 保存状态事件的协议载荷。"""

from typing import ClassVar, Literal

from pydantic import Field

from pytrio.protocol.actor.events.base import ProtocolPayload
from pytrio.protocol.actor.events.event import EventType
from pytrio.protocol.base import ProtocolResponseModel

CheckpointVisibility = Literal["WORKSPACE", "TEMPORARY"]


class TrainerSavePayload(ProtocolPayload):
    """``TrainerSave`` Actor 事件的已校验载荷。"""

    event_types: ClassVar[tuple[EventType, ...]] = (
        EventType.TRAINER_SAVE_STATE,
        EventType.TRAINER_SAVE_WEIGHTS,
    )

    name: str
    ttl_seconds: int | None = None
    overwrite: bool = False
    visibility: CheckpointVisibility = "WORKSPACE"
    metadata: dict[str, object] | None = None


class TrainerCheckpointResult(ProtocolResponseModel):
    """Actor 返回的 checkpoint 稳定字段；额外服务端元数据在协议边界忽略。"""

    uri: str = Field(min_length=1)
    model_id: str | None = Field(default=None, min_length=1)
    size_bytes: int = Field(ge=0)


class TrainerSaveResult(ProtocolResponseModel):
    """保存事件结果的顶层 envelope，明确 adapter 接收的嵌套字段结构。"""

    checkpoint: TrainerCheckpointResult
