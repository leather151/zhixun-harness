"""定义 Actor 终止 training run 的 Trainer 事件载荷。

当前 SDK 生命周期不自动提交该事件；该模型仅定义 Actor 协议载荷。
"""

from typing import ClassVar

from pytrio.protocol.actor.events.base import ProtocolPayload
from pytrio.protocol.actor.events.event import EventType


class TrainerEndRunPayload(ProtocolPayload):
    """``TRAINER_END_RUN`` 事件的已校验载荷。"""

    event_types: ClassVar[tuple[EventType, ...]] = (EventType.TRAINER_END_RUN,)

    source: str = "sdk"
    reason: str = "user_requested"
