"""定义 Actor Trainer 前向与反向事件的协议载荷。"""

from typing import ClassVar

from pydantic import Field

from pytrio.protocol.actor.events.base import ProtocolPayload
from pytrio.protocol.actor.events.event import EventType
from pytrio.protocol.actor.events.tensor import WireTensorData
from pytrio.protocol.actor.model_input import WireModelInput
from pytrio.protocol.base import ProtocolModel


class LossSpec(ProtocolModel):
    """Trainer forward 事件使用的损失函数名称与配置。"""

    type: str
    config: dict[str, object] = Field(default_factory=dict)


class GradientAccumulationSpec(ProtocolModel):
    """Trainer 计算等效逻辑 batch 梯度时使用的全局归一化信息。

    字段始终描述拆分前的完整 batch。常规单 event 请求与多 event 请求携带同一结构，
    Trainer 使用统一计算路径选择归一化分母。
    """

    total_samples: int = Field(gt=0)
    total_active_tokens: int = Field(ge=0)
    total_advantage_tokens: int = Field(ge=0)


class TrainerForwardMetrics(ProtocolModel):
    """SDK 可稳定聚合的 forward 指标契约。"""

    loss_sum: float = Field(allow_inf_nan=False)
    loss_mean: float = Field(allow_inf_nan=False)
    token_count: int = Field(ge=0)


class TrainerForwardResult(ProtocolModel):
    """单个物理 forward event 的严格响应边界模型。"""

    loss_fn_outputs: list[dict[str, WireTensorData]]
    metrics: TrainerForwardMetrics


class TrainerForwardDatum(ProtocolModel):
    """一条 canonical v2 ``data[]`` 训练样本。"""

    model_input: WireModelInput
    target_ids: list[int] = Field(min_length=1)
    weights: list[float] | None = None
    logprobs: list[float] | None = None
    advantages: list[float] | None = None


class TrainerForwardBackwardPayload(ProtocolPayload):
    """forward 与 forward_backward 共享的 canonical v2 payload。"""

    event_types: ClassVar[tuple[EventType, ...]] = (
        EventType.TRAINER_FORWARD,
        EventType.TRAINER_FORWARD_BACKWARD,
    )

    data: list[TrainerForwardDatum] = Field(min_length=1)
    auto_shift: bool = False
    loss: LossSpec
    gradient_accumulation: GradientAccumulationSpec
