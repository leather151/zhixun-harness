"""定义 Actor Trainer 优化步骤事件的协议载荷。"""

from typing import ClassVar

from pytrio.protocol.actor.events.base import ProtocolPayload
from pytrio.protocol.actor.events.event import EventType
from pytrio.protocol.base import ProtocolModel


class TrainerAdamParamsPayload(ProtocolModel):
    """``TrainerAdamParams`` Actor 事件的已校验载荷。"""

    learning_rate: float
    beta1: float
    beta2: float
    eps: float
    weight_decay: float
    grad_clip_norm: float


class TrainerOptimizeStepPayload(ProtocolPayload):
    """``TrainerOptimizeStep`` Actor 事件的已校验载荷。"""

    event_types: ClassVar[tuple[EventType, ...]] = (EventType.TRAINER_OPTIMIZE_STEP,)

    adam_params: TrainerAdamParamsPayload
