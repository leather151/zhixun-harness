"""定义 Actor Trainer 初始化任务事件的协议载荷。"""

from typing import ClassVar

from pytrio.protocol.actor.events.base import ProtocolPayload
from pytrio.protocol.actor.events.event import EventType
from pytrio.protocol.base import ProtocolModel


class TrainerLoraPayload(ProtocolModel):
    """``TrainerLora`` Actor 事件的已校验载荷。"""

    rank: int
    seed: int | None = None
    train_mlp: bool
    train_attn: bool
    train_unembed: bool


class TrainerInitRunPayload(ProtocolPayload):
    """``TrainerInitRun`` Actor 事件的已校验载荷。"""

    event_types: ClassVar[tuple[EventType, ...]] = (EventType.TRAINER_INIT_RUN,)

    base_model: str
    lora_config: TrainerLoraPayload
    checkpoint_uri: str | None = None
    load_optimizer: bool = False
    user_metadata: dict[str, object] | None = None
