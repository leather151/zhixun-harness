"""定义 Actor Trainer LoRA 来源事件的协议载荷。"""

from dataclasses import dataclass


@dataclass(frozen=True)
class FreshLoraSource:
    """声明从基础模型创建新的 LoRA 状态。"""


@dataclass(frozen=True)
class CheckpointLoraSource:
    """声明从已有 checkpoint URI 加载 LoRA 状态。"""

    uri: str


LoraSource = FreshLoraSource | CheckpointLoraSource


@dataclass(frozen=True)
class LoraRunSpec:
    """SDK 构造 Trainer 初始化载荷使用的 LoRA 任务配置。"""

    model_id: str
    rank: int
    seed: int | None
    train_mlp: bool
    train_attn: bool
    train_unembed: bool
    source: LoraSource
