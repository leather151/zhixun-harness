"""定义 Actor 采样请求与响应的协议模型。"""

from pydantic import Field, field_validator, model_validator

from pytrio.protocol.actor.model_input import WireModelInput
from pytrio.protocol.base import ProtocolModel, ProtocolResponseModel


class SampleRequest(ProtocolModel):
    """提交给 Actor sampling run 的采样参数。"""

    request_id: str = Field(min_length=1)
    prompt: WireModelInput
    sampling_params: dict[str, object] = Field(
        default_factory=dict, validate_default=True
    )
    num_samples: int = Field(default=1, ge=1)
    return_text: bool = True
    return_token_logprobs: bool = True
    return_prompt_logprobs: bool = False
    topk_prompt_logprobs: int = Field(default=0, ge=0)

    @field_validator("sampling_params")
    @classmethod
    def _validate_sampling_params(cls, value: dict[str, object]) -> dict[str, object]:
        max_tokens = value.get("max_tokens")
        if not isinstance(max_tokens, int) or isinstance(max_tokens, bool):
            # Pydantic value validators report invalid field values as ValueError.
            raise ValueError("sampling_params.max_tokens required")  # noqa: TRY004
        if max_tokens <= 0:
            raise ValueError("sampling_params.max_tokens must be greater than 0")
        return value

    @model_validator(mode="after")
    def _validate_prompt(self) -> "SampleRequest":
        """拒绝没有任何文本 token 或图像的 v2 prompt。"""
        if self.prompt.is_empty:
            raise ValueError("prompt cannot be empty")
        return self


class ActorSampleSequence(ProtocolResponseModel):
    """Actor 返回的一条生成序列。"""

    tokens: list[int] = Field(default_factory=list)
    text: str | None = None
    logprobs: list[float] = Field(default_factory=list)
    stop_reason: str = ""


class Usage(ProtocolResponseModel):
    """Actor 采样调用的 token 用量。"""

    input_tokens: int = 0
    output_tokens: int = 0


class ActorSampleResponse(ProtocolResponseModel):
    """Actor 采样接口的完整响应。"""

    request_id: str = ""
    sampling_run: str = ""
    sequences: list[ActorSampleSequence] = Field(default_factory=list)
    prompt_logprobs: list[float | None] | None = None
    topk_prompt_logprobs: list[list[tuple[int, float]] | None] | None = None
    usage: Usage = Field(default_factory=Usage)
