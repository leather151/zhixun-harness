"""定义 SDK 与 Actor 共享的 v2 模型输入协议。"""

import base64
from typing import Annotated, Literal

from pydantic import Field, field_serializer, field_validator

from pytrio.protocol.base import ProtocolModel


class WireEncodedTextChunk(ProtocolModel):
    """Actor wire 格式中的已编码文本片段。"""

    tokens: list[int]
    type: Literal["encoded_text"] = "encoded_text"


class WireImageChunk(ProtocolModel):
    """Actor wire 格式中的标准 Base64/MessagePack binary 图像片段。"""

    data: bytes = Field(min_length=1)
    format: Literal["png", "jpeg"]
    expected_tokens: int | None = Field(default=None, gt=0)
    type: Literal["image"] = "image"

    @field_validator("data", mode="before")
    @classmethod
    def _decode_base64_json_data(cls, value: object) -> object:
        """将 JSON Base64 字符串转换为 wire 图像字节。"""
        if not isinstance(value, str):
            return value
        try:
            return base64.b64decode(value, validate=True)
        except ValueError as error:
            raise ValueError("image data must be standard base64") from error

    @field_serializer("data", when_used="json")
    def _encode_base64_json_data(self, value: bytes) -> str:
        """JSON 请求使用标准 Base64，MessagePack 请求保留原始 bytes。"""
        return base64.b64encode(value).decode("ascii")


WireModelInputChunk = Annotated[
    WireEncodedTextChunk | WireImageChunk,
    Field(discriminator="type"),
]


class WireModelInput(ProtocolModel):
    """Actor v2 wire 格式中的有序模型输入。"""

    chunks: list[WireModelInputChunk] = Field(min_length=1)

    @property
    def is_empty(self) -> bool:
        """返回输入是否既没有文本 token 也没有图像。"""
        return not any(
            isinstance(chunk, WireImageChunk) or len(chunk.tokens) > 0
            for chunk in self.chunks
        )
