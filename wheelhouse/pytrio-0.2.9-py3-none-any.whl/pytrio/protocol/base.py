"""定义 SDK 协议模型的公共校验配置。"""

from typing import ClassVar

from pydantic import BaseModel, ConfigDict


class ProtocolModel(BaseModel):
    """禁止额外字段的 SDK 协议模型基类。"""

    model_config: ClassVar[ConfigDict] = ConfigDict(
        extra="forbid",
        frozen=False,
    )


class ProtocolResponseModel(BaseModel):
    """允许服务端扩展字段的响应协议模型基类。"""

    model_config: ClassVar[ConfigDict] = ConfigDict(
        extra="ignore",
        frozen=False,
    )
