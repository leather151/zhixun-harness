"""定义 Control 模型目录列表接口的协议模型。"""

from datetime import datetime

from pydantic import Field

from pytrio.protocol.base import ProtocolResponseModel


class ModelRunnerCapability(ProtocolResponseModel):
    """Control 返回的单种模型运行容量。"""

    max_batch_size: int | None = Field(gt=0)
    max_tokens_per_request: int | None = Field(gt=0)
    max_seq_len: int | None = Field(gt=0)


class ModelInfo(ProtocolResponseModel):
    """Control 模型目录中的单个模型能力。"""

    cuid: str
    alias: str
    model_id: str
    display_name: str | None = None
    description: str | None = None
    model_type: str | None = None
    architecture: str | None = None
    size_tier: str | None = None
    model_family: str | None = None
    parameter_size: str | None = None
    context_length: int | None = None
    license: str | None = None
    homepage_url: str | None = None
    precision: str | None = None
    train_available: bool
    sample_available: bool
    trainer: ModelRunnerCapability
    sampler: ModelRunnerCapability
    created_at: datetime
    updated_at: datetime


class ModelListResponse(ProtocolResponseModel):
    """``ModelList`` Control 接口的已校验响应体。"""

    items: list[ModelInfo]
    total: int
    limit: int
    offset: int
