"""定义 Control 协议共用的分页字段。"""

from pytrio.protocol.base import ProtocolResponseModel


class ControlCursor(ProtocolResponseModel):
    """Control 列表响应的分页游标。"""

    offset: int
    limit: int
    total: int
