"""定义 Control checkpoint 下载地址接口的协议模型。"""

from __future__ import annotations

from datetime import datetime
from typing import Literal
from urllib.parse import urlsplit

from pydantic import field_validator, model_validator

from pytrio.protocol.base import ProtocolResponseModel

CheckpointDownloadSource = Literal["object_storage", "actor"]
CheckpointDownloadStatus = Literal["LOCAL", "SYNCING", "READY"]


class CheckpointDownloadResponse(ProtocolResponseModel):
    """``CheckpointDownload`` Control 接口的已校验响应体。"""

    url: str
    expires_at: datetime
    source: CheckpointDownloadSource
    checkpoint_status: CheckpointDownloadStatus
    tls_cert_pem: str | None
    tls_not_after: datetime | None

    @field_validator("url")
    @classmethod
    def validate_url(cls, value: str) -> str:
        parsed = urlsplit(value)
        if parsed.scheme not in ("http", "https") or not parsed.netloc:
            raise ValueError("checkpoint download URL must be an absolute HTTP(S) URL")
        return value

    @model_validator(mode="after")
    def validate_tls_contract(self) -> CheckpointDownloadResponse:
        scheme = urlsplit(self.url).scheme
        if self.source == "object_storage" and (
            self.tls_cert_pem is not None or self.tls_not_after is not None
        ):
            raise ValueError("object storage downloads cannot include Actor TLS fields")
        if scheme == "http" and (
            self.tls_cert_pem is not None or self.tls_not_after is not None
        ):
            raise ValueError("HTTP Actor downloads cannot include TLS fields")
        if self.tls_cert_pem is None and self.tls_not_after is not None:
            raise ValueError("tls_not_after requires tls_cert_pem")
        return self
