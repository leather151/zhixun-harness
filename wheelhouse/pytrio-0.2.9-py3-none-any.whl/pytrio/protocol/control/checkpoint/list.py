"""定义 Control checkpoint 列表接口的协议模型。"""

from datetime import datetime

from pytrio.protocol.base import ProtocolResponseModel
from pytrio.protocol.control.common import ControlCursor


class CheckpointResponse(ProtocolResponseModel):
    """``Checkpoint`` Control 接口的已校验响应体。"""

    cuid: str
    checkpoint_cuid: str
    training_run_cuid: str
    workspace_cuid: str | None = None
    name: str
    checkpoint_type: str
    status: str
    checkpoint_uri: str
    model: str
    base_model: str
    model_spec_cuid: str
    task_id: str
    task_name: str | None = None
    task_created_at: datetime
    task_status: str
    step: int | None = None
    path: str
    created_at: datetime
    uploaded_at: datetime | None = None
    size_bytes: int | None = None
    lora_rank: int
    is_uploaded: bool
    expired_at: datetime | None = None


class CheckpointListResponse(ProtocolResponseModel):
    """``CheckpointList`` Control 接口的已校验响应体。"""

    checkpoints: list[CheckpointResponse]
    cursor: ControlCursor
