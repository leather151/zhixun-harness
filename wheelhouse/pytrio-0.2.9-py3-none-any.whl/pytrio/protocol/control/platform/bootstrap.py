"""定义 Control 平台启动策略接口的协议模型。"""

from datetime import datetime
from typing import Literal

from pytrio.protocol.base import ProtocolResponseModel

SDKCompatibilityStatus = Literal["compatible", "warning", "blocked"]


class SDKCompatibilityResponse(ProtocolResponseModel):
    """Control 对当前 SDK 版本的兼容性判定。"""

    status: SDKCompatibilityStatus
    sdk_version: str
    latest_version: str | None = None
    recommended_version: str | None = None
    min_supported_version: str | None = None
    message: str | None = None
    upgrade_command: str | None = None
    upgrade_url: str | None = None
    policy_release_no: str | None = None
    policy_version: str | None = None
    effective_at: datetime | None = None


class SDKNoticeResponse(ProtocolResponseModel):
    """Control 下发的 SDK 用户通知。"""

    release_no: str
    version: str | None = None
    type: str
    level: str
    title: str
    message: str | None = None
    release_url: str | None = None
    published_at: datetime


class SDKBootstrapResponse(ProtocolResponseModel):
    """SDK 启动兼容性策略与通知集合。"""

    compatibility: SDKCompatibilityResponse
    notices: list[SDKNoticeResponse]
