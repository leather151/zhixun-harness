"""定义 Control 采样任务查询接口的协议模型。"""

from datetime import datetime

from pytrio.protocol.base import ProtocolResponseModel


class SamplingRunGetResponse(ProtocolResponseModel):
    """``SamplingRunGet`` Control 接口的已校验响应体。"""

    sampling_run_cuid: str
    service_session_cuid: str
    workspace_cuid: str
    status: str
    base_model: str
    model_id: str
    alias: str
    source_checkpoint_uri: str | None = None
    created_at: datetime
    updated_at: datetime
