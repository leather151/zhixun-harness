"""定义 Control 采样任务凭据续期接口的协议模型。"""

from pytrio.protocol.base import ProtocolResponseModel
from pytrio.protocol.control.actor.credentials import ActorConnectionInfo, ActorJWT


class SamplingRunRenewResponse(ProtocolResponseModel):
    """``SamplingRunRenew`` Control 接口的已校验响应体。"""

    sampling_run_cuid: str
    service_session_cuid: str
    workspace_cuid: str
    actor: ActorConnectionInfo
    actor_jwt: ActorJWT
