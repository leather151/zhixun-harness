"""定义 Control 采样任务创建接口的协议模型。"""

from datetime import datetime

from pydantic import Field

from pytrio.protocol.base import ProtocolModel, ProtocolResponseModel
from pytrio.protocol.control.actor.credentials import ActorConnectionInfo, ActorJWT


class SamplingRunCreateRequest(ProtocolModel):
    """``SamplingRunCreate`` Control 接口的已校验请求体。"""

    base_model: str
    source_checkpoint_uri: str = ""


class SamplingRunnerCapability(ProtocolResponseModel):
    """已调度 Sampler Runner 的请求容量。"""

    max_batch_size: int | None = Field(gt=0)
    max_tokens_per_request: int | None = Field(gt=0)
    max_seq_len: int | None = Field(gt=0)


class SamplingRunCreateResponse(ProtocolResponseModel):
    """``SamplingRunCreate`` Control 接口的已校验响应体。"""

    sampling_run_cuid: str
    service_session_cuid: str
    workspace_cuid: str
    status: str
    run_index: int
    model_spec_cuid: str
    model_alias: str = Field(min_length=1)
    model_id: str = Field(min_length=1)
    sampler: SamplingRunnerCapability
    actor: ActorConnectionInfo
    actor_jwt: ActorJWT
    created_at: datetime
    init_metadata: dict[str, object] | None = None
