"""定义 Control Actor 连接凭据接口的协议模型。"""

from datetime import datetime

from pytrio.protocol.base import ProtocolResponseModel


class ActorConnectionInfo(ProtocolResponseModel):
    """Control 返回的 Actor endpoint 与 TLS 信任信息。"""

    actor_cuid: str
    endpoint: str
    connect_mode: str
    tls_enabled: bool
    tls_cert_pem: str | None = None
    tls_not_after: datetime | None = None


class ActorJWT(ProtocolResponseModel):
    """访问指定 Actor 的短期 JWT 及其过期时间。"""

    token: str
    expires_at: datetime
