"""定义 Control API Key 校验接口的协议模型。"""

from datetime import datetime

from pytrio.protocol.base import ProtocolResponseModel


class APIKeyInfo(ProtocolResponseModel):
    """Control 校验 API Key 后返回的创建者与工作区身份。"""

    api_key_tid: str
    api_key_name: str | None
    user_cuid: str
    username: str
    display_name: str | None
    workspace_cuid: str
    workspace_name: str
    workspace_type: str
    expires_at: datetime | None
