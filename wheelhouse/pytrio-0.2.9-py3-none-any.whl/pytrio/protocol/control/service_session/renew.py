"""定义 Control 服务会话凭据续期接口的协议模型。"""

from datetime import datetime

from pytrio.protocol.base import ProtocolResponseModel


class ServiceSessionRenewResponse(ProtocolResponseModel):
    """``ServiceSessionRenew`` Control 接口的已校验响应体。"""

    service_session_cuid: str
    workspace_cuid: str
    status: str
    updated_at: datetime
