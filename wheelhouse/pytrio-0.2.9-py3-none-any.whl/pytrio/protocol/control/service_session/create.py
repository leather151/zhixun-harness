"""定义 Control 服务会话创建接口的协议模型。"""

from datetime import datetime

from pytrio.protocol.base import ProtocolModel, ProtocolResponseModel


class ServiceSessionCreateRequest(ProtocolModel):
    """``ServiceSessionCreate`` Control 接口的已校验请求体。"""

    sdk_version: str
    user_metadata: dict[str, object] | None = None


class ServiceSessionCreateResponse(ProtocolResponseModel):
    """``ServiceSessionCreate`` Control 接口的已校验响应体。"""

    service_session_cuid: str
    workspace_cuid: str
    status: str
    created_at: datetime
