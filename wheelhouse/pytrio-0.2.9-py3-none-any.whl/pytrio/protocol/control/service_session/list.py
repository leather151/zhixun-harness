"""定义 Control 服务会话列表接口的协议模型。"""

from pytrio.protocol.base import ProtocolResponseModel
from pytrio.protocol.control.common import ControlCursor
from pytrio.protocol.control.service_session.get import ServiceSessionListItemResponse


class ServiceSessionListResponse(ProtocolResponseModel):
    """``ServiceSessionList`` Control 接口的已校验响应体。"""

    service_sessions: list[ServiceSessionListItemResponse]
    cursor: ControlCursor
