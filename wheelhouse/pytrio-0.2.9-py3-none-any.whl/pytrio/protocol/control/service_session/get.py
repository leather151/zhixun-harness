"""定义 Control 服务会话查询接口的协议模型。"""

from datetime import datetime

from pytrio.protocol.base import ProtocolResponseModel


class ServiceSessionGetResponse(ProtocolResponseModel):
    """``ServiceSessionGet`` Control 接口的已校验响应体。"""

    service_session_cuid: str
    workspace_cuid: str
    status: str
    sdk_version: str | None = None
    training_run_cuids: list[str]
    sampling_run_cuids: list[str]
    created_at: datetime
    updated_at: datetime


class ServiceSessionListItemResponse(ProtocolResponseModel):
    """``ServiceSessionListItem`` Control 接口的已校验响应体。"""

    service_session_cuid: str
    workspace_cuid: str
    status: str
    sdk_version: str | None = None
    created_at: datetime
    updated_at: datetime
