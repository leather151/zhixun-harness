"""定义 Control 服务会话关闭接口的协议模型。"""

from typing import Literal

from pytrio.protocol.base import ProtocolModel

ServiceSessionCloseStatus = Literal["ENDED", "CANCELLED"]


class ServiceSessionCloseRequest(ProtocolModel):
    """``ServiceSessionClose`` 的关闭方式请求体。"""

    status: ServiceSessionCloseStatus
