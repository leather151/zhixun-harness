"""定义 Control 训练任务列表接口的协议模型。"""

from pytrio.protocol.base import ProtocolResponseModel
from pytrio.protocol.control.common import ControlCursor
from pytrio.protocol.control.training_run.get import TrainingRunGetResponse


class TrainingRunListResponse(ProtocolResponseModel):
    """``TrainingRunList`` Control 接口的已校验响应体。"""

    training_runs: list[TrainingRunGetResponse]
    cursor: ControlCursor
