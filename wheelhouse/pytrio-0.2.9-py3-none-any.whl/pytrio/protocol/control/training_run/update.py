"""定义 Control 训练任务初始化前恢复绑定的协议模型。"""

from pydantic import Field

from pytrio.protocol.base import ProtocolModel, ProtocolResponseModel
from pytrio.protocol.control.actor.credentials import ActorConnectionInfo, ActorJWT
from pytrio.protocol.control.training_run.create import TrainingRunnerCapability


class TrainingRunUpdateRequest(ProtocolModel):
    """``TrainingRunUpdate`` 的 checkpoint 恢复请求。"""

    source_checkpoint_uri: str = Field(min_length=1)
    restore_optimizer: bool


class TrainingRunUpdateResponse(ProtocolResponseModel):
    """Control 原子重绑定后 SDK 初始化需要的最终运行信息。"""

    source_checkpoint_uri: str = Field(min_length=1)
    restore_optimizer: bool
    trainer: TrainingRunnerCapability
    actor: ActorConnectionInfo
    actor_jwt: ActorJWT
