"""定义 Control 训练任务按 checkpoint URI 查询接口的协议模型。"""

from pytrio.protocol.base import ProtocolResponseModel


class TrainingRunFindByCheckpointURIResponse(ProtocolResponseModel):
    """``TrainingRunFindByCheckpointURI`` Control 接口的已校验响应体。"""

    base_model: str
    lora_rank: int
    seed: int | None = None
    train_mlp: bool
    train_attn: bool
    train_unembed: bool
