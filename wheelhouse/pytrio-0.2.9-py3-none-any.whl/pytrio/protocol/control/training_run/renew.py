"""定义 Control 训练任务凭据续期接口的协议模型。"""

from pytrio.protocol.base import ProtocolResponseModel
from pytrio.protocol.control.actor.credentials import ActorConnectionInfo, ActorJWT


class TrainingRunRenewResponse(ProtocolResponseModel):
    """``TrainingRunRenew`` Control 接口的已校验响应体。"""

    training_run_cuid: str
    service_session_cuid: str
    workspace_cuid: str
    actor: ActorConnectionInfo
    actor_jwt: ActorJWT
