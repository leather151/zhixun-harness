"""定义 Control 训练任务查询接口的协议模型。"""

from datetime import datetime

from pytrio.protocol.base import ProtocolResponseModel


class TrainingRunParamsResponse(ProtocolResponseModel):
    """``TrainingRunParams`` Control 接口的已校验响应体。"""

    restore_optimizer: bool
    lora_rank: int | None = None
    seed: int | None = None
    train_mlp: bool
    train_attn: bool
    train_unembed: bool


class TrainingRunGetResponse(ProtocolResponseModel):
    """``TrainingRunGet`` Control 接口的已校验响应体。"""

    training_run_cuid: str
    base_model: str
    service_session_cuid: str
    workspace_cuid: str
    status: str
    run_index: int
    model_spec_cuid: str
    is_lora: bool
    source_checkpoint_uri: str | None = None
    restore_optimizer: bool
    name: str | None = None
    lora_rank: int
    seed: int | None = None
    train_mlp: bool
    train_attn: bool
    train_unembed: bool
    corrupted: bool
    corrupted_reason: str | None = None
    training_params: TrainingRunParamsResponse
    created_at: datetime
    started_at: datetime | None = None
    ended_at: datetime | None = None
    updated_at: datetime
    user_metadata: dict[str, object] | None = None
