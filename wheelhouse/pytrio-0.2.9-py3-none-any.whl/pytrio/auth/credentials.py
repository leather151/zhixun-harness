"""读写当前环境的 API Key 凭据。"""

from pytrio.auth.user_info import AuthUserInfo
from pytrio.config.config import normalize_base_url, save_profile
from pytrio.config.models import ProfileConfig
from pytrio.errors.auth import AuthError


def save_credentials(env_name: str, user_info: AuthUserInfo) -> ProfileConfig:
    profile = ProfileConfig(
        api_key=user_info.api_key,
        base_url=normalize_base_url(user_info.base_url),
    )
    try:
        return save_profile(env_name, profile)
    except AuthError:
        raise
    except Exception as error:  # noqa: BLE001 - normalize the persistence boundary
        raise AuthError(
            f"Failed to save config file: {error}",
            code="auth.save_config_failed",
        ) from None
