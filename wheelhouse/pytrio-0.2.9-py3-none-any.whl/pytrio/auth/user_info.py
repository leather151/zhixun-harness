"""定义认证后的用户与工作区身份信息。"""

from dataclasses import dataclass


@dataclass(frozen=True)
class AuthUserInfo:
    """认证成功后的用户、工作区身份与凭据快照。"""

    user_cuid: str
    username: str
    display_name: str | None
    workspace_cuid: str
    workspace_name: str
    api_key_tid: str
    api_key: str
    base_url: str
