"""注册认证相关的命令行操作。"""

import click

from pytrio.auth.flow import (
    ensure_login,
    is_relogin_auth_error,
)
from pytrio.auth.prompt import PROMPT_PREFIX, prompt_api_key
from pytrio.config.config import (
    auth_state,
    clear_current_login_config,
    configuration,
    configure,
    profile_exists,
)
from pytrio.errors.auth import AuthError
from pytrio.errors.base import PyTrioError
from pytrio.logging.render import log_error, log_message


@click.option(
    "-k",
    "--api-key",
    type=str,
    help="API key to validate and save; prompt securely when omitted.",
)
@click.option(
    "-r",
    "--relogin",
    is_flag=True,
    help="Validate a new API key and replace the saved credentials.",
)
@click.option(
    "--base-url",
    type=str,
    metavar="URL",
    help="PyTrio service root URL for the active profile.",
)
def login(api_key: str | None, relogin: bool, base_url: str | None) -> None:
    """Authenticate the active server profile and save its credentials.

    With no options, validate the credentials already saved for the active
    profile. If there are no valid credentials, prompt securely for an API key.
    Successful authentication saves the key, user information, and normalized
    service URL in the active profile under ~/.pytrio.

    \b
    Examples:
      trio login
          Log in interactively, or verify the currently saved API key.

    \b
      trio login --api-key <key>
          Validate <key> and save it to the active profile.

    \b
      trio login --base-url https://beta.pytrio.com
          Log in to this service URL and save it to the active profile.

    \b
      trio login --relogin
          Prompt for a new key even when valid credentials are already saved.

    Failed authentication does not replace saved credentials. To create or
    select a named profile, use `trio env use NAME` first.
    """
    try:
        if auth_state.config_error is not None:
            raise auth_state.config_error
        if base_url is not None:
            configure(base_url=base_url)
        has_login_input = api_key is not None or base_url is not None or relogin
        if not has_login_input:
            existing_key = auth_state.api_key.strip()
            if existing_key:
                try:
                    ensure_login(api_key=existing_key, save=False)
                except PyTrioError as e:
                    if not is_relogin_auth_error(e):
                        raise
                    should_prompt = True
                else:
                    should_prompt = False
                if not should_prompt:
                    log_message(
                        "You are already logged in. Use `"
                        + click.style("trio login --relogin", bold=True)
                        + "` to force relogin."
                    )
                    return

        # A changed base URL must not silently reuse and persist the existing
        # key. Require an explicit key or a prompt before writing a profile.
        login_relogin = relogin or (base_url is not None and api_key is None)
        user_info = ensure_login(
            api_key=api_key,
            base_url=base_url,
            relogin=login_relogin,
            save=True,
            prompt_callback=prompt_api_key,
        )
        log_message(
            "Login successfully. Hi, "
            + click.style(user_info.display_name or user_info.username, bold=True)
            + "!"
        )
    except click.Abort:
        raise
    except PyTrioError as e:
        log_error(e)
        raise SystemExit(1) from None


def logout() -> None:
    """Remove credentials saved for the active server profile.

    This command asks for confirmation before changing local state. It does not
    revoke the API key on the PyTrio service and does not change the active
    profile.

    \b
    Example:
      trio env show    Confirm which profile is active
      trio logout      Remove that profile's local credentials

    For a named profile, its service URL and profile directory are preserved so
    it can be used and logged in again. To delete the whole named profile, run
    `trio env remove NAME`.
    """
    has_login_config = bool(auth_state.api_key or auth_state.config_error is not None)
    if profile_exists(configuration.active_env) or has_login_config:
        prompt = (
            PROMPT_PREFIX
            + "Are you sure you want to logout?"
            + click.style(" (y/N):", bold=True)
        )
        if not click.confirm(
            prompt,
            default=False,
            show_default=False,
            prompt_suffix=" ",
        ):
            log_message("Logout cancelled.")
            return

        try:
            clear_current_login_config()
        except AuthError as e:
            log_error(e)
            raise SystemExit(1) from None
        log_message(
            "Logout successfully. You can use `"
            + click.style("trio login", bold=True)
            + "` to login again."
        )
        return

    log_message(
        "You are not logged in. If you want to login in, please use `"
        + click.style("trio login", bold=True)
        + "` to login."
    )
