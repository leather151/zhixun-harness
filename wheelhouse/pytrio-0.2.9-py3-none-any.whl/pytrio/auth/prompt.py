"""从交互终端安全读取 API Key。"""

import signal
import sys
from collections.abc import Callable

import click

from pytrio.config.config import configuration
from pytrio.logging.render import PROMPT_PREFIX, log_message

try:
    import termios
    import tty
except ImportError:  # pragma: no cover - non-POSIX platform
    termios = None
    tty = None


def _read_masked_chunks(read_chunk: Callable[[], str]) -> str:
    """逐键读取输入并以掩码回显，直到收到换行或中断。"""
    characters: list[str] = []
    escape_sequence = ""

    while True:
        chunk = read_chunk()
        if chunk == "":
            raise EOFError

        for character in chunk:
            if character == "\x03":
                raise KeyboardInterrupt
            if character == "\x04":
                raise EOFError
            if escape_sequence == "\x1b":
                escape_sequence = "\x1b[" if character == "[" else ""
                continue
            if escape_sequence.startswith("\x1b["):
                if 0x40 <= ord(character) <= 0x7E:
                    escape_sequence = ""
                continue
            if character == "\x1b":
                escape_sequence = "\x1b"
                continue
            if character in ("\r", "\n"):
                click.echo()
                return "".join(characters)
            if character in ("\b", "\x7f"):
                if characters:
                    characters.pop()
                    click.echo("\b \b", nl=False)
                continue
            if character.isprintable():
                characters.append(character)
                click.echo("*", nl=False)


def _read_masked_from_terminal() -> str:
    if termios is None or tty is None or not sys.stdin.isatty():
        return _read_masked_chunks(lambda: click.getchar(echo=False))

    fd = sys.stdin.fileno()
    original_attrs = termios.tcgetattr(fd)
    try:
        tty.setcbreak(fd)
        return _read_masked_chunks(lambda: sys.stdin.read(1))
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, original_attrs)


def _prompt_masked(prompt: str) -> str:
    click.echo(f"{prompt}: ", nl=False)
    try:
        return _read_masked_from_terminal()
    except (KeyboardInterrupt, EOFError):
        click.echo()
        raise click.Abort() from None


def prompt_api_key() -> str:
    log_message(
        "You can find your API key at: "
        + click.style(configuration.base_url, fg=(229, 229, 18))
    )
    original_sigint_handler = signal.getsignal(signal.SIGINT)
    try:
        _ = signal.signal(signal.SIGINT, signal.default_int_handler)
        try:
            api_key = _prompt_masked(
                PROMPT_PREFIX
                + "Paste an API key from your profile and hit enter, or press 'Ctrl+C' to quit",
            )
        except KeyboardInterrupt:
            raise click.Abort() from None
    finally:
        _ = signal.signal(signal.SIGINT, original_sigint_handler)

    return str(api_key).strip()
