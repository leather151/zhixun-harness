"""编排 SDK 环境配置的命令行交互。"""

import click

from pytrio.auth.credentials import save_credentials
from pytrio.auth.flow import ensure_login
from pytrio.auth.prompt import prompt_api_key
from pytrio.auth.user_info import AuthUserInfo
from pytrio.config.config import (
    DEFAULT_BASE_URL,
    DEFAULT_ENV,
    configuration,
    current_env_info,
    display_env_name,
    list_envs,
    load_login_config,
    normalize_env_name,
    remove_env,
    set_active_env,
    use_env,
)
from pytrio.config.models import EnvironmentInfo
from pytrio.errors.base import PyTrioError
from pytrio.logging.render import log_error, log_message


def _status_text(logged_in: bool, has_error: bool) -> str:
    if has_error:
        return "error"
    if logged_in:
        return "logged in"
    return "not logged in"


def _authenticate_before_persisting_env(
    name: str | None,
    base_url: str,
) -> tuple[EnvironmentInfo, AuthUserInfo]:
    """在写入环境配置前使用候选地址和 API Key 完成认证。"""
    env_name = normalize_env_name(name)
    previous_base_url = configuration.base_url
    try:
        user_info = ensure_login(
            base_url=base_url,
            relogin=True,
            save=False,
            prompt_callback=prompt_api_key,
        )
    except (click.Abort, PyTrioError):
        configuration.base_url = previous_base_url
        raise

    if env_name == DEFAULT_ENV:
        set_active_env(DEFAULT_ENV)
        save_credentials(env_name, user_info)
    else:
        save_credentials(env_name, user_info)
        set_active_env(env_name)
    load_login_config()
    return current_env_info(), user_info


def _target_env_info(name: str | None) -> EnvironmentInfo | None:
    env_name = normalize_env_name(name)
    for info in list_envs():
        if info.name == env_name:
            return info
    return None


@click.group(name="env")
def env() -> None:
    """Manage local PyTrio server profiles and their saved credentials.

    A profile selects the service URL and credentials used by the CLI and SDK.
    The active profile is persisted locally under ~/.pytrio; switching profiles
    does not modify resources on a PyTrio service.

    \b
    Examples:
      trio env list
      trio env use myprofile
      trio env use myprofile --base-url https://pytrio.com
      trio env show
      trio env remove myprofile
    """


@env.command(name="list")
def list_command() -> None:
    """List local server profiles, URLs, and login states.

    The leading `*` marks the active profile. Status is `logged in`,
    `not logged in`, or `error` when a saved configuration cannot be loaded.

    \b
    Example:
      $ trio env list
        (default)  https://pytrio.com       not logged in
      * dev        https://beta.pytrio.com  logged in

    This command only reads local profile configuration.
    """
    env_infos = list_envs()
    name_width = max(len(display_env_name(info.name)) for info in env_infos)
    base_url_width = max(len(info.base_url or "-") for info in env_infos)
    for info in env_infos:
        marker = "*" if info.current else " "
        name = display_env_name(info.name)
        base_url = info.base_url or "-"
        status = _status_text(info.logged_in, info.config_error is not None)
        click.echo(
            f"{marker} {name:<{name_width}}  {base_url:<{base_url_width}}  {status}"
        )


@env.command(name="show")
def show_command() -> None:
    """Show details for the active server profile.

    Output includes the profile name, effective service URL, configuration file
    path, and login state.

    \b
    Example:
      $ trio env show
      env: dev
      base_url: https://beta.pytrio.com
      config: /home/user/.pytrio/envs/dev/config.toml
      status: logged in

    This command only reads local profile configuration. It exits with an error
    after displaying details if the active configuration is invalid.
    """
    info = current_env_info()
    status = _status_text(info.logged_in, info.config_error is not None)
    click.echo(f"env: {display_env_name(info.name)}")
    click.echo(f"base_url: {info.base_url or '-'}")
    click.echo(f"config: {info.config_path}")
    click.echo(f"status: {status}")
    if info.config_error is not None:
        log_error(info.config_error)
        raise SystemExit(1)


@env.command(name="use")
@click.argument("name", required=False)
@click.option(
    "--base-url",
    type=str,
    metavar="URL",
    help="Service root URL used when creating or updating the profile.",
)
def use_command(name: str | None, base_url: str | None) -> None:
    """Switch to a server profile, creating and authenticating it if needed.

    NAME identifies a local named profile. Omit NAME or use `default` or
    `(default)` to switch to the default profile. Switching to an existing
    profile keeps its saved URL and credentials; a logged-out profile is not
    logged in automatically.

    \b
    Examples:
      trio env use [default]
          Switch to the default profile; its reserved name is optional.

    \b
      trio env use myprofile
          Switch to the profile named `myprofile`; if it does not exist,
          authenticate against the default PyTrio service and create it after
          login succeeds.

    \b
      trio env use myprofile --base-url https://pytrio.com
          Use `myprofile` as the local profile name and
          https://pytrio.com as its PyTrio service root URL.
          Authenticate first, then create or update the profile configuration
          and make it active.

    When authentication is required, no profile is created or overwritten and
    the active profile is unchanged unless login succeeds.
    """
    user_info: AuthUserInfo | None
    try:
        if base_url is None:
            target_info = _target_env_info(name)
            if target_info is None:
                info, user_info = _authenticate_before_persisting_env(
                    name,
                    DEFAULT_BASE_URL,
                )
            elif target_info.config_error is not None:
                raise target_info.config_error
            elif target_info.logged_in:
                info = use_env(name)
                user_info = None
            else:
                info = use_env(name)
                user_info = None
        else:
            info, user_info = _authenticate_before_persisting_env(name, base_url)
    except PyTrioError as e:
        log_error(e)
        raise SystemExit(1) from None

    log_message(
        "Using PyTrio server profile "
        + click.style(display_env_name(info.name), bold=True)
        + "."
    )
    if info.config_error is not None:
        log_error(info.config_error)
        raise SystemExit(1) from None

    if user_info is not None:
        log_message(
            "Login successfully. Hi, "
            + click.style(user_info.display_name or user_info.username, bold=True)
            + "!"
        )
        return

    if not info.logged_in:
        log_message(
            "Run `" + click.style("trio login", bold=True) + "` to authenticate."
        )


@env.command(name="remove")
@click.argument("name")
@click.option(
    "-y",
    "--yes",
    is_flag=True,
    help="Remove without interactive confirmation.",
)
def remove_command(name: str, yes: bool) -> None:
    """Delete a named profile and all credentials saved in it.

    The default profile cannot be removed. Confirmation is required unless
    --yes is given. If NAME is active, the default profile becomes active before
    the named profile directory is deleted.

    \b
    Examples:
      trio env remove dev        Ask before deleting `dev`
      trio env remove dev --yes  Delete `dev` without prompting

    This only deletes local files; it does not revoke credentials or modify the
    PyTrio service.
    """
    try:
        env_name = normalize_env_name(name)
        if env_name == DEFAULT_ENV:
            _ = remove_env(env_name)
    except PyTrioError as e:
        log_error(e)
        raise SystemExit(1) from None

    if not yes:
        prompt = (
            "Remove server profile "
            + click.style(display_env_name(env_name), bold=True)
            + " and its saved credentials?"
        )
        if not click.confirm(prompt, default=False):
            log_message("Server profile remove cancelled.")
            return

    try:
        result = remove_env(env_name)
    except PyTrioError as e:
        log_error(e)
        raise SystemExit(1) from None

    log_message(
        "Removed server profile "
        + click.style(display_env_name(result.name), bold=True)
        + "."
    )
    if result.switched_to_default:
        log_message(
            "Active server profile switched to "
            + click.style("(default)", bold=True)
            + "."
        )
