"""编排 API Key 校验、登录和凭据持久化。"""

import asyncio
import logging
from collections.abc import Callable, Coroutine
from typing import Protocol

from pytrio.auth.credentials import save_credentials
from pytrio.auth.user_info import AuthUserInfo
from pytrio.config.config import (
    Configuration,
    auth_state,
    configuration,
    configure,
    set_login_profile,
)
from pytrio.errors.auth import AuthError
from pytrio.errors.base import PyTrioError
from pytrio.errors.control import ControlAPIError
from pytrio.logging.render import log_message
from pytrio.protocol.control.api_key.verify import APIKeyInfo
from pytrio.runtime.event_loop import SDKEventLoopRunner
from pytrio.transport.control.http_client import ControlHTTPClient

logger = logging.getLogger(__name__)


class APIKeyVerifier(Protocol):
    """认证流程依赖的最小 Control Client 契约。"""

    async def verify_api_key(self) -> APIKeyInfo:
        raise NotImplementedError

    async def aclose(self) -> None:
        raise NotImplementedError


def is_relogin_auth_error(error: PyTrioError) -> bool:
    return (
        error.code == "unauthorized"
        or error.code == "api_key_expired"
        or error.code == "api_key_revoked"
        or error.code == "api_key_disabled"
        or error.code == "forbidden"
    )


async def check_api_key(
    control_client: APIKeyVerifier,
    api_key: str,
    *,
    base_url: str | None = None,
) -> AuthUserInfo:
    """校验 API Key 并转换为 SDK 用户与工作区身份。

    Args:
        control_client: 已使用待校验 API Key 构造的 Control Client。
        api_key: 返回身份对象需要保留的 API Key。

    Returns:
        已验证的用户、工作区身份和当前服务地址。

    Raises:
        AuthError: Control 拒绝凭据或校验请求失败。
    """
    try:
        logger.debug("Verifying API key against Trio Control")
        api_key_info = await control_client.verify_api_key()
        logger.debug(
            "Verified API key for workspace=%s",
            api_key_info.workspace_cuid,
        )
        return AuthUserInfo(
            user_cuid=api_key_info.user_cuid,
            username=api_key_info.username,
            display_name=api_key_info.display_name,
            workspace_cuid=api_key_info.workspace_cuid,
            workspace_name=api_key_info.workspace_name,
            api_key_tid=api_key_info.api_key_tid,
            api_key=api_key,
            base_url=configuration.base_url if base_url is None else base_url,
        )
    except ControlAPIError:
        # Control 已提供稳定的 message/code/status 和 SDK code-based hint；认证编排
        # 不重新构造异常，避免覆盖服务端原文、来源和请求上下文。
        raise
    except Exception as e:
        if isinstance(e, PyTrioError):
            raise
        raise AuthError(
            str(e),
            code="auth.verify_failed",
            operation="auth.verify_api_key",
        ) from None


async def close_control_client(control_client: APIKeyVerifier) -> None:
    try:
        await control_client.aclose()
    except Exception:  # noqa: BLE001,S110 - cleanup must not mask authentication
        pass


async def authenticate_api_key_async(
    api_key: str,
    *,
    runtime_configuration: Configuration | None = None,
) -> AuthUserInfo:
    """Verify one API key without prompting or changing persistent state."""
    resolved_api_key = str(api_key).strip()
    if not resolved_api_key:
        raise AuthError("API key cannot be empty", code="auth.missing_api_key")

    client = ControlHTTPClient(
        api_key=resolved_api_key,
        runtime_configuration=runtime_configuration,
    )
    try:
        base_url = (
            configuration.base_url
            if runtime_configuration is None
            else runtime_configuration.base_url
        )
        return await check_api_key(client, resolved_api_key, base_url=base_url)
    finally:
        await close_control_client(client)


def authenticate_api_key(
    api_key: str,
    *,
    runtime_configuration: Configuration | None = None,
) -> AuthUserInfo:
    """Synchronously verify one API key without persistence side effects."""
    return _run_auth_coroutine(
        authenticate_api_key_async(
            api_key,
            runtime_configuration=runtime_configuration,
        )
    )


def _missing_prompt_callback() -> str:
    raise AuthError("API key is required", code="auth.missing_api_key")


async def ensure_login_async(
    api_key: str | None = None,
    base_url: str | None = None,
    relogin: bool = False,
    save: bool = True,
    show_success_message: bool = False,
    prompt_callback: Callable[[], str] = _missing_prompt_callback,
) -> AuthUserInfo:
    """解析、校验并按策略保存 SDK 登录凭据。

    Args:
        api_key: 显式 API Key；未提供时优先读取当前环境保存的凭据。
        base_url: 本次认证使用的服务根地址。
        relogin: 是否跳过已保存凭据并重新解析 API Key。
        save: 是否把验证成功的凭据保存到当前环境。
        show_success_message: 交互输入成功后是否输出登录消息。
        prompt_callback: 没有可用凭据时读取 API Key 的回调。

    Returns:
        已验证的用户与工作区身份。

    Raises:
        AuthError: 配置无效、凭据缺失或 Control 校验失败。
    """
    if auth_state.config_error is not None:
        raise auth_state.config_error
    if base_url is not None:
        logger.debug("Applying explicit base_url override=%s", base_url)
        configure(base_url=base_url)

    if not relogin and not api_key:
        # 已保存凭据验证失败且属于可重新登录的认证错误时，交互调用继续使用 prompt；
        # 非交互调用直接保留原始失败语义。
        existing_key = auth_state.api_key.strip()
        if existing_key:
            logger.debug("Attempting login with saved API key from config")
            control_client = ControlHTTPClient(api_key=existing_key)
            try:
                try:
                    user_info = await check_api_key(control_client, existing_key)
                except PyTrioError as e:
                    logger.debug(
                        "Saved API key verification failed code=%s prompted=%s",
                        e.code,
                        prompt_callback is not _missing_prompt_callback,
                    )
                    if (
                        not is_relogin_auth_error(e)
                        or prompt_callback is _missing_prompt_callback
                    ):
                        raise
                else:
                    logger.debug(
                        "Saved API key accepted for workspace=%s",
                        user_info.workspace_cuid,
                    )
                    if save:
                        profile = save_credentials(
                            configuration.active_env,
                            user_info,
                        )
                        set_login_profile(profile)
                    return user_info
            finally:
                await close_control_client(control_client)

    prompted_for_api_key = False
    if api_key:
        resolved_api_key = str(api_key).strip()
        logger.debug("Using explicit API key provided to ensure_login")
    else:
        logger.debug("Resolving API key through prompt callback")
        resolved_api_key = str(prompt_callback()).strip()
        prompted_for_api_key = prompt_callback is not _missing_prompt_callback
    if not resolved_api_key:
        raise AuthError("API key cannot be empty", code="auth.missing_api_key")

    control_client = ControlHTTPClient(api_key=resolved_api_key)
    try:
        user_info = await check_api_key(control_client, resolved_api_key)
    finally:
        await close_control_client(control_client)

    if save:
        logger.debug("Saving verified login config to %s", configuration.config_path)
        profile = save_credentials(configuration.active_env, user_info)
        set_login_profile(profile)
    if show_success_message and prompted_for_api_key:
        log_message(
            f"Login successfully. Hi, {user_info.display_name or user_info.username}!"
        )
    logger.debug("Login resolved for workspace=%s", user_info.workspace_cuid)
    return user_info


def _run_auth_coroutine(coro: Coroutine[object, object, AuthUserInfo]) -> AuthUserInfo:
    """Run async authentication from synchronous CLI and constructor boundaries."""
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)

    try:
        event_loop = SDKEventLoopRunner()
    except BaseException:
        coro.close()
        raise
    try:
        return event_loop.run_sync(coro)
    finally:
        event_loop.close()


def ensure_login(
    api_key: str | None = None,
    base_url: str | None = None,
    relogin: bool = False,
    save: bool = True,
    show_success_message: bool = False,
    prompt_callback: Callable[[], str] = _missing_prompt_callback,
) -> AuthUserInfo:
    """Synchronously authenticate while all Control I/O remains asynchronous."""
    return _run_auth_coroutine(
        ensure_login_async(
            api_key=api_key,
            base_url=base_url,
            relogin=relogin,
            save=save,
            show_success_message=show_success_message,
            prompt_callback=prompt_callback,
        )
    )
