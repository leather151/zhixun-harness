"""编排 Control 元数据查询与 checkpoint 下载。"""

import functools
import logging
from collections.abc import Callable, Coroutine, Mapping
from concurrent.futures import Future as ConcurrentFuture
from dataclasses import dataclass
from pathlib import Path
from typing import Literal, TypeVar
from urllib.parse import urlsplit

from pytrio.client.adapters.rest.checkpoint import (
    archive_url_from_download,
    checkpoints_from_control,
    download_url_from_control,
)
from pytrio.client.adapters.rest.sampling_run import sampling_run_from_control
from pytrio.client.adapters.rest.service_session import (
    service_session_from_control,
    service_sessions_from_control,
)
from pytrio.client.adapters.rest.training_run import (
    training_run_from_control,
    training_runs_from_control,
)
from pytrio.errors.base import PyTrioError, ValidationError
from pytrio.errors.control import ControlAPIError
from pytrio.logging.render import LogField, LogLevel, log_user_message
from pytrio.protocol.control.checkpoint.list import (
    CheckpointListResponse as ControlCheckpointListResponse,
)
from pytrio.runtime.event_loop import SDKEventLoopRunner
from pytrio.runtime.service import ServiceRuntime
from pytrio.transport.control.http_client import ControlHTTPClient
from pytrio.transport.download import Downloader, DownloadSource
from pytrio.types.future.api_future import APIFuture
from pytrio.types.rest import (
    CheckpointArchiveUrlResponse,
    CheckpointDownloadResult,
    CheckpointDownloadSource,
    CheckpointsListResponse,
    GetSamplerResponse,
    GetSessionResponse,
    ListSessionsResponse,
    TrainingRun,
    TrainingRunsResponse,
)

T = TypeVar("T")
AccessScope = Literal["owned", "accessible"]
logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class CheckpointArchiveStatusLog:
    """checkpoint 归档失败状态对应的用户日志策略。"""

    level: LogLevel
    reason: str


_CHECKPOINT_ARCHIVE_DEFAULT_LOG = CheckpointArchiveStatusLog(
    "WARNING",
    "download URL request failed",
)

_CHECKPOINT_ARCHIVE_STATUS_LOGS: Mapping[int, CheckpointArchiveStatusLog] = {
    400: CheckpointArchiveStatusLog("WARNING", "invalid path parameters"),
    401: CheckpointArchiveStatusLog("WARNING", "unauthorized request"),
    403: CheckpointArchiveStatusLog("WARNING", "forbidden request"),
    404: CheckpointArchiveStatusLog(
        "WARNING",
        "checkpoint not found, inaccessible, or not downloadable",
    ),
    409: CheckpointArchiveStatusLog("INFO", "checkpoint status is not downloadable"),
    429: CheckpointArchiveStatusLog("WARNING", "rate limited request"),
    500: CheckpointArchiveStatusLog("ERROR", "internal server error"),
    503: CheckpointArchiveStatusLog("WARNING", "auth service unavailable"),
}


class RestClient:
    """Query Control metadata and download checkpoints.

    The client shares the ``ServiceRuntime`` Control connection and SDK-owned
    event loop. Synchronous methods return waitable concurrent futures, while
    ``*_async`` methods return domain results directly.

    Args:
        runtime: Runtime shared with the root service client.
        downloader: Checkpoint downloader. A default downloader is created when
            omitted.
    """

    def __init__(
        self,
        runtime: ServiceRuntime,
        downloader: Downloader | None = None,
    ) -> None:
        self._runtime: ServiceRuntime = runtime
        self._control_client: ControlHTTPClient = runtime.control_client
        self._event_loop: SDKEventLoopRunner = runtime.event_loop
        self._downloader: Downloader = (
            Downloader(runtime_configuration=runtime.configuration)
            if downloader is None
            else downloader
        )

    def get_training_run(
        self,
        training_run_id: str,
        access_scope: AccessScope = "owned",
    ) -> ConcurrentFuture[TrainingRun]:
        """Submit a training run metadata query.

        Args:
            training_run_id: Training run ID.
            access_scope: Query resources owned by or accessible to the workspace.

        Returns:
            A concurrent future that resolves to training run metadata.
        """
        return self._submit_to_sdk_loop(
            self.get_training_run_async(training_run_id, access_scope=access_scope)
        )

    async def get_training_run_async(
        self,
        training_run_id: str,
        access_scope: AccessScope = "owned",
    ) -> TrainingRun:
        """Query training run metadata asynchronously.

        Args:
            training_run_id: Training run ID.
            access_scope: Query resources owned by or accessible to the workspace.

        Returns:
            Validated training run metadata.
        """
        self._require_non_empty("training_run_id", training_run_id)
        response = await self._call_control(
            functools.partial(
                self._control_client.get_training_run,
                training_run_id,
                access_scope=access_scope,
            )
        )
        return training_run_from_control(response)

    def list_training_runs(
        self,
        limit: int = 20,
        offset: int = 0,
        access_scope: AccessScope = "owned",
    ) -> ConcurrentFuture[TrainingRunsResponse]:
        """Submit a paginated training run query.

        Args:
            limit: Maximum records in the page.
            offset: Starting record offset.
            access_scope: Query resources owned by or accessible to the workspace.

        Returns:
            A concurrent future that resolves to a training run page.
        """
        return self._submit_to_sdk_loop(
            self.list_training_runs_async(
                limit=limit, offset=offset, access_scope=access_scope
            )
        )

    async def list_training_runs_async(
        self,
        limit: int = 20,
        offset: int = 0,
        access_scope: AccessScope = "owned",
    ) -> TrainingRunsResponse:
        """Query a page of training runs asynchronously.

        Args:
            limit: Maximum records in the page.
            offset: Starting record offset.
            access_scope: Query resources owned by or accessible to the workspace.

        Returns:
            Training runs and the page cursor.
        """
        response = await self._call_control(
            functools.partial(
                self._control_client.list_training_runs,
                limit=limit,
                offset=offset,
                access_scope=access_scope,
            )
        )
        return training_runs_from_control(response)

    def list_checkpoints(
        self, training_run_id: str
    ) -> ConcurrentFuture[CheckpointsListResponse]:
        """Submit a query for all checkpoints in one training run.

        Args:
            training_run_id: Training run ID.

        Returns:
            A concurrent future that resolves to the complete checkpoint list.
        """
        return self._submit_to_sdk_loop(self.list_checkpoints_async(training_run_id))

    async def list_checkpoints_async(
        self, training_run_id: str
    ) -> CheckpointsListResponse:
        """Query all checkpoints in one training run asynchronously.

        Args:
            training_run_id: Training run ID.

        Returns:
            The complete checkpoint list in Control order.
        """
        self._require_non_empty("training_run_id", training_run_id)
        first_page = await self._call_control(
            functools.partial(
                self._control_client.list_training_run_checkpoints,
                training_run_id,
                limit=200,
                offset=0,
            )
        )
        checkpoints = list(first_page.checkpoints)
        cursor = first_page.cursor
        offset = cursor.offset + cursor.limit
        has_items = bool(first_page.checkpoints)
        while offset < cursor.total and has_items:
            page = await self._call_control(
                functools.partial(
                    self._control_client.list_training_run_checkpoints,
                    training_run_id,
                    limit=200,
                    offset=offset,
                )
            )
            checkpoints.extend(page.checkpoints)
            has_items = bool(page.checkpoints)
            cursor = page.cursor
            offset = cursor.offset + cursor.limit
        response = ControlCheckpointListResponse(checkpoints=checkpoints, cursor=cursor)
        return checkpoints_from_control(response, cursor=False)

    def list_user_checkpoints(
        self,
        limit: int = 100,
        offset: int = 0,
    ) -> ConcurrentFuture[CheckpointsListResponse]:
        """Submit a paginated workspace checkpoint query.

        Args:
            limit: Maximum records in the page.
            offset: Starting record offset.

        Returns:
            A concurrent future that resolves to a checkpoint page.
        """
        return self._submit_to_sdk_loop(
            self.list_user_checkpoints_async(limit=limit, offset=offset)
        )

    async def list_user_checkpoints_async(
        self,
        limit: int = 100,
        offset: int = 0,
    ) -> CheckpointsListResponse:
        """Query a page of workspace checkpoints asynchronously.

        Args:
            limit: Maximum records in the page.
            offset: Starting record offset.

        Returns:
            Checkpoints and the page cursor.
        """
        response = await self._call_control(
            functools.partial(
                self._control_client.list_checkpoints,
                limit=limit,
                offset=offset,
            )
        )
        return checkpoints_from_control(response)

    def get_checkpoint_archive_url(
        self,
        checkpoint_id: str,
    ) -> ConcurrentFuture[CheckpointArchiveUrlResponse]:
        """Submit a checkpoint download URL query.

        Args:
            checkpoint_id: Checkpoint ID.

        Returns:
            A concurrent future that resolves to the current download URL and expiry.
        """
        return self._submit_to_sdk_loop(
            self.get_checkpoint_archive_url_async(checkpoint_id)
        )

    def get_checkpoint_download_url(
        self,
        checkpoint_id: str,
    ) -> ConcurrentFuture[CheckpointDownloadSource]:
        """Submit a checkpoint download source query.

        Args:
            checkpoint_id: Checkpoint ID.

        Returns:
            A concurrent future that resolves to download and TLS metadata.
        """
        return self._submit_to_sdk_loop(
            self.get_checkpoint_download_url_async(checkpoint_id)
        )

    def download_checkpoint(
        self,
        checkpoint_id: str,
        destination_path: str | Path,
        *,
        resume: bool = True,
    ) -> ConcurrentFuture[CheckpointDownloadResult]:
        """Submit a checkpoint download to local storage.

        Args:
            checkpoint_id: Checkpoint ID.
            destination_path: Local destination file.
            resume: Whether to resume from the existing file size.

        Returns:
            A concurrent future that resolves to the local download result.
        """
        return self._submit_to_sdk_loop(
            self.download_checkpoint_async(
                checkpoint_id,
                destination_path,
                resume=resume,
            )
        )

    async def get_checkpoint_archive_url_async(
        self,
        checkpoint_id: str,
    ) -> CheckpointArchiveUrlResponse:
        """Query a checkpoint download URL asynchronously.

        Args:
            checkpoint_id: Checkpoint ID.

        Returns:
            The current download URL and its expiry.
        """
        self._require_non_empty("checkpoint_id", checkpoint_id)
        try:
            response = await self._call_control(
                functools.partial(
                    self._control_client.get_checkpoint_download_url,
                    checkpoint_id,
                )
            )
        except ControlAPIError as e:
            status_log = _CHECKPOINT_ARCHIVE_STATUS_LOGS.get(
                e.status_code,
                _CHECKPOINT_ARCHIVE_DEFAULT_LOG,
            )
            fields = [LogField("Checkpoint", checkpoint_id)]
            if e.status_code > 0:
                fields.append(LogField("Status", e.status_code))
            if e.code:
                fields.append(LogField("Code", e.code))
            fields.append(LogField("Reason", status_log.reason))
            if e.message:
                fields.append(LogField("Message", e.message))
            log_user_message(
                logger,
                status_log.level,
                "Checkpoint download URL request failed.",
                fields=fields,
            )
            raise
        return archive_url_from_download(response)

    async def get_checkpoint_download_url_async(
        self,
        checkpoint_id: str,
    ) -> CheckpointDownloadSource:
        """Query the current checkpoint download source asynchronously.

        Args:
            checkpoint_id: Checkpoint ID.

        Returns:
            Download URL, source, status, and Actor TLS metadata.
        """
        self._require_non_empty("checkpoint_id", checkpoint_id)
        response = await self._call_control(
            functools.partial(
                self._control_client.get_checkpoint_download_url,
                checkpoint_id,
            )
        )
        return download_url_from_control(checkpoint_id, response)

    async def download_checkpoint_async(
        self,
        checkpoint_id: str,
        destination_path: str | Path,
        *,
        resume: bool = True,
    ) -> CheckpointDownloadResult:
        """Download a checkpoint asynchronously on the SDK-owned event loop.

        Args:
            checkpoint_id: Checkpoint ID.
            destination_path: Local destination file.
            resume: Whether to resume from the existing file size.

        Returns:
            Bytes written and the final local file state.
        """
        self._require_non_empty("checkpoint_id", checkpoint_id)
        path = Path(destination_path)
        return await self._run_on_sdk_loop(
            self._download_checkpoint(
                checkpoint_id,
                path,
                resume=resume,
            )
        )

    def delete_checkpoint(
        self,
        training_run_id: str,
        checkpoint_id: str,
    ) -> ConcurrentFuture[None]:
        """Submit a checkpoint deletion.

        Args:
            training_run_id: Training run that owns the checkpoint.
            checkpoint_id: Checkpoint ID.

        Returns:
            A concurrent future that resolves when deletion completes.
        """
        return self._submit_to_sdk_loop(
            self.delete_checkpoint_async(training_run_id, checkpoint_id)
        )

    async def delete_checkpoint_async(
        self, training_run_id: str, checkpoint_id: str
    ) -> None:
        """Delete a checkpoint asynchronously.

        Args:
            training_run_id: Training run that owns the checkpoint. The SDK validates
                this identifier before submission.
            checkpoint_id: Checkpoint ID.
        """
        self._require_non_empty("training_run_id", training_run_id)
        self._require_non_empty("checkpoint_id", checkpoint_id)
        await self._call_control(
            functools.partial(self._control_client.delete_checkpoint, checkpoint_id)
        )

    def get_session(
        self,
        session_id: str,
        access_scope: AccessScope = "owned",
    ) -> ConcurrentFuture[GetSessionResponse]:
        """Submit a service session metadata query.

        Args:
            session_id: Service session ID.
            access_scope: Query resources owned by or accessible to the workspace.

        Returns:
            A concurrent future that resolves to the session's run IDs.
        """
        return self._submit_to_sdk_loop(
            self.get_session_async(session_id, access_scope=access_scope)
        )

    async def get_session_async(
        self,
        session_id: str,
        access_scope: AccessScope = "owned",
    ) -> GetSessionResponse:
        """Query runs associated with a service session asynchronously.

        Args:
            session_id: Service session ID.
            access_scope: Query resources owned by or accessible to the workspace.

        Returns:
            Training and sampling run IDs associated with the session.
        """
        self._require_non_empty("session_id", session_id)
        response = await self._call_control(
            functools.partial(
                self._control_client.get_service_session,
                session_id,
                access_scope=access_scope,
            )
        )
        return service_session_from_control(response)

    def list_sessions(
        self,
        limit: int = 20,
        offset: int = 0,
        access_scope: AccessScope = "owned",
    ) -> ConcurrentFuture[ListSessionsResponse]:
        """Submit a paginated service session query.

        Args:
            limit: Maximum records in the page.
            offset: Starting record offset.
            access_scope: Query resources owned by or accessible to the workspace.

        Returns:
            A concurrent future that resolves to service session IDs.
        """
        return self._submit_to_sdk_loop(
            self.list_sessions_async(
                limit=limit, offset=offset, access_scope=access_scope
            )
        )

    async def list_sessions_async(
        self,
        limit: int = 20,
        offset: int = 0,
        access_scope: AccessScope = "owned",
    ) -> ListSessionsResponse:
        """Query a page of service sessions asynchronously.

        Args:
            limit: Maximum records in the page.
            offset: Starting record offset.
            access_scope: Query resources owned by or accessible to the workspace.

        Returns:
            Service session IDs in the current page.
        """
        response = await self._call_control(
            functools.partial(
                self._control_client.list_service_sessions,
                limit=limit,
                offset=offset,
                access_scope=access_scope,
            )
        )
        return service_sessions_from_control(response)

    def get_sampler(self, sampler_id: str) -> APIFuture[GetSamplerResponse]:
        """Submit a sampling run metadata query.

        Args:
            sampler_id: Sampling run ID.

        Returns:
            An API future that resolves to sampling run metadata.
        """
        return APIFuture(self._submit_to_sdk_loop(self.get_sampler_async(sampler_id)))

    async def get_sampler_async(self, sampler_id: str) -> GetSamplerResponse:
        """Query sampling run metadata asynchronously.

        Args:
            sampler_id: Sampling run ID.

        Returns:
            Base model and weight URI used by the sampling run.
        """
        self._require_non_empty("sampler_id", sampler_id)
        response = await self._call_control(
            functools.partial(self._control_client.get_sampling_run, sampler_id)
        )
        return sampling_run_from_control(response)

    async def _call_control(
        self,
        call: Callable[[], Coroutine[object, object, T]],
    ) -> T:
        """Execute one Control request on the runtime-owned event loop."""
        return await self._run_on_sdk_loop(call())

    async def _download_checkpoint(
        self,
        checkpoint_id: str,
        path: Path,
        *,
        resume: bool,
    ) -> CheckpointDownloadResult:
        """执行可刷新异步下载并补充领域错误上下文。"""

        async def fetch_download_source() -> DownloadSource:
            response = await self._control_client.get_checkpoint_download_url(
                checkpoint_id
            )
            return DownloadSource(
                url=response.url,
                expires_at=response.expires_at,
                source=response.source,
                tls_cert_pem=response.tls_cert_pem,
                tls_not_after=response.tls_not_after,
            )

        active_source = await fetch_download_source()

        # 下载器每次判断 URL 或 Actor 证书临近过期时，通过闭包获取同一 checkpoint
        # 的最新下载源；错误包装使用最后一次实际访问的源信息。
        async def refresh_download_source() -> DownloadSource:
            nonlocal active_source
            active_source = await fetch_download_source()
            return active_source

        try:
            result = await self._downloader.download(
                active_source,
                path,
                resume=resume,
                refresh_source=refresh_download_source,
            )
        except ControlAPIError:
            raise
        except PyTrioError as error:
            parsed_url = urlsplit(active_source.url)
            server_netloc = parsed_url.netloc.rsplit("@", 1)[-1]
            server = f"{parsed_url.scheme}://{server_netloc}"
            error.source = error.source or active_source.source
            error.operation = error.operation or "checkpoint.download"
            error.server = error.server or server
            raise
        return CheckpointDownloadResult(
            checkpoint_id=checkpoint_id,
            path=str(result.path),
            bytes_written=result.bytes_written,
            file_size_bytes=result.file_size_bytes,
            status_code=result.status_code,
            resumed=result.resumed,
        )

    async def _run_on_sdk_loop(
        self,
        coro: Coroutine[object, object, T],
    ) -> T:
        return await self._event_loop.run_async(coro)

    def _submit_to_sdk_loop(
        self,
        coro: Coroutine[object, object, T],
    ) -> ConcurrentFuture[T]:
        return self._event_loop.run_coroutine_threadsafe(coro)

    def _require_non_empty(self, name: str, value: str) -> None:
        if not value:
            raise ValidationError(
                f"Expected a non-empty value for `{name}` but received {value!r}",
                code="validation.empty_rest_argument",
            )
