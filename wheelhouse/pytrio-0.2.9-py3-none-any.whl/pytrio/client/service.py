"""创建 SDK 根服务会话及共享其生命周期的派生 Client。"""

import functools
import logging
from collections.abc import Coroutine
from dataclasses import dataclass
from pathlib import Path
from time import perf_counter
from typing import TypeVar, cast

from pytrio.auth.flow import authenticate_api_key
from pytrio.auth.user_info import AuthUserInfo
from pytrio.client.adapters.limits import (
    sampling_run_limits_from_control,
    training_run_limits_from_control,
)
from pytrio.client.adapters.model import server_capabilities_from_control
from pytrio.client.rest import RestClient
from pytrio.client.sampling import SamplingClient
from pytrio.client.training import TrainingClient, _PendingTrainingActorBinding
from pytrio.config.config import auth_state, configuration
from pytrio.config.notices import LocalNoticeStore
from pytrio.errors.auth import AuthError
from pytrio.errors.base import PyTrioError, ValidationError
from pytrio.errors.control import ControlAPIError, SDKCompatibilityError
from pytrio.logging.render import LogField, log_user_message, strict_log_level
from pytrio.logging.setup import setup_logging
from pytrio.observability.api import (
    create_observability_runtime,
    error_attributes,
    record_operation,
)
from pytrio.protocol.actor.events.trainer.lora import (
    CheckpointLoraSource,
    FreshLoraSource,
    LoraRunSpec,
    LoraSource,
)
from pytrio.protocol.control.training_run.find_by_checkpoint_uri import (
    TrainingRunFindByCheckpointURIResponse,
)
from pytrio.runtime.service import ServiceRuntime
from pytrio.transport.control.actor_capacity import call_with_actor_capacity_polling
from pytrio.types.server_capabilities import GetServerCapabilitiesResponse

logger = logging.getLogger(__name__)

_BILLING_INSUFFICIENT_BALANCE = "billing_insufficient_balance"
T = TypeVar("T")


@dataclass(frozen=True)
class _LoraRunRequest:
    """尚未由 Control 解析模型身份的 LoRA 创建配置。"""

    base_model: str
    rank: int
    seed: int | None
    train_mlp: bool
    train_attn: bool
    train_unembed: bool
    source: LoraSource


class ServiceClient:
    """Root client that authenticates a user and workspace for run clients.

    ``ServiceClient`` creates a Control service session and the ``ServiceRuntime``
    shared by all derived clients. Every derived client keeps the runtime and
    remote service session alive for as long as it remains reachable.

    Args:
        api_key: API key for this process. When omitted, use the effective current
            process credential from the active profile, environment, or runtime config.

    Raises:
        AuthError: Authentication fails or the user or workspace identity is invalid.
        SDKCompatibilityError: Control blocks the current SDK version.
    """

    def __init__(
        self,
        api_key: str | None = None,
    ) -> None:
        """Initialize the root service client.

        Args:
            api_key: API key for this process. When omitted, use the effective current
                process credential from the active profile, environment, or runtime config.

        Raises:
            AuthError: Authentication fails or the user or workspace identity is invalid.
            SDKCompatibilityError: Control blocks the current SDK version.
        """
        client_configuration = configuration.model_copy(deep=True)
        try:
            # ServiceClient only verifies credentials. Persistent login is an
            # explicit CLI operation and must never be a constructor side effect.
            if auth_state.config_error is not None:
                raise auth_state.config_error
            resolved_api_key = (
                auth_state.api_key if api_key is None else api_key
            )
            user_info = authenticate_api_key(
                resolved_api_key,
                runtime_configuration=client_configuration,
            )
        except PyTrioError:
            raise
        except Exception as e:  # noqa: BLE001 - normalize authentication boundary
            raise AuthError(f"Login failed: {e}", code="auth.login_failed") from None
        self.user_info: AuthUserInfo = user_info
        self.user_id: str = user_info.user_cuid
        self.user_cuid: str = user_info.user_cuid
        self.username: str = user_info.username
        self.display_name: str | None = user_info.display_name
        self.workspace_cuid: str = user_info.workspace_cuid
        self.workspace_name: str = user_info.workspace_name
        self._api_key: str = user_info.api_key
        self.service_session_cuid: str = ""

        if not self.user_id and not self.username:
            raise AuthError(
                "Unable to retrieve user info", code="auth.invalid_user_info"
            )
        if not self._api_key:
            raise AuthError("Unable to retrieve API key", code="auth.missing_api_key")

        setup_logging()

        logger.debug(
            "Authenticated ServiceClient user=%s workspace=%s base_url=%s",
            self.username,
            self.workspace_cuid,
            client_configuration.base_url,
        )

        # 根 Client 创建共享运行时；后续派生 Client 通过强引用共同维持本地资源和
        # 远端 ServiceSession 的生命周期。
        telemetry = create_observability_runtime(
            api_key=self._api_key,
            user_cuid=self.user_cuid,
            workspace_cuid=self.workspace_cuid,
            base_url=client_configuration.base_url,
            buffer_home=Path(client_configuration.home),
        )
        self._runtime: ServiceRuntime = ServiceRuntime(
            api_key=self._api_key,
            telemetry=telemetry,
            runtime_configuration=client_configuration,
        )
        try:
            self._run_sync(self._initialize())
        except BaseException:
            self._runtime.shutdown(status="CANCELLED")
            raise

    async def _initialize(self) -> None:
        """Validate SDK compatibility and create the owned service session."""
        await self._check_sdk_bootstrap()
        started = perf_counter()
        try:
            service_session = (
                await self._runtime.control_client.create_service_session()
            )
        except ControlAPIError as e:
            record_operation(
                self._runtime.telemetry,
                "create_service_session",
                status="error",
                attributes={
                    **error_attributes(e),
                    "duration_ms": int((perf_counter() - started) * 1000),
                },
            )
            raise
        self._runtime.bind_service_session(service_session.service_session_cuid)
        self.service_session_cuid = service_session.service_session_cuid
        record_operation(
            self._runtime.telemetry,
            "create_service_session",
            attributes={
                "service_session_cuid": self.service_session_cuid,
                "workspace_cuid": self.workspace_cuid,
                "duration_ms": int((perf_counter() - started) * 1000),
            },
        )
        logger.debug(
            "Initialized ServiceClient session=%s",
            self.service_session_cuid,
        )

    def get_supported_models(self) -> list[str]:
        """Return model IDs available to the current workspace.

        Returns:
            Stable model IDs from the Control model catalog.
        """
        capabilities = self.get_server_capabilities()
        return [model.model_name for model in capabilities.supported_models]

    def get_server_capabilities(self) -> GetServerCapabilitiesResponse:
        """Return available models and their operation limits.

        Returns:
            Per-model training and sampling capabilities visible to the workspace.
        """
        return self._run_sync(self._get_server_capabilities())

    async def get_server_capabilities_async(
        self,
    ) -> GetServerCapabilitiesResponse:
        """Return available models and operation limits asynchronously.

        Returns:
            Per-model training and sampling capabilities visible to the workspace.
        """
        return await self._run_async(self._get_server_capabilities())

    async def _get_server_capabilities(self) -> GetServerCapabilitiesResponse:
        models = await self._runtime.control_client.get_models()
        return server_capabilities_from_control(models)

    def create_rest_client(self) -> RestClient:
        """Create a metadata client that shares this service runtime.

        Returns:
            A client for Control metadata and checkpoint operations.
        """
        logger.debug(
            "Creating RestClient for session=%s",
            self.service_session_cuid,
        )
        return RestClient(self._runtime)

    def _run_sync(self, coro: Coroutine[object, object, T]) -> T:
        try:
            return self._runtime.event_loop.run_sync(coro)
        except Exception:
            coro.close()
            raise

    async def _run_async(self, coro: Coroutine[object, object, T]) -> T:
        try:
            return await self._runtime.event_loop.run_async(coro)
        except Exception:
            coro.close()
            raise

    async def _check_sdk_bootstrap(self) -> None:
        """应用 Control 返回的 SDK 兼容性策略和用户通知。"""
        try:
            response = await self._runtime.control_client.sdk_bootstrap(
                self._runtime.configuration.version
            )
        except ControlAPIError as e:
            error_fields: list[LogField] = []
            if e.status_code > 0:
                error_fields.append(LogField("Status", e.status_code))
            if e.code:
                error_fields.append(LogField("Code", e.code))
            if e.message:
                error_fields.append(LogField("Message", e.message))
            log_user_message(
                logger,
                "WARNING",
                "SDK bootstrap check failed; continuing without compatibility policy.",
                fields=error_fields,
            )
            return
        except Exception as e:  # noqa: BLE001 - bootstrap is best-effort policy
            error_fields = []
            if str(e):
                error_fields.append(LogField("Error", str(e)))
            log_user_message(
                logger,
                "WARNING",
                "SDK bootstrap check failed; continuing without compatibility policy.",
                fields=error_fields,
            )
            return

        compatibility = response.compatibility
        status = compatibility.status
        message = (
            compatibility.message
            or f"PyTrio SDK version {compatibility.sdk_version} is {compatibility.status}"
        )
        fields = [LogField("SDK Version", compatibility.sdk_version)]
        if compatibility.recommended_version:
            fields.append(LogField("Recommended", compatibility.recommended_version))
        if compatibility.min_supported_version:
            fields.append(
                LogField("Min Supported", compatibility.min_supported_version)
            )
        if compatibility.latest_version:
            fields.append(LogField("Latest", compatibility.latest_version))
        if compatibility.policy_release_no:
            fields.append(LogField("Release", compatibility.policy_release_no))
        details = compatibility.model_dump(mode="json")

        # blocked 终止会话创建；warning 和 notices 写入用户日志。
        if status == "blocked":
            hints: list[str] = []
            if compatibility.upgrade_command:
                hints.append(f"Upgrade with `{compatibility.upgrade_command}`.")
            if compatibility.upgrade_url:
                hints.append(f"See {compatibility.upgrade_url}.")
            hint = " ".join(hints) if hints else ""
            raise SDKCompatibilityError(
                message,
                details=details,
                hint=hint,
                server=self._runtime.configuration.base_url,
            )

        if status == "warning":
            log_user_message(logger, "WARNING", message, fields=fields)
        else:
            log_user_message(logger, "DEBUG", message, fields=fields)

        for notice in response.notices:
            try:
                level = strict_log_level(notice.level)
            except ValueError:
                log_user_message(
                    logger,
                    "ERROR",
                    "Unrecognized server notice level; falling back to WARNING.",
                    fields=[LogField("Level", notice.level)],
                )
                level = "WARNING"
            if level == "INFO" and not self._claim_info_notice(notice.release_no):
                continue
            notice_message = notice.message or notice.title
            fields = [LogField("Release", notice.release_no)]
            if notice.release_url:
                fields.append(LogField("URL", notice.release_url))
            log_user_message(
                logger,
                level,
                notice_message,
                fields=fields,
            )

    def _claim_info_notice(self, release_no: str) -> bool:
        """为当前环境中可见的 INFO 通知取得一次性展示权。"""
        if not logger.isEnabledFor(logging.INFO):
            return False
        try:
            return LocalNoticeStore(self._runtime.configuration.notices_path).claim(
                release_no
            )
        except (OSError, UnicodeError) as error:
            logger.debug(
                "Failed to persist SDK notice state release=%s path=%s error=%s",
                release_no,
                self._runtime.configuration.notices_path,
                error,
            )
            return True

    def _log_run_creation_control_error(
        self,
        task_type: str,
        error: ControlAPIError,
    ) -> None:
        if error.code != _BILLING_INSUFFICIENT_BALANCE:
            return
        fields = [LogField("Service Session", self.service_session_cuid)]
        if error.status_code > 0:
            fields.append(LogField("Status", error.status_code))
        if error.code:
            fields.append(LogField("Code", error.code))
        if error.message:
            fields.append(LogField("Message", error.message))
        log_user_message(
            logger,
            "ERROR",
            (
                f"{task_type} creation failed: workspace balance is exhausted or cash "
                "balance is overdue."
            ),
            fields=fields,
        )

    def create_lora_training_client(
        self,
        base_model: str,
        rank: int = 32,
        seed: int | None = None,
        train_mlp: bool = True,
        train_attn: bool = True,
        train_unembed: bool = True,
    ) -> TrainingClient:
        """Create a new LoRA training client.

        Args:
            base_model: Base model ID from the Control model catalog.
            rank: LoRA rank in the inclusive range ``[4, 64]``.
            seed: Random seed for LoRA parameter initialization.
            train_mlp: Whether to train MLP layers.
            train_attn: Whether to train attention layers.
            train_unembed: Whether to train the output embedding layer.

        Returns:
            A training client bound to the new training run.

        Raises:
            ValidationError: The rank or model capabilities are invalid.
            ControlAPIError: Control cannot create the training run.
        """
        return self._run_sync(
            self._create_lora_training_client(
                base_model=base_model,
                rank=rank,
                seed=seed,
                train_mlp=train_mlp,
                train_attn=train_attn,
                train_unembed=train_unembed,
            )
        )

    async def create_lora_training_client_async(
        self,
        base_model: str,
        rank: int = 32,
        seed: int | None = None,
        train_mlp: bool = True,
        train_attn: bool = True,
        train_unembed: bool = True,
    ) -> TrainingClient:
        """Create a new LoRA training client asynchronously.

        Args:
            base_model: Base model ID from the Control model catalog.
            rank: LoRA rank in the inclusive range ``[4, 64]``.
            seed: Random seed for LoRA parameter initialization.
            train_mlp: Whether to train MLP layers.
            train_attn: Whether to train attention layers.
            train_unembed: Whether to train the output embedding layer.

        Returns:
            A training client bound to the new training run.

        Raises:
            ValidationError: The rank or model capabilities are invalid.
            ControlAPIError: Control cannot create the training run.
        """
        return await self._run_async(
            self._create_lora_training_client(
                base_model=base_model,
                rank=rank,
                seed=seed,
                train_mlp=train_mlp,
                train_attn=train_attn,
                train_unembed=train_unembed,
            )
        )

    async def _create_lora_training_client(
        self,
        base_model: str,
        rank: int = 32,
        seed: int | None = None,
        train_mlp: bool = True,
        train_attn: bool = True,
        train_unembed: bool = True,
    ) -> TrainingClient:
        if rank not in range(4, 65):
            raise ValidationError(
                f"rank must be in [4, 64]. Got {rank}",
                code="validation.invalid_lora_rank",
            )

        request = _LoraRunRequest(
            base_model=base_model,
            rank=rank,
            seed=seed,
            train_mlp=train_mlp,
            train_attn=train_attn,
            train_unembed=train_unembed,
            source=FreshLoraSource(),
        )
        return await self._register_lora_training_client(request)

    async def _register_lora_training_client(
        self,
        request: _LoraRunRequest,
        *,
        restore_optimizer: bool = False,
    ) -> TrainingClient:
        """向 Control 注册 LoRA 任务，保留首次初始化前的 Actor 重绑定窗口。"""
        source = request.source
        if isinstance(source, CheckpointLoraSource):
            source_checkpoint_uri = source.uri
            control_base_model = ""
        else:
            source_checkpoint_uri = ""
            control_base_model = request.base_model
        logger.debug(
            "Registering LoRA training client base_model=%s rank=%s restore_optimizer=%s source_checkpoint=%s",
            request.base_model,
            request.rank,
            restore_optimizer,
            bool(source_checkpoint_uri),
        )
        # Control 创建 run 并给出初始 Actor 凭据；TrainingClient 在首次初始化时才建立
        # run coordinator，使 load_state 可以先通过 PATCH 原子重绑定最终 Actor。
        try:
            run = await call_with_actor_capacity_polling(
                functools.partial(
                    self._runtime.control_client.create_training_run,
                    self.service_session_cuid,
                    base_model=control_base_model,
                    lora_rank=request.rank,
                    train_mlp=request.train_mlp,
                    train_attn=request.train_attn,
                    train_unembed=request.train_unembed,
                    source_checkpoint_uri=source_checkpoint_uri,
                    restore_optimizer=restore_optimizer,
                    seed=request.seed,
                ),
                self._runtime.configuration,
            )
        except ControlAPIError as e:
            self._log_run_creation_control_error("TrainingRun", e)
            record_operation(
                self._runtime.telemetry,
                "create_training_run",
                status="error",
                attributes={
                    "service_session_cuid": self.service_session_cuid,
                    "base_model": request.base_model,
                    "lora_rank": request.rank,
                    "has_source_checkpoint": bool(source_checkpoint_uri),
                    **error_attributes(e),
                },
            )
            raise
        resolved_lora = LoraRunSpec(
            model_id=run.model_id,
            rank=request.rank,
            seed=request.seed,
            train_mlp=request.train_mlp,
            train_attn=request.train_attn,
            train_unembed=request.train_unembed,
            source=request.source,
        )
        limits = training_run_limits_from_control(run.trainer)
        logger.debug(
            "Created training run training_run=%s actor=%s",
            run.training_run_cuid,
            run.actor.actor_cuid,
        )
        record_operation(
            self._runtime.telemetry,
            "create_training_run",
            attributes={
                "training_run_cuid": run.training_run_cuid,
                "base_model": request.base_model,
                "model_id": run.model_id,
                "lora_rank": request.rank,
                "has_source_checkpoint": bool(source_checkpoint_uri),
            },
        )

        training_client = TrainingClient(
            training_run_cuid=run.training_run_cuid,
            model_id=run.model_id,
            lora=resolved_lora,
            actor_binding=_PendingTrainingActorBinding(
                actor=run.actor,
                actor_jwt=run.actor_jwt,
            ),
            runtime=self._runtime,
            service_session_cuid=self.service_session_cuid,
            limits=limits,
            init_load_optimizer=restore_optimizer,
            model_alias=run.model_alias,
        )
        return training_client

    def create_sampling_client(
        self,
        base_model: str,
        model_path: str | None = None,
    ) -> SamplingClient:
        """Create a sampling client for a base model or LoRA checkpoint.

        Args:
            base_model: Base model ID from the Control model catalog.
            model_path: Optional LoRA checkpoint URI for the sampler to load.

        Returns:
            A sampling client bound to the new sampling run.

        Raises:
            ControlAPIError: Control cannot create the sampling run.
        """
        return self._run_sync(
            self._create_sampling_client(
                base_model=base_model,
                model_path=model_path,
            )
        )

    async def create_sampling_client_async(
        self,
        base_model: str,
        model_path: str | None = None,
    ) -> SamplingClient:
        """Create a sampling client asynchronously.

        Args:
            base_model: Base model ID from the Control model catalog.
            model_path: Optional LoRA checkpoint URI for the sampler to load.

        Returns:
            A sampling client bound to the new sampling run.

        Raises:
            ControlAPIError: Control cannot create the sampling run.
        """
        return await self._run_async(
            self._create_sampling_client(
                base_model=base_model,
                model_path=model_path,
            )
        )

    async def _create_sampling_client(
        self,
        base_model: str,
        model_path: str | None = None,
    ) -> SamplingClient:
        """向 Control 创建 sampling run 并绑定 Actor run coordinator。"""
        logger.debug(
            "Creating sampling client base_model=%s source_checkpoint=%s",
            base_model,
            model_path is not None,
        )
        try:
            run = await self._runtime.control_client.create_sampling_run(
                self.service_session_cuid,
                base_model=base_model,
                source_checkpoint_uri="" if model_path is None else model_path,
            )
        except ControlAPIError as e:
            self._log_run_creation_control_error("SamplingRun", e)
            record_operation(
                self._runtime.telemetry,
                "create_sampling_run",
                status="error",
                attributes={
                    "service_session_cuid": self.service_session_cuid,
                    "base_model": base_model,
                    "has_model_path": model_path is not None,
                    **error_attributes(e),
                },
            )
            raise
        limits = sampling_run_limits_from_control(run.sampler)
        sampling_coordinator = self._runtime.create_actor_sampling_run_coordinator(
            run.actor,
            run.actor_jwt,
            functools.partial(
                self._runtime.control_client.renew_sampling_run,
                run.sampling_run_cuid,
            ),
            sampling_run_cuid=run.sampling_run_cuid,
        )
        logger.debug(
            "Created sampling run sampling_run=%s actor=%s",
            run.sampling_run_cuid,
            run.actor.actor_cuid,
        )
        record_operation(
            self._runtime.telemetry,
            "create_sampling_run",
            attributes={
                "sampling_run_cuid": run.sampling_run_cuid,
                "base_model": base_model,
                "model_id": run.model_id,
                "has_model_path": model_path is not None,
            },
        )

        return SamplingClient(
            sampling_run_cuid=run.sampling_run_cuid,
            model_id=run.model_id,
            coordinator=sampling_coordinator,
            limits=limits,
            runtime=self._runtime,
        )

    def create_training_client_from_state(self, path: str) -> TrainingClient:
        """Create a training client from saved model weights.

        Args:
            path: Checkpoint URI returned by ``save_state``.

        Returns:
            A new training client configured to load the checkpoint weights.
        """
        return self._run_sync(
            self._create_training_client_from_state(path=path, restore_optimizer=False)
        )

    async def create_training_client_from_state_async(
        self, path: str
    ) -> TrainingClient:
        """Create a training client from saved model weights asynchronously.

        Args:
            path: Checkpoint URI returned by ``save_state``.

        Returns:
            A new training client configured to load the checkpoint weights.
        """
        return await self._run_async(
            self._create_training_client_from_state(path=path, restore_optimizer=False)
        )

    async def _create_training_client_from_state(
        self,
        path: str,
        *,
        restore_optimizer: bool,
    ) -> TrainingClient:
        """解析 checkpoint 归属配置并注册新的恢复任务。"""
        logger.debug(
            "Restoring training client from checkpoint=%s restore_optimizer=%s",
            path,
            restore_optimizer,
        )
        # checkpoint URI 先由 Control 解析回原 LoRA 配置，新的 training run 使用
        # checkpoint 来源建立独立的 Actor 状态。
        checkpoint_info = cast(
            TrainingRunFindByCheckpointURIResponse,
            await self._runtime.control_client.find_training_run_by_checkpoint_uri(
                path
            ),
        )
        model_id = checkpoint_info.base_model
        if not model_id:
            raise ValidationError(
                "Unable to determine base_model from checkpoint metadata",
                code="validation.missing_base_model",
            )
        rank = checkpoint_info.lora_rank
        if rank not in range(4, 65):
            raise ValidationError(
                f"rank must be in [4, 64]. Got {rank}",
                code="validation.invalid_lora_rank",
            )
        logger.debug(
            "Resolved checkpoint metadata model_id=%s rank=%s restore_optimizer=%s",
            model_id,
            rank,
            restore_optimizer,
        )

        request = _LoraRunRequest(
            base_model=model_id,
            rank=rank,
            seed=checkpoint_info.seed,
            train_mlp=checkpoint_info.train_mlp,
            train_attn=checkpoint_info.train_attn,
            train_unembed=checkpoint_info.train_unembed,
            source=CheckpointLoraSource(path),
        )
        return await self._register_lora_training_client(
            request,
            restore_optimizer=restore_optimizer,
        )

    def create_training_client_from_state_with_optimizer(
        self, path: str
    ) -> TrainingClient:
        """Create a training client from saved weights and optimizer state.

        Args:
            path: Checkpoint URI returned by ``save_state``.

        Returns:
            A new training client configured to load weights and optimizer state.
        """
        return self._run_sync(
            self._create_training_client_from_state(path=path, restore_optimizer=True)
        )

    async def create_training_client_from_state_with_optimizer_async(
        self, path: str
    ) -> TrainingClient:
        """Create a training client from saved weights and optimizer state asynchronously.

        Args:
            path: Checkpoint URI returned by ``save_state``.

        Returns:
            A new training client configured to load weights and optimizer state.
        """
        return await self._run_async(
            self._create_training_client_from_state(path=path, restore_optimizer=True)
        )
