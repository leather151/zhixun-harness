"""训练逻辑批次的校验、归一化与分片规划。

该层把公共 ``Datum`` 一次性收窄为不可变的内部样本，并以用户的一次
forward/forward_backward 调用为逻辑批次计算归一化总量。builder 只将计划结果
映射为 canonical v2 ``data[]``，本层负责发送前的完整训练语义校验。
"""

import math
from dataclasses import dataclass
from typing import Literal, cast

from pytrio.errors.base import ValidationError
from pytrio.model.limits import TrainingLimits
from pytrio.types.forward.datum import Datum
from pytrio.types.forward.encoded_text_chunk import EncodedTextChunk
from pytrio.types.forward.image_chunk import ImageChunk
from pytrio.types.forward.model_input import ModelInput

LossFunction = Literal[
    "cross_entropy",
    "importance_sampling",
    "ppo",
    "cispo",
    "dro",
]

LOSS_INPUT_SCHEMAS: dict[LossFunction, tuple[str, ...]] = {
    "cross_entropy": ("target_tokens",),
    "importance_sampling": (
        "target_tokens",
        "logprobs",
        "advantages",
    ),
    "ppo": (
        "target_tokens",
        "logprobs",
        "advantages",
    ),
    "cispo": (
        "target_tokens",
        "logprobs",
        "advantages",
    ),
    "dro": (
        "target_tokens",
        "logprobs",
        "advantages",
    ),
}


def normalize_loss_fn(loss_fn: str) -> LossFunction:
    """归一化并收窄 Trainer 支持的 loss 名称。"""
    normalized = loss_fn.strip().lower()
    if normalized not in LOSS_INPUT_SCHEMAS:
        raise ValueError(f"Unsupported loss function type: {loss_fn}")
    return cast(LossFunction, normalized)


@dataclass(frozen=True)
class CrossEntropyTrainingSample:
    """已校验的交叉熵样本；默认权重也已在领域层显式补齐。"""

    model_input: ModelInput
    target_tokens: tuple[int, ...]
    weights: tuple[float, ...]

    @property
    def input_length(self) -> int:
        return len(self.model_input)


@dataclass(frozen=True)
class PolicyTrainingSample:
    """已校验的策略损失样本，保留计算全局归一化分母所需的 token 数据。"""

    model_input: ModelInput
    target_tokens: tuple[int, ...]
    logprobs: tuple[float, ...]
    advantages: tuple[float, ...]

    @property
    def input_length(self) -> int:
        return len(self.model_input)


TrainingSample = CrossEntropyTrainingSample | PolicyTrainingSample


@dataclass(frozen=True)
class GradientAccumulationTotals:
    """一个逻辑批次的全局分母；每个物理微批都携带完全相同的值。"""

    total_samples: int
    total_active_tokens: int
    total_advantage_tokens: int


@dataclass(frozen=True)
class TrainingBatchChunk:
    """一次 Actor forward 请求的领域输入，由 builder 编码为 v2 ``data[]``。"""

    loss_fn: LossFunction
    samples: tuple[TrainingSample, ...]
    input_tokens: int


@dataclass(frozen=True)
class TrainingBatchPlan:
    """一次公共训练调用的有序微批计划及其逻辑批次总量。"""

    chunks: tuple[TrainingBatchChunk, ...]
    totals: GradientAccumulationTotals


def plan_training_batch(
    data: list[Datum],
    *,
    loss_fn: str,
    auto_shift: bool,
    limits: TrainingLimits,
    tokenizer_vocab_size: int,
) -> TrainingBatchPlan:
    """生成保持样本顺序的执行计划。

    本层完成校验、类型收窄和 totals 计算，builder 编码计划结果。单微批与多微批共享
    同一套归一化口径和输入校验结果。
    """
    if not data:
        raise ValidationError(
            "training data cannot be empty",
            code="validation.empty_training_data",
        )

    normalized_loss_fn = normalize_loss_fn(loss_fn)
    required_loss_inputs = LOSS_INPUT_SCHEMAS[normalized_loss_fn]
    samples: list[TrainingSample] = []
    total_active_tokens = 0
    total_advantage_tokens = 0

    # 第一阶段准备完整逻辑批次。totals 定义为拆分前数据的全局分母，每个微批引用
    # 该分母形成与完整 batch 等效的梯度。
    for sample_index, datum in enumerate(data):
        for field_name in required_loss_inputs:
            if field_name not in datum.loss_fn_inputs:
                raise ValueError(f"{field_name} is required")

        model_input = datum.model_input
        missing_image_indices: list[int] = []
        known_input_length = 0
        for chunk_index, chunk in enumerate(model_input.chunks):
            if isinstance(chunk, EncodedTextChunk):
                known_input_length += len(chunk)
            else:
                if chunk.expected_tokens is None:
                    missing_image_indices.append(chunk_index)
                else:
                    known_input_length += chunk.expected_tokens

        if missing_image_indices:
            if len(missing_image_indices) > 1:
                raise ValueError(
                    "cannot infer expected_tokens for more than one image chunk"
                )
            target_shape = datum.loss_fn_inputs["target_tokens"].shape
            if len(target_shape) != 1:
                raise ValueError(
                    "target_tokens must be one-dimensional to infer expected_tokens"
                )
            inferred_image_tokens = target_shape[0] - known_input_length
            if inferred_image_tokens <= 0:
                raise ValueError(
                    "inferred expected_tokens must be greater than 0: "
                    f"target_tokens={target_shape[0]} "
                    f"known_input_tokens={known_input_length}"
                )
            normalized_chunks = list(model_input.chunks)
            missing_index = missing_image_indices[0]
            missing_image = normalized_chunks[missing_index]
            if not isinstance(missing_image, ImageChunk):
                raise TypeError("missing image index does not reference an ImageChunk")
            normalized_chunks[missing_index] = missing_image.model_copy(
                update={"expected_tokens": inferred_image_tokens}
            )
            model_input = ModelInput(chunks=normalized_chunks)

        sequence_length = len(model_input)
        if sequence_length < 1:
            raise ValidationError(
                "training samples cannot be empty",
                code="validation.empty_training_sample",
                details={"sample_index": sample_index},
            )
        # 图像由 Actor 按实际二进制内容验证并计量；SDK 仍在此校验每一个
        # encoded_text token，避免图文混合输入绕过 vocabulary 边界。
        text_token_index = 0
        for chunk in model_input.chunks:
            if not isinstance(chunk, EncodedTextChunk):
                continue
            for token_id in chunk.tokens:
                if token_id < 0 or token_id >= tokenizer_vocab_size:
                    raise ValidationError(
                        "training input token ID is outside the tokenizer vocabulary",
                        code="validation.token_id_out_of_range",
                        details={
                            "field": "input_ids",
                            "sample_index": sample_index,
                            "token_index": text_token_index,
                            "token_id": token_id,
                            "vocab_size": tokenizer_vocab_size,
                        },
                    )
                text_token_index += 1
        if limits.max_seq_len is not None and sequence_length > limits.max_seq_len:
            raise ValidationError(
                "training sample exceeds max_seq_len",
                code="validation.training_sample_too_long",
                details={
                    "sample_index": sample_index,
                    "seq_len": sequence_length,
                    "max_seq_len": limits.max_seq_len,
                },
            )
        if (
            limits.max_tokens_per_request is not None
            and sequence_length > limits.max_tokens_per_request
        ):
            raise ValidationError(
                "training sample exceeds max_tokens_per_request",
                code="validation.training_sample_too_large",
                details={
                    "sample_index": sample_index,
                    "input_tokens": sequence_length,
                    "max_tokens_per_request": limits.max_tokens_per_request,
                },
            )

        target_tensor = datum.loss_fn_inputs["target_tokens"]
        if target_tensor.dtype != "int64":
            raise ValueError("target_tokens must have dtype int64")
        if target_tensor.shape != [sequence_length]:
            raise ValueError(
                f"target_tokens must have shape [{sequence_length}], got "
                f"{target_tensor.shape}"
            )
        target_tokens = tuple(int(token) for token in target_tensor.data)
        # Trainer 的 auto_shift 会按样本丢弃第一个 label；SDK 统计必须复现同一口径。
        token_start = 1 if auto_shift else 0
        if normalized_loss_fn == "cross_entropy":
            if "weights" in datum.loss_fn_inputs:
                weights_tensor = datum.loss_fn_inputs["weights"]
                if weights_tensor.shape != [sequence_length]:
                    raise ValueError(
                        f"weights must have shape [{sequence_length}], got "
                        f"{weights_tensor.shape}"
                    )
                weights = tuple(float(weight) for weight in weights_tensor.data)
            else:
                weights = (1.0,) * sequence_length
            for token_index, weight in enumerate(weights):
                if not math.isfinite(weight):
                    raise ValueError(
                        f"weights[{token_index}] must be finite for sample "
                        f"{sample_index}"
                    )
            samples.append(
                CrossEntropyTrainingSample(
                    model_input=model_input,
                    target_tokens=target_tokens,
                    weights=weights,
                )
            )
            for token_index, token_id in enumerate(target_tokens):
                if token_id != -100 and (
                    token_id < 0 or token_id >= tokenizer_vocab_size
                ):
                    raise ValidationError(
                        "training target token ID is outside the tokenizer vocabulary",
                        code="validation.token_id_out_of_range",
                        details={
                            "field": "target_tokens",
                            "sample_index": sample_index,
                            "token_index": token_index,
                            "token_id": token_id,
                            "vocab_size": tokenizer_vocab_size,
                        },
                    )
                if (
                    token_index >= token_start
                    and token_id != -100
                    and (weights[token_index] != 0.0)
                ):
                    total_active_tokens += 1
        else:
            logprobs_tensor = datum.loss_fn_inputs["logprobs"]
            advantages_tensor = datum.loss_fn_inputs["advantages"]
            for field_name, tensor in (
                ("logprobs", logprobs_tensor),
                ("advantages", advantages_tensor),
            ):
                if tensor.shape != [sequence_length]:
                    raise ValueError(
                        f"{field_name} must have shape [{sequence_length}], got "
                        f"{tensor.shape}"
                    )
            logprobs = tuple(float(logprob) for logprob in logprobs_tensor.data)
            advantages = tuple(float(advantage) for advantage in advantages_tensor.data)
            for field_name, values in (
                ("logprobs", logprobs),
                ("advantages", advantages),
            ):
                for token_index, value in enumerate(values):
                    if not math.isfinite(value):
                        raise ValueError(
                            f"{field_name}[{token_index}] must be finite for "
                            f"sample {sample_index}"
                        )
            samples.append(
                PolicyTrainingSample(
                    model_input=model_input,
                    target_tokens=target_tokens,
                    logprobs=logprobs,
                    advantages=advantages,
                )
            )
            for token_index, token_id in enumerate(target_tokens):
                if token_id != -100 and (
                    token_id < 0 or token_id >= tokenizer_vocab_size
                ):
                    raise ValidationError(
                        "training target token ID is outside the tokenizer vocabulary",
                        code="validation.token_id_out_of_range",
                        details={
                            "field": "target_tokens",
                            "sample_index": sample_index,
                            "token_index": token_index,
                            "token_id": token_id,
                            "vocab_size": tokenizer_vocab_size,
                        },
                    )
                if token_index < token_start or token_id == -100:
                    continue
                total_active_tokens += 1
                # advantage token 是 DRO 等归一化模式的独立分母；零 advantage 的有效
                # label 计入 active token，同时排除在 advantage token 之外。
                if advantages[token_index] != 0.0:
                    total_advantage_tokens += 1

    # 第二阶段按 Actor 声明的单请求容量做稳定贪心分片。token 成本使用每条
    # canonical ModelInput 使用 logical length，wire payload 不包含 padding。
    chunks: list[TrainingBatchChunk] = []
    current_samples: list[TrainingSample] = []
    current_input_tokens = 0
    for sample in samples:
        sequence_length = sample.input_length
        exceeds_batch_size = (
            limits.max_batch_size is not None
            and len(current_samples) + 1 > limits.max_batch_size
        )
        exceeds_input_tokens = (
            limits.max_tokens_per_request is not None
            and current_input_tokens + sequence_length > limits.max_tokens_per_request
        )
        if current_samples and (exceeds_batch_size or exceeds_input_tokens):
            chunks.append(
                TrainingBatchChunk(
                    loss_fn=normalized_loss_fn,
                    samples=tuple(current_samples),
                    input_tokens=current_input_tokens,
                )
            )
            current_samples = []
            current_input_tokens = 0

        current_samples.append(sample)
        current_input_tokens += sequence_length

    if current_samples:
        chunks.append(
            TrainingBatchChunk(
                loss_fn=normalized_loss_fn,
                samples=tuple(current_samples),
                input_tokens=current_input_tokens,
            )
        )

    return TrainingBatchPlan(
        chunks=tuple(chunks),
        totals=GradientAccumulationTotals(
            total_samples=len(samples),
            total_active_tokens=total_active_tokens,
            total_advantage_tokens=total_advantage_tokens,
        ),
    )
