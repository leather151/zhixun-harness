"""把公共模型输入映射为 Actor v2 wire 模型。"""

from pytrio.protocol.actor.model_input import (
    WireEncodedTextChunk,
    WireImageChunk,
    WireModelInput,
)
from pytrio.types.forward.encoded_text_chunk import EncodedTextChunk
from pytrio.types.forward.model_input import ModelInput


def model_input_to_wire(model_input: ModelInput) -> WireModelInput:
    """保留 chunk 顺序并隔离公共类型与 Actor 协议类型。"""
    chunks: list[WireEncodedTextChunk | WireImageChunk] = []
    for chunk in model_input.chunks:
        if isinstance(chunk, EncodedTextChunk):
            chunks.append(WireEncodedTextChunk(tokens=chunk.to_ints()))
        else:
            chunks.append(
                WireImageChunk(
                    data=chunk.data,
                    format=chunk.format,
                    expected_tokens=chunk.expected_tokens,
                )
            )
    return WireModelInput(chunks=chunks)
