"""把已规划的训练领域对象编码为 Actor Trainer v2 payload。"""

import hashlib
import logging
import re

from pytrio.client.builders.model_input import model_input_to_wire
from pytrio.client.training_batch import (
    CrossEntropyTrainingSample,
    GradientAccumulationTotals,
    TrainingBatchChunk,
)
from pytrio.errors.base import ValidationError
from pytrio.protocol.actor.events.trainer.forward import (
    GradientAccumulationSpec,
    LossSpec,
    TrainerForwardBackwardPayload,
    TrainerForwardDatum,
)
from pytrio.protocol.actor.events.trainer.init_run import (
    TrainerInitRunPayload,
    TrainerLoraPayload,
)
from pytrio.protocol.actor.events.trainer.lora import (
    CheckpointLoraSource,
    LoraRunSpec,
    LoraSource,
)
from pytrio.protocol.actor.events.trainer.optimize_step import (
    TrainerAdamParamsPayload,
    TrainerOptimizeStepPayload,
)
from pytrio.protocol.actor.events.trainer.save import (
    CheckpointVisibility,
    TrainerSavePayload,
)
from pytrio.types.optim_step.adam_params import AdamParams

logger = logging.getLogger(__name__)

CHECKPOINT_NAME_MAX_LENGTH = 200
CHECKPOINT_NAME_PREFIX_LENGTH = 180
CHECKPOINT_NAME_HASH_LENGTH = 20
CHECKPOINT_NAME_PATTERN_TEXT = r"^[A-Za-z0-9](?:[A-Za-z0-9._-]*[A-Za-z0-9_-])?$"
CHECKPOINT_NAME_PATTERN = re.compile(CHECKPOINT_NAME_PATTERN_TEXT)


def _normalize_checkpoint_name(name: object) -> str:
    """规范化并校验 SDK checkpoint 名称，再收敛到稳定的 200 字符标识。"""
    if not isinstance(name, str):
        raise ValidationError(
            "checkpoint name must be a string",
            code="validation.invalid_checkpoint_name",
        )
    normalized = name.replace(" ", "-")
    if normalized != name:
        logger.warning(
            "Checkpoint name spaces were replaced with hyphens: original=%r new=%r",
            name,
            normalized,
        )

    if CHECKPOINT_NAME_PATTERN.fullmatch(normalized) is None:
        raise ValidationError(
            f"checkpoint name must match {CHECKPOINT_NAME_PATTERN_TEXT}",
            code="validation.invalid_checkpoint_name",
        )

    if len(normalized) <= CHECKPOINT_NAME_MAX_LENGTH:
        return normalized

    digest = hashlib.sha256(normalized.encode("ascii")).hexdigest()[
        :CHECKPOINT_NAME_HASH_LENGTH
    ]
    shortened = normalized[:CHECKPOINT_NAME_PREFIX_LENGTH] + digest
    logger.warning(
        "Checkpoint name exceeded %d characters and was shortened: original=%r new=%r",
        CHECKPOINT_NAME_MAX_LENGTH,
        normalized,
        shortened,
    )
    return shortened


def build_trainer_init_payload(
    lora: LoraRunSpec,
    *,
    source: LoraSource,
    load_optimizer: bool = False,
) -> TrainerInitRunPayload:
    """编码 LoRA 配置和初始来源为 Trainer 初始化载荷。"""
    init_payload: dict[str, object] = {
        "base_model": lora.model_id,
        "load_optimizer": load_optimizer,
        "lora_config": TrainerLoraPayload(
            rank=lora.rank,
            seed=lora.seed,
            train_mlp=lora.train_mlp,
            train_attn=lora.train_attn,
            train_unembed=lora.train_unembed,
        ),
    }
    if isinstance(source, CheckpointLoraSource):
        init_payload["checkpoint_uri"] = source.uri
    return TrainerInitRunPayload.model_validate(init_payload)


def build_trainer_forward_payload(
    chunk: TrainingBatchChunk,
    loss_fn_config: dict[str, object] | None,
    auto_shift: bool,
    gradient_accumulation: GradientAccumulationTotals,
) -> TrainerForwardBackwardPayload:
    """编码一个 v2 物理微批，并附带其所属逻辑批次的全局 totals。"""
    data: list[TrainerForwardDatum] = []
    for sample in chunk.samples:
        fields: dict[str, object] = {
            "model_input": model_input_to_wire(sample.model_input),
            "target_ids": list(sample.target_tokens),
        }
        if isinstance(sample, CrossEntropyTrainingSample):
            fields["weights"] = list(sample.weights)
        else:
            fields["logprobs"] = list(sample.logprobs)
            fields["advantages"] = list(sample.advantages)
        data.append(TrainerForwardDatum.model_validate(fields))

    return TrainerForwardBackwardPayload(
        data=data,
        auto_shift=auto_shift,
        loss=LossSpec(type=chunk.loss_fn, config=loss_fn_config or {}),
        gradient_accumulation=GradientAccumulationSpec(
            total_samples=gradient_accumulation.total_samples,
            total_active_tokens=gradient_accumulation.total_active_tokens,
            total_advantage_tokens=gradient_accumulation.total_advantage_tokens,
        ),
    )


def build_trainer_optimize_payload(
    adam_params: AdamParams,
) -> TrainerOptimizeStepPayload:
    """编码用户 AdamW 参数为 Trainer 优化步骤载荷。"""
    return TrainerOptimizeStepPayload(
        adam_params=TrainerAdamParamsPayload(**adam_params.model_dump())
    )


def build_trainer_save_payload(
    name: str,
    ttl_seconds: int | None,
    overwrite: bool = False,
    visibility: CheckpointVisibility = "WORKSPACE",
) -> TrainerSavePayload:
    """编码 checkpoint 名称、有效期、覆盖与可见性策略。"""
    return TrainerSavePayload(
        name=_normalize_checkpoint_name(name),
        ttl_seconds=ttl_seconds,
        overwrite=overwrite,
        visibility=visibility,
    )
