"""将采样领域输入编码为 Actor 请求。"""

from collections.abc import Sequence
from uuid import uuid4

from pytrio.client.builders.model_input import model_input_to_wire
from pytrio.protocol.actor.sampling_run.sample import ActorSampleResponse, SampleRequest
from pytrio.types.forward.model_input import ModelInput
from pytrio.types.sample.sample_response import SampleResponse
from pytrio.types.sample.sample_sequence import SampleSequence
from pytrio.types.sample.sampling_params import SamplingParams


def build_sample_request(
    prompt: ModelInput,
    *,
    num_samples: int,
    sampling_params: SamplingParams,
    include_prompt_logprobs: bool,
    topk_prompt_logprobs: int,
    return_text: bool,
    return_token_logprobs: bool,
) -> SampleRequest:
    """将用户采样输入编码为 Actor 请求。

    Args:
        prompt: 编码后的模型输入。
        num_samples: 生成候选数量。
        sampling_params: 用户采样参数。
        include_prompt_logprobs: 是否返回 prompt logprob。
        topk_prompt_logprobs: 每个 prompt 位置返回的 top-k 数量。
        return_text: 是否返回解码文本。
        return_token_logprobs: 是否返回生成 token 的 logprob。

    Returns:
        带唯一请求 ID 的已校验 Actor 请求。
    """
    # Actor 分别接受 stop 字符串和 stop token ID；用户类型在 builder 边界归一化为
    # 对应的明确协议字段。
    actor_sampling_params = sampling_params.model_dump(exclude_none=True)
    stop = actor_sampling_params.pop("stop", None)
    if stop is not None:
        if isinstance(stop, str):
            actor_sampling_params["stop"] = [stop]
        elif isinstance(stop, Sequence) and all(
            isinstance(item, int) and not isinstance(item, bool) for item in stop
        ):
            actor_sampling_params["stop_token_ids"] = list(stop)
        elif isinstance(stop, Sequence):
            actor_sampling_params["stop"] = list(stop)
        else:
            actor_sampling_params["stop"] = stop

    return SampleRequest(
        request_id=f"req_{uuid4().hex}",
        prompt=model_input_to_wire(prompt),
        sampling_params=actor_sampling_params,
        num_samples=num_samples,
        return_text=return_text,
        return_token_logprobs=return_token_logprobs,
        return_prompt_logprobs=include_prompt_logprobs,
        topk_prompt_logprobs=topk_prompt_logprobs,
    )


def actor_sample_response_to_sdk(actor_response: ActorSampleResponse) -> SampleResponse:
    """将 Actor 采样响应转换为用户结果并补齐可选列表。"""
    return SampleResponse(
        sequences=[
            SampleSequence(
                tokens=sequence.tokens,
                text=sequence.text,
                logprobs=sequence.logprobs,
                stop_reason=sequence.stop_reason,
            )
            for sequence in actor_response.sequences
        ],
        prompt_logprobs=actor_response.prompt_logprobs or [],
        topk_prompt_logprobs=actor_response.topk_prompt_logprobs or [],
        input_tokens=actor_response.usage.input_tokens,
        output_tokens=actor_response.usage.output_tokens,
    )
