"""Actor Trainer 响应到 SDK 用户类型的边界适配。

单微批和多微批统一经过同一套显式协议模型。公共输出契约在两条执行路径中保持一致，
聚合规则由本层按照稳定字段语义集中定义。
"""

from pydantic import TypeAdapter

from pytrio.errors.base import ValidationError
from pytrio.protocol.actor.events.trainer.forward import TrainerForwardResult
from pytrio.protocol.actor.events.trainer.save import TrainerSaveResult
from pytrio.types.checkpoint.save_weights_for_sampler_response import (
    SaveWeightsForSamplerResponse,
)
from pytrio.types.checkpoint.save_weights_response import SaveWeightsResponse
from pytrio.types.forward.forward_backward_output import ForwardBackwardOutput
from pytrio.types.forward.tensor_data import TensorData
from pytrio.types.optim_step.optim_step_response import OptimStepResponse

_RESULT_ADAPTER = TypeAdapter(dict[str, object])


def actor_forward_responses_to_sdk(
    responses: list[dict[str, object]],
    *,
    expected_samples: tuple[int, ...],
) -> ForwardBackwardOutput:
    """校验并聚合一个逻辑 forward 调用的有序物理响应。

    ``expected_samples`` 来自提交时的计划，用于同时检查响应片数和逐片输出数，并在
    边界即时报告 Actor/Trainer 契约漂移。
    """
    if len(responses) != len(expected_samples):
        raise ValidationError(
            "forward response count does not match submitted chunk count",
            code="validation.forward_response_count_mismatch",
            details={
                "response_count": len(responses),
                "chunk_count": len(expected_samples),
            },
        )

    # 严格协议模型是原始 MessagePack 字典进入 SDK 内部的唯一入口。
    results: list[TrainerForwardResult] = []
    for chunk_index, (response, expected_count) in enumerate(
        zip(responses, expected_samples, strict=True)
    ):
        raw_result = _RESULT_ADAPTER.validate_python(response.get("result"))
        result = TrainerForwardResult.model_validate(raw_result)
        if len(result.loss_fn_outputs) != expected_count:
            raise ValidationError(
                "forward output count does not match submitted sample count",
                code="validation.forward_output_count_mismatch",
                details={
                    "chunk_index": chunk_index,
                    "expected_samples": expected_count,
                    "output_count": len(result.loss_fn_outputs),
                },
            )
        results.append(result)

    # 物理响应按提交顺序收集，因此顺序展开即可还原用户原始 batch 的逐样本输出。
    loss_fn_outputs = [
        {
            name: TensorData.from_numpy(wire_tensor.to_numpy())
            for name, wire_tensor in sample.items()
        }
        for result in results
        for sample in result.loss_fn_outputs
    ]
    # loss_sum 和 token_count 是可加量；逻辑批次的 loss_mean 定义为全局
    # loss_sum / token_count，微批有效 token 数自然成为对应权重。
    loss_sum = sum(result.metrics.loss_sum for result in results)
    token_count = sum(result.metrics.token_count for result in results)
    return ForwardBackwardOutput(
        loss_fn_outputs=loss_fn_outputs,
        metrics={
            "loss_sum": loss_sum,
            "loss_mean": loss_sum / token_count if token_count > 0 else 0.0,
            "token_count": token_count,
        },
        debug={},
    )


def actor_optim_response_to_sdk(
    response: dict[str, object],
) -> OptimStepResponse:
    return OptimStepResponse.model_validate(response.get("result"))


def actor_save_state_response_to_sdk(
    response: dict[str, object],
    *,
    default_model: str,
) -> SaveWeightsResponse:
    """把保存状态响应映射为公共类型；缺失模型 ID 时使用训练 Client 的已知基座模型。"""
    result = TrainerSaveResult.model_validate(response.get("result"))
    return SaveWeightsResponse(
        path=result.checkpoint.uri,
        model=result.checkpoint.model_id or default_model,
        size=result.checkpoint.size_bytes,
    )


def actor_save_weights_response_to_sdk(
    response: dict[str, object],
    *,
    default_model: str,
) -> SaveWeightsForSamplerResponse:
    """把 sampler 权重响应映射为公共类型，并显式应用同一模型归属规则。"""
    result = TrainerSaveResult.model_validate(response.get("result"))
    return SaveWeightsForSamplerResponse(
        path=result.checkpoint.uri,
        model=result.checkpoint.model_id or default_model,
        size=result.checkpoint.size_bytes,
    )
