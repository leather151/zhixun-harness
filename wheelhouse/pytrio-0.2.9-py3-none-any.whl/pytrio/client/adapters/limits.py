"""将已调度 Runner 的 Control 容量转换为客户端领域限制。"""

from pytrio.model.limits import SamplingLimits, TrainingLimits
from pytrio.protocol.control.sampling_run.create import SamplingRunnerCapability
from pytrio.protocol.control.training_run.create import TrainingRunnerCapability


def training_run_limits_from_control(
    capability: TrainingRunnerCapability,
) -> TrainingLimits:
    """转换已调度 Trainer Runner 的容量。"""
    return TrainingLimits(
        max_batch_size=capability.max_batch_size,
        max_tokens_per_request=capability.max_tokens_per_request,
        max_seq_len=capability.max_seq_len,
    )


def sampling_run_limits_from_control(
    capability: SamplingRunnerCapability,
) -> SamplingLimits:
    """转换已调度 Sampler Runner 的容量。"""
    return SamplingLimits(
        max_batch_size=capability.max_batch_size,
        max_tokens_per_request=capability.max_tokens_per_request,
        max_seq_len=capability.max_seq_len,
    )
