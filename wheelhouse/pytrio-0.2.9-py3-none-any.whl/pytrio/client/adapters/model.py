"""将 Control 模型能力响应转换为 SDK 领域类型。"""

from pytrio.errors.base import ValidationError
from pytrio.model.limits import ModelLimits, SamplingLimits, TrainingLimits
from pytrio.protocol.control.model.list import ModelInfo
from pytrio.types.server_capabilities import (
    GetServerCapabilitiesResponse,
    ModelOperationCapabilities,
    SupportedModel,
)


def model_limits_from_control(
    models: list[ModelInfo],
    model_name: str,
) -> ModelLimits:
    """提取指定模型的训练与采样容量。

    Args:
        models: Control 返回的已校验模型目录。
        model_name: 用户请求的模型 ID。

    Returns:
        SDK 内部使用的逐操作容量。

    Raises:
        ValidationError: 模型不在当前工作区目录中。
    """
    model = next((item for item in models if item.model_id == model_name), None)
    if model is None:
        raise ValidationError(
            f"Model {model_name} is not supported by the server",
            code="validation.unsupported_model",
        )
    return ModelLimits(
        training=TrainingLimits(
            max_batch_size=model.trainer.max_batch_size,
            max_tokens_per_request=model.trainer.max_tokens_per_request,
            max_seq_len=model.trainer.max_seq_len,
        ),
        sampling=SamplingLimits(
            max_batch_size=model.sampler.max_batch_size,
            max_tokens_per_request=model.sampler.max_tokens_per_request,
            max_seq_len=model.sampler.max_seq_len,
        ),
    )


def server_capabilities_from_control(
    models: list[ModelInfo],
) -> GetServerCapabilitiesResponse:
    """将 Control 模型目录转换为稳定公共能力类型。"""
    return GetServerCapabilitiesResponse(
        supported_models=[
            SupportedModel(
                model_name=model.model_id,
                max_context_length=model.context_length,
                training=ModelOperationCapabilities(
                    available=model.train_available,
                    max_batch_size=model.trainer.max_batch_size,
                    max_tokens_per_request=model.trainer.max_tokens_per_request,
                    max_seq_len=model.trainer.max_seq_len,
                ),
                sampling=ModelOperationCapabilities(
                    available=model.sample_available,
                    max_batch_size=model.sampler.max_batch_size,
                    max_tokens_per_request=model.sampler.max_tokens_per_request,
                    max_seq_len=model.sampler.max_seq_len,
                ),
            )
            for model in models
        ]
    )
