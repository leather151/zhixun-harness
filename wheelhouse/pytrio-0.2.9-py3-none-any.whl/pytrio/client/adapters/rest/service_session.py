"""将 Control 服务会话响应转换为 SDK 领域类型。"""

from pytrio.protocol.control.service_session.get import ServiceSessionGetResponse
from pytrio.protocol.control.service_session.list import ServiceSessionListResponse
from pytrio.types.rest import GetSessionResponse, ListSessionsResponse


def service_session_from_control(
    response: ServiceSessionGetResponse,
) -> GetSessionResponse:
    return GetSessionResponse(
        training_run_ids=response.training_run_cuids,
        sampler_ids=response.sampling_run_cuids,
    )


def service_sessions_from_control(
    response: ServiceSessionListResponse,
) -> ListSessionsResponse:
    return ListSessionsResponse(
        sessions=[item.service_session_cuid for item in response.service_sessions]
    )
