"""将 Control checkpoint 响应转换为 SDK 领域类型。"""

from pytrio.client.adapters.rest.cursor import cursor_from_control
from pytrio.errors.base import ValidationError
from pytrio.protocol.control.checkpoint.download import CheckpointDownloadResponse
from pytrio.protocol.control.checkpoint.list import (
    CheckpointListResponse,
    CheckpointResponse,
)
from pytrio.types.rest import (
    Checkpoint,
    CheckpointArchiveUrlResponse,
    CheckpointDownloadSource,
    CheckpointsListResponse,
)


def checkpoint_from_control(checkpoint: CheckpointResponse) -> Checkpoint:
    if checkpoint.checkpoint_type == "TRAINING":
        checkpoint_type = "training"
    elif checkpoint.checkpoint_type == "SAMPLER":
        checkpoint_type = "sampler"
    else:
        raise ValidationError(
            f"unknown checkpoint_type: {checkpoint.checkpoint_type}",
            code="validation.unknown_checkpoint_type",
        )
    return Checkpoint(
        checkpoint_id=checkpoint.checkpoint_cuid,
        checkpoint_type=checkpoint_type,
        time=checkpoint.created_at,
        path=checkpoint.checkpoint_uri,
        size_bytes=checkpoint.size_bytes,
        public=False,
        expires_at=checkpoint.expired_at,
    )


def checkpoints_from_control(
    response: CheckpointListResponse,
    *,
    cursor: bool = True,
) -> CheckpointsListResponse:
    return CheckpointsListResponse(
        checkpoints=[checkpoint_from_control(item) for item in response.checkpoints],
        cursor=cursor_from_control(response.cursor) if cursor else None,
    )


def archive_url_from_download(
    response: CheckpointDownloadResponse,
) -> CheckpointArchiveUrlResponse:
    """将统一下载源投影为仅包含 URL 和过期时间的响应。"""
    return CheckpointArchiveUrlResponse(url=response.url, expires=response.expires_at)


def download_url_from_control(
    checkpoint_id: str,
    response: CheckpointDownloadResponse,
) -> CheckpointDownloadSource:
    return CheckpointDownloadSource(
        checkpoint_id=checkpoint_id,
        url=str(response.url),
        expires=response.expires_at,
        source=response.source,
        checkpoint_status=response.checkpoint_status,
        tls_cert_pem=response.tls_cert_pem,
        tls_not_after=response.tls_not_after,
    )
