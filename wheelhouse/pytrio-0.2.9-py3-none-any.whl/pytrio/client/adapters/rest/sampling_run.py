"""将 Control 采样任务响应转换为 SDK 领域类型。"""

from pytrio.protocol.control.sampling_run.get import SamplingRunGetResponse
from pytrio.types.rest import GetSamplerResponse


def sampling_run_from_control(response: SamplingRunGetResponse) -> GetSamplerResponse:
    return GetSamplerResponse(
        sampler_id=response.sampling_run_cuid,
        base_model=response.base_model,
        model_path=response.source_checkpoint_uri,
    )
