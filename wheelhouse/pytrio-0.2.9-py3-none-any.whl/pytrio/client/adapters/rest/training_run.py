"""将 Control 训练任务响应转换为 SDK 领域类型。"""

from pytrio.client.adapters.rest.cursor import cursor_from_control
from pytrio.protocol.control.training_run.get import TrainingRunGetResponse
from pytrio.protocol.control.training_run.list import TrainingRunListResponse
from pytrio.types.rest import TrainingRun, TrainingRunsResponse


def training_run_from_control(response: TrainingRunGetResponse) -> TrainingRun:
    return TrainingRun(
        training_run_id=response.training_run_cuid,
        base_model=response.base_model,
        model_owner=response.workspace_cuid,
        is_lora=response.is_lora,
        corrupted=response.corrupted,
        lora_rank=response.lora_rank
        if response.is_lora and response.lora_rank > 0
        else None,
        last_request_time=response.updated_at,
        last_checkpoint=None,
        last_sampler_checkpoint=None,
        user_metadata=response.user_metadata,
    )


def training_runs_from_control(
    response: TrainingRunListResponse,
) -> TrainingRunsResponse:
    return TrainingRunsResponse(
        training_runs=[
            training_run_from_control(item) for item in response.training_runs
        ],
        cursor=cursor_from_control(response.cursor),
    )
