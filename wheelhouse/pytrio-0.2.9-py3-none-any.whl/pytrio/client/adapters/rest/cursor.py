"""将 Control 分页游标转换为 SDK 领域类型。"""

from pytrio.protocol.control.common import ControlCursor
from pytrio.types.rest import Cursor


def cursor_from_control(cursor: ControlCursor) -> Cursor:
    return Cursor(
        offset=cursor.offset,
        limit=cursor.limit,
        total_count=cursor.total,
    )
