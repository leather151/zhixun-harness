"""编排用户采样调用与 Actor 采样响应转换。"""

from pydantic import ValidationError as PydanticValidationError

from pytrio.client.builders.sampling import (
    actor_sample_response_to_sdk,
    build_sample_request,
)
from pytrio.errors.base import ValidationError
from pytrio.model.limits import SamplingLimits
from pytrio.model.tokenizer import get_tokenizer
from pytrio.protocol.actor.sampling_run.sample import ActorSampleResponse
from pytrio.runtime.event_loop import SDKEventLoopRunner
from pytrio.runtime.service import ServiceRuntime
from pytrio.transport.actor.sampling_run.coordinator import ActorSamplingRunCoordinator
from pytrio.types.forward.model_input import ModelInput
from pytrio.types.future.api_future import APIFuture
from pytrio.types.sample.sample_response import SampleResponse
from pytrio.types.sample.sampling_params import SamplingParams

_DEFAULT_SAMPLING_PARAMS = SamplingParams()


class SamplingClient:
    """Submit sampling requests for one sampling run.

    The client keeps the shared ``ServiceRuntime`` alive while its sampling run
    coordinator manages request concurrency and credential renewal.

    Args:
        sampling_run_cuid: Sampling run CUID created by Control.
        model_id: Canonical model ID resolved by Control.
        coordinator: Actor sampling run coordinator supplied by the SDK factory.
        limits: Sampling request limits for the model.
        runtime: Runtime shared with the root service client.
    """

    def __init__(
        self,
        sampling_run_cuid: str,
        model_id: str,
        coordinator: ActorSamplingRunCoordinator,
        limits: SamplingLimits,
        runtime: ServiceRuntime,
    ) -> None:
        self.sampling_run_cuid: str = sampling_run_cuid
        self._sampling_run_cuid: str = sampling_run_cuid
        self.model_id: str = model_id
        self._limits: SamplingLimits = limits

        self._runtime: ServiceRuntime = runtime
        self._sampling_coordinator: ActorSamplingRunCoordinator = coordinator
        self._event_loop: SDKEventLoopRunner = runtime.event_loop

    def sample(
        self,
        prompt: ModelInput,
        num_samples: int = 1,
        sampling_params: SamplingParams = _DEFAULT_SAMPLING_PARAMS,
        include_prompt_logprobs: bool = False,
        topk_prompt_logprobs: int = 0,
        return_text: bool = True,
    ) -> APIFuture[SampleResponse]:
        """Generate one or more sequences from the model.

        Args:
            prompt: Encoded prompt tokens.
            num_samples: Number of candidate sequences to generate.
            sampling_params: Generation length and sampling strategy.
            include_prompt_logprobs: Whether to return prompt token logprobs.
            topk_prompt_logprobs: Number of top candidates returned per prompt position.
            return_text: Whether to return decoded text for each sequence.

        Returns:
            An API future that resolves to the sampling response.

        Raises:
            ValidationError: The prompt is empty or sampling parameters are invalid.
        """
        return self._event_loop.run_sync(
            self._sample(
                prompt=prompt,
                num_samples=num_samples,
                sampling_params=sampling_params,
                include_prompt_logprobs=include_prompt_logprobs,
                topk_prompt_logprobs=topk_prompt_logprobs,
                return_text=return_text,
                return_token_logprobs=True,
            )
        )

    async def sample_async(
        self,
        prompt: ModelInput,
        num_samples: int = 1,
        sampling_params: SamplingParams = _DEFAULT_SAMPLING_PARAMS,
        include_prompt_logprobs: bool = False,
        topk_prompt_logprobs: int = 0,
        return_text: bool = True,
    ) -> SampleResponse:
        """Generate one or more sequences asynchronously.

        Args:
            prompt: Encoded prompt tokens.
            num_samples: Number of candidate sequences to generate.
            sampling_params: Generation length and sampling strategy.
            include_prompt_logprobs: Whether to return prompt token logprobs.
            topk_prompt_logprobs: Number of top candidates returned per prompt position.
            return_text: Whether to return decoded text for each sequence.

        Returns:
            The sampling response after the Actor request completes.

        Raises:
            ValidationError: The prompt is empty or sampling parameters are invalid.
        """
        response = await self._event_loop.run_async(
            self._sample(
                prompt=prompt,
                num_samples=num_samples,
                sampling_params=sampling_params,
                include_prompt_logprobs=include_prompt_logprobs,
                topk_prompt_logprobs=topk_prompt_logprobs,
                return_text=return_text,
                return_token_logprobs=True,
            )
        )
        return await response

    async def _sample(
        self,
        prompt: ModelInput,
        num_samples: int = 1,
        sampling_params: SamplingParams = _DEFAULT_SAMPLING_PARAMS,
        include_prompt_logprobs: bool = False,
        topk_prompt_logprobs: int = 0,
        return_text: bool = True,
        return_token_logprobs: bool = True,
    ) -> APIFuture[SampleResponse]:
        response = await self._submit_sample(
            prompt=prompt,
            num_samples=num_samples,
            sampling_params=sampling_params,
            include_prompt_logprobs=include_prompt_logprobs,
            topk_prompt_logprobs=topk_prompt_logprobs,
            return_text=return_text,
            return_token_logprobs=return_token_logprobs,
        )
        return response.map(self._parse_sample_response)

    async def _submit_sample(
        self,
        prompt: ModelInput,
        num_samples: int,
        sampling_params: SamplingParams,
        include_prompt_logprobs: bool,
        topk_prompt_logprobs: int = 0,
        return_text: bool = True,
        return_token_logprobs: bool = True,
    ) -> APIFuture[ActorSampleResponse]:
        """校验用户输入并将强类型请求提交到 sampling run coordinator。"""
        self._validate_non_empty_prompt(prompt)
        if prompt.has_images and (include_prompt_logprobs or topk_prompt_logprobs > 0):
            raise ValidationError(
                "prompt logprobs do not support image chunks",
                code="validation.image_logprobs_unsupported",
            )
        if sampling_params.max_tokens is None or sampling_params.max_tokens <= 0:
            raise ValidationError(
                "sampling_params.max_tokens must be greater than 0",
                code="validation.invalid_sampling_request",
            )
        try:
            request = build_sample_request(
                prompt,
                sampling_params=sampling_params,
                num_samples=num_samples,
                include_prompt_logprobs=include_prompt_logprobs,
                topk_prompt_logprobs=topk_prompt_logprobs,
                return_text=return_text,
                return_token_logprobs=return_token_logprobs,
            )
        except PydanticValidationError as e:
            raise ValidationError(
                "invalid sampling request",
                code="validation.invalid_sampling_request",
                details={"errors": e.errors()},
            ) from None

        return await self._sampling_coordinator.submit(request)

    def _parse_sample_response(
        self,
        response: ActorSampleResponse,
    ) -> SampleResponse:
        return actor_sample_response_to_sdk(response)

    def _validate_non_empty_prompt(self, prompt: ModelInput) -> None:
        if prompt.is_empty:
            raise ValidationError(
                "prompt cannot be empty", code="validation.empty_prompt"
            )

    def compute_logprobs(self, prompt: ModelInput) -> APIFuture[list[float | None]]:
        """Compute the logprob of each prompt token.

        Args:
            prompt: Encoded prompt tokens.

        Returns:
            An API future that resolves to prompt-aligned logprobs. Positions omitted
            by the server contain ``None``.

        Raises:
            ValidationError: The prompt is empty.
        """
        return self._event_loop.run_sync(self._compute_logprobs(prompt=prompt))

    async def compute_logprobs_async(self, prompt: ModelInput) -> list[float | None]:
        """Compute prompt token logprobs asynchronously.

        Args:
            prompt: Encoded prompt tokens.

        Returns:
            Prompt-aligned logprobs. Positions omitted by the server contain ``None``.

        Raises:
            ValidationError: The prompt is empty.
        """
        response = await self._event_loop.run_async(
            self._compute_logprobs(prompt=prompt)
        )
        return await response

    async def _compute_logprobs(
        self, prompt: ModelInput
    ) -> APIFuture[list[float | None]]:
        """用单 token 采样请求复用 Actor 的 prompt logprob 能力。"""
        self._validate_non_empty_prompt(prompt)
        if prompt.has_images:
            raise ValidationError(
                "compute_logprobs does not support image chunks",
                code="validation.image_logprobs_unsupported",
            )

        response = await self._submit_sample(
            prompt=prompt,
            num_samples=1,
            sampling_params=SamplingParams(max_tokens=1),
            include_prompt_logprobs=True,
            return_text=False,
            return_token_logprobs=False,
        )
        return response.map(self._parse_prompt_logprobs)

    def _parse_prompt_logprobs(
        self,
        response: ActorSampleResponse,
    ) -> list[float | None]:
        sample_response = actor_sample_response_to_sdk(response)
        return sample_response.prompt_logprobs

    def get_tokenizer(self) -> object:
        """Return the tokenizer for this client's base model.

        Returns:
            A tokenizer provided by ModelScope or Transformers.
        """
        return get_tokenizer(self.model_id)
