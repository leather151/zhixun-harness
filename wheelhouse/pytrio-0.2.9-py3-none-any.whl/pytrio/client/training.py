"""编排训练请求、惰性初始化和用户结果转换。"""

import asyncio
import functools
import inspect
import logging
import uuid
import weakref
from collections.abc import Callable, Coroutine, Sized
from dataclasses import dataclass
from typing import TYPE_CHECKING, TypeAlias, TypeVar, cast

from pytrio.client.adapters.limits import (
    sampling_run_limits_from_control,
    training_run_limits_from_control,
)
from pytrio.client.adapters.training import (
    actor_forward_responses_to_sdk,
    actor_optim_response_to_sdk,
    actor_save_state_response_to_sdk,
    actor_save_weights_response_to_sdk,
)
from pytrio.client.builders.training import (
    build_trainer_forward_payload,
    build_trainer_init_payload,
    build_trainer_optimize_payload,
    build_trainer_save_payload,
)
from pytrio.client.sampling import SamplingClient
from pytrio.client.training_batch import plan_training_batch
from pytrio.errors.base import DependencyError, ValidationError
from pytrio.model.limits import TrainingLimits
from pytrio.model.tokenizer import get_tokenizer
from pytrio.observability.api import record_operation
from pytrio.protocol.actor.events.event import EventType
from pytrio.protocol.actor.events.trainer.lora import (
    CheckpointLoraSource,
    LoraRunSpec,
    LoraSource,
)
from pytrio.protocol.actor.events.trainer.save import CheckpointVisibility
from pytrio.protocol.control.actor.credentials import ActorConnectionInfo, ActorJWT
from pytrio.protocol.control.training_run.update import TrainingRunUpdateResponse
from pytrio.runtime.event_loop import SDKEventLoopRunner
from pytrio.runtime.service import ActorHeartbeatHandle, ServiceRuntime
from pytrio.transport.actor.training_run.coordinator import ActorTrainingRunCoordinator
from pytrio.transport.control.actor_capacity import call_with_actor_capacity_polling
from pytrio.types.checkpoint.save_weights_for_sampler_response import (
    SaveWeightsForSamplerResponse,
)
from pytrio.types.checkpoint.save_weights_response import SaveWeightsResponse
from pytrio.types.forward.datum import Datum
from pytrio.types.forward.forward_backward_output import ForwardBackwardOutput
from pytrio.types.forward.tensor_data import TensorData
from pytrio.types.future.api_future import APIFuture
from pytrio.types.optim_step.adam_params import AdamParams
from pytrio.types.optim_step.optim_step_response import OptimStepResponse

logger = logging.getLogger(__name__)

APIFutureDict = APIFuture[dict[str, object]]
T = TypeVar("T")
CustomLossResult: TypeAlias = tuple["torch.Tensor", dict[str, float]]
CustomLossFnWithoutConfig: TypeAlias = Callable[
    [list[Datum], list["torch.Tensor"]], CustomLossResult
]
CustomLossFnWithConfig: TypeAlias = Callable[
    [list[Datum], list["torch.Tensor"], dict[str, object]], CustomLossResult
]
CustomLossFn: TypeAlias = CustomLossFnWithoutConfig | CustomLossFnWithConfig
_TEMP_SAMPLING_NAME_PREFIX = "temp-sampling-"
_TEMP_SAMPLING_TTL_SECONDS = 6 * 60 * 60
_TEMP_SAMPLING_VISIBILITY: CheckpointVisibility = "TEMPORARY"

if TYPE_CHECKING:
    import torch  # pyright: ignore[reportMissingImports] - optional dependency


def _invoke_custom_loss(
    loss_fn: CustomLossFn,
    data: list[Datum],
    logprobs: list["torch.Tensor"],
    loss_fn_config: dict[str, object] | None,
) -> CustomLossResult:
    """按 callable 实际签名决定是否传入本地 loss 配置。"""
    if loss_fn_config is None:
        loss_fn_without_config = cast(CustomLossFnWithoutConfig, loss_fn)
        return loss_fn_without_config(data, logprobs)

    try:
        inspect.signature(loss_fn).bind(data, logprobs, loss_fn_config)
    except (TypeError, ValueError):
        loss_fn_without_config = cast(CustomLossFnWithoutConfig, loss_fn)
        return loss_fn_without_config(data, logprobs)

    loss_fn_with_config = cast(CustomLossFnWithConfig, loss_fn)
    return loss_fn_with_config(data, logprobs, loss_fn_config)


@dataclass(frozen=True)
class _PendingTrainingActorBinding:
    """尚未创建 Actor run coordinator 的训练绑定。"""

    actor: ActorConnectionInfo
    actor_jwt: ActorJWT


@dataclass(frozen=True)
class _InitializingTrainingActorBinding:
    """已绑定 Actor run coordinator、正在等待唯一 init 结果。"""

    coordinator: ActorTrainingRunCoordinator
    heartbeat_handle: ActorHeartbeatHandle


@dataclass(frozen=True)
class _ReadyTrainingActorBinding:
    """Trainer 已完成初始化的 Actor 绑定。"""

    coordinator: ActorTrainingRunCoordinator
    heartbeat_handle: ActorHeartbeatHandle


TrainingActorBindingState: TypeAlias = (
    _PendingTrainingActorBinding
    | _InitializingTrainingActorBinding
    | _ReadyTrainingActorBinding
)


class _TrainingHeartbeatOwner:
    """为 TrainingClient finalizer 持有可原子替换的 heartbeat 句柄。"""

    def __init__(self) -> None:
        self._handle: ActorHeartbeatHandle = ActorHeartbeatHandle()

    def bind(self, handle: ActorHeartbeatHandle) -> None:
        """将资源所有权切换到最终 Actor 的 heartbeat。"""
        self._handle.close()
        self._handle = handle

    def close(self) -> None:
        """幂等停止当前 heartbeat。"""
        try:
            self._handle.close()
        except Exception:
            logger.debug("Failed to close training heartbeat handle", exc_info=True)


class TrainingClient:
    """Submit Trainer events for one LoRA training run.

    The client owns an Actor training run coordinator and heartbeat handle while sharing
    the root client's runtime. The first stateful operation submits exactly one
    ``TRAINER_INIT_RUN`` under an initialization lock; later events remain ordered
    by the same coordinator.

    Args:
        training_run_cuid: Training run CUID created by Control.
        model_id: Canonical model ID resolved by Control.
        lora: LoRA configuration and initial weight source.
        actor_binding: 完整的 Actor 绑定与初始化状态。
        runtime: Runtime shared with the root service client.
        service_session_cuid: Service session that owns this training run.
        limits: Training request limits for the model.
        model_alias: Exact Control model alias used for derived sampling runs.
        init_load_optimizer: Whether initialization restores optimizer state.
    """

    def __init__(
        self,
        training_run_cuid: str,
        model_id: str,
        lora: LoraRunSpec,
        actor_binding: TrainingActorBindingState,
        runtime: ServiceRuntime,
        service_session_cuid: str,
        limits: TrainingLimits,
        model_alias: str,
        init_load_optimizer: bool = False,
    ) -> None:
        self.training_run_cuid: str = training_run_cuid
        self._training_run_cuid: str = training_run_cuid
        self.model_id: str = model_id
        self.model_alias: str = model_alias
        self.lora: LoraRunSpec = lora
        self._limits: TrainingLimits = limits

        self._actor_binding: TrainingActorBindingState = actor_binding
        self._runtime: ServiceRuntime = runtime
        self._service_session_cuid: str = service_session_cuid
        self._event_loop: SDKEventLoopRunner = runtime.event_loop
        self._heartbeat_owner: _TrainingHeartbeatOwner = _TrainingHeartbeatOwner()
        if isinstance(
            actor_binding,
            (_InitializingTrainingActorBinding, _ReadyTrainingActorBinding),
        ):
            self._heartbeat_owner.bind(actor_binding.heartbeat_handle)
        self._finalizer: weakref.finalize = weakref.finalize(
            self, self._heartbeat_owner.close
        )
        self._init_lock: asyncio.Lock = asyncio.Lock()
        self._init_source: LoraSource = lora.source
        self._init_load_optimizer: bool = (
            init_load_optimizer
            if isinstance(lora.source, CheckpointLoraSource)
            else False
        )

    def _run_sync(self, coro: Coroutine[object, object, T]) -> T:
        try:
            return self._event_loop.run_sync(coro)
        except Exception:
            coro.close()
            raise

    async def _run_async(self, coro: Coroutine[object, object, T]) -> T:
        try:
            return await self._event_loop.run_async(coro)
        except Exception:
            coro.close()
            raise

    async def _ensure_initialized(self) -> ActorTrainingRunCoordinator:
        """在共享锁内完成一次 Trainer 初始化并发布 READY 状态。"""
        actor_binding = self._actor_binding
        if isinstance(actor_binding, _ReadyTrainingActorBinding):
            return actor_binding.coordinator
        async with self._init_lock:
            actor_binding = self._actor_binding
            if isinstance(actor_binding, _ReadyTrainingActorBinding):
                return actor_binding.coordinator
            if isinstance(actor_binding, _PendingTrainingActorBinding):
                actor_binding = self._activate_actor(actor_binding)
            await self._submit_init(actor_binding.coordinator)
            ready = _ReadyTrainingActorBinding(
                coordinator=actor_binding.coordinator,
                heartbeat_handle=actor_binding.heartbeat_handle,
            )
            self._actor_binding = ready
            return ready.coordinator

    def _activate_actor(
        self, actor_binding: _PendingTrainingActorBinding
    ) -> _InitializingTrainingActorBinding:
        """使用 Control 最终确认的凭据创建唯一 run coordinator 和 heartbeat。"""
        coordinator = self._runtime.create_actor_training_run_coordinator(
            actor_binding.actor,
            actor_binding.actor_jwt,
            functools.partial(
                self._runtime.control_client.renew_training_run,
                self._training_run_cuid,
            ),
            training_run_cuid=self._training_run_cuid,
        )
        heartbeat_handle = self._runtime.start_actor_heartbeat(coordinator.actor_client)
        initializing = _InitializingTrainingActorBinding(
            coordinator=coordinator,
            heartbeat_handle=heartbeat_handle,
        )
        self._heartbeat_owner.bind(heartbeat_handle)
        self._actor_binding = initializing
        return initializing

    async def _submit_init(self, coordinator: ActorTrainingRunCoordinator) -> None:
        future = await coordinator.submit(
            EventType.TRAINER_INIT_RUN,
            build_trainer_init_payload(
                self.lora,
                source=self._init_source,
                load_optimizer=self._init_load_optimizer,
            ),
        )
        await future

    def _validate_non_empty_batch(self, data: list[Datum]) -> None:
        if not data:
            raise ValidationError(
                "training data cannot be empty", code="validation.empty_training_data"
            )

    def forward(
        self,
        data: list[Datum],
        loss_fn: str = "cross_entropy",
        loss_fn_config: dict[str, object] | None = None,
        auto_shift: bool = False,
    ) -> APIFuture[ForwardBackwardOutput]:
        """Run a forward pass with automatic batch splitting.

        Args:
            data: Training samples in user-provided order.
            loss_fn: Loss function supported by the Trainer.
            loss_fn_config: Optional loss function configuration.
            auto_shift: Whether the Trainer shifts labels by one token.

        Returns:
            An API future that resolves to the aggregated logical-batch output.

        Raises:
            ValidationError: The batch is empty, loss inputs are invalid, or one sample
                exceeds model limits.
        """
        return self._run_sync(
            self._forward(
                data=data,
                loss_fn=loss_fn,
                loss_fn_config=loss_fn_config,
                auto_shift=auto_shift,
            )
        )

    async def forward_async(
        self,
        data: list[Datum],
        loss_fn: str = "cross_entropy",
        loss_fn_config: dict[str, object] | None = None,
        auto_shift: bool = False,
    ) -> APIFuture[ForwardBackwardOutput]:
        """Submit a forward pass asynchronously with automatic batch splitting.

        Args:
            data: Training samples in user-provided order.
            loss_fn: Loss function supported by the Trainer.
            loss_fn_config: Optional loss function configuration.
            auto_shift: Whether the Trainer shifts labels by one token.

        Returns:
            An API future that resolves to the aggregated logical-batch output.

        Raises:
            ValidationError: The batch is empty, loss inputs are invalid, or one sample
                exceeds model limits.
        """
        return await self._run_async(
            self._forward(
                data=data,
                loss_fn=loss_fn,
                loss_fn_config=loss_fn_config,
                auto_shift=auto_shift,
            )
        )

    async def _forward(
        self,
        data: list[Datum],
        loss_fn: str = "cross_entropy",
        loss_fn_config: dict[str, object] | None = None,
        auto_shift: bool = False,
    ) -> APIFuture[ForwardBackwardOutput]:
        return await self._submit_forward_batch(
            event_type=EventType.TRAINER_FORWARD,
            data=data,
            loss_fn=loss_fn,
            loss_fn_config=loss_fn_config,
            auto_shift=auto_shift,
        )

    def forward_backward_custom(
        self,
        data: list[Datum],
        loss_fn: CustomLossFn,
        loss_fn_config: dict[str, object] | None = None,
    ) -> APIFuture[ForwardBackwardOutput]:
        """Run forward and backward passes with a local PyTorch loss function.

        Args:
            data: Training samples in user-provided order.
            loss_fn: Function that maps samples and per-sample logprobs to a scalar
                loss tensor and custom metrics.
            loss_fn_config: Optional configuration passed only to the local loss
                function as a single mapping.

        Returns:
            An API future that resolves after the Trainer completes backward.

        Raises:
            DependencyError: PyTorch is not installed.
            ValidationError: Backend logprobs are missing or the local loss produces no
                gradients.
        """
        return self._run_sync(
            self._forward_backward_custom(
                data=data,
                loss_fn=loss_fn,
                loss_fn_config=loss_fn_config,
            )
        )

    async def forward_backward_custom_async(
        self,
        data: list[Datum],
        loss_fn: CustomLossFn,
        loss_fn_config: dict[str, object] | None = None,
    ) -> APIFuture[ForwardBackwardOutput]:
        """Submit a custom-loss forward-backward pass asynchronously.

        Args:
            data: Training samples in user-provided order.
            loss_fn: Function that maps samples and per-sample logprobs to a scalar
                loss tensor and custom metrics.
            loss_fn_config: Optional configuration passed only to the local loss
                function as a single mapping.

        Returns:
            An API future that resolves after the Trainer completes backward.

        Raises:
            DependencyError: PyTorch is not installed.
            ValidationError: Backend logprobs are missing or the local loss produces no
                gradients.
        """
        return await self._run_async(
            self._forward_backward_custom(
                data=data,
                loss_fn=loss_fn,
                loss_fn_config=loss_fn_config,
            )
        )

    async def _forward_backward_custom(
        self,
        data: list[Datum],
        loss_fn: CustomLossFn,
        loss_fn_config: dict[str, object] | None,
    ) -> APIFuture[ForwardBackwardOutput]:
        """把本地 autograd 梯度转换为 Trainer 可执行的线性代理损失。"""
        try:
            import torch  # pyright: ignore[reportMissingImports] - optional dependency
        except ImportError:
            raise DependencyError(
                "Detected missing 'torch'. This operation requires it. "
                "Install via 'pip install torch'.",
                code="dependency.missing_torch",
            )

        self._validate_non_empty_batch(data)

        # 首次前向从 Trainer 获取逐 token logprob；这些值在本地重建为叶子 tensor，
        # 用户损失只参与梯度计算，不进入 Actor 协议。
        forward_future = await self._forward(
            data=data,
            loss_fn="cross_entropy",
            loss_fn_config=None,
            auto_shift=False,
        )
        forward_result = await forward_future

        logprobs_list: list[torch.Tensor] = []
        for output in forward_result.loss_fn_outputs:
            if "logprobs" not in output:
                raise ValidationError(
                    "custom loss requires backend logprobs in forward output",
                    code="validation.missing_logprobs",
                )
            raw = output["logprobs"]
            logprob = torch.tensor(raw.data, dtype=torch.float32).reshape(raw.shape)
            logprobs_list.append(logprob.clone().detach().requires_grad_(True))

        loss, custom_metrics = _invoke_custom_loss(
            loss_fn, data, logprobs_list, loss_fn_config
        )
        loss.backward()

        # 对 logprob 的负梯度作为交叉熵权重，使 Trainer 反向得到与本地自定义损失相同
        # 的参数梯度方向。
        linear_loss_data: list[Datum] = []
        for datum, logprob in zip(data, logprobs_list, strict=True):
            if logprob.grad is None:
                raise ValidationError(
                    "Custom loss output has no gradients. Ensure loss_fn returns a tensor with gradients.",
                    code="validation.missing_custom_loss_gradient",
                )

            grad = logprob.grad.clone().detach()
            linear_loss_data.append(
                Datum(
                    model_input=datum.model_input,
                    loss_fn_inputs={
                        "target_tokens": datum.loss_fn_inputs["target_tokens"],
                        # TensorData 保留 autograd 梯度的原始 shape，并作为 batch planner
                        # 与 builder 之间的强类型输入。
                        "weights": TensorData.from_torch((-grad).cpu()),
                    },
                )
            )

        backend_future = await self._forward_backward(
            data=linear_loss_data,
            loss_fn="cross_entropy",
            loss_fn_config=None,
            auto_shift=False,
        )

        return backend_future.map(
            functools.partial(
                self._merge_custom_metrics,
                custom_metrics=custom_metrics,
            )
        )

    def _merge_custom_metrics(
        self,
        response: ForwardBackwardOutput,
        *,
        custom_metrics: dict[str, float],
    ) -> ForwardBackwardOutput:
        return ForwardBackwardOutput(
            loss_fn_outputs=response.loss_fn_outputs,
            metrics={**response.metrics, **custom_metrics},
        )

    def forward_backward(
        self,
        data: list[Datum],
        loss_fn: str = "cross_entropy",
        loss_fn_config: dict[str, object] | None = None,
        auto_shift: bool = False,
    ) -> APIFuture[ForwardBackwardOutput]:
        """Run forward and backward passes with automatic gradient accumulation.

        Args:
            data: Samples in the logical training batch, in user-provided order.
            loss_fn: Loss function supported by the Trainer.
            loss_fn_config: Optional loss function configuration.
            auto_shift: Whether the Trainer shifts labels by one token.

        Returns:
            An API future that resolves to the aggregated logical-batch output.

        Raises:
            ValidationError: The batch is empty, loss inputs are invalid, or one sample
                exceeds model limits.
        """
        return self._run_sync(
            self._forward_backward(
                data=data,
                loss_fn=loss_fn,
                loss_fn_config=loss_fn_config,
                auto_shift=auto_shift,
            )
        )

    async def forward_backward_async(
        self,
        data: list[Datum],
        loss_fn: str = "cross_entropy",
        loss_fn_config: dict[str, object] | None = None,
        auto_shift: bool = False,
    ) -> APIFuture[ForwardBackwardOutput]:
        """Submit automatic batch splitting and gradient accumulation asynchronously.

        Args:
            data: Samples in the logical training batch, in user-provided order.
            loss_fn: Loss function supported by the Trainer.
            loss_fn_config: Optional loss function configuration.
            auto_shift: Whether the Trainer shifts labels by one token.

        Returns:
            An API future that resolves to the aggregated logical-batch output.

        Raises:
            ValidationError: The batch is empty, loss inputs are invalid, or one sample
                exceeds model limits.
        """
        return await self._run_async(
            self._forward_backward(
                data=data,
                loss_fn=loss_fn,
                loss_fn_config=loss_fn_config,
                auto_shift=auto_shift,
            )
        )

    async def _forward_backward(
        self,
        data: list[Datum],
        loss_fn: str = "cross_entropy",
        loss_fn_config: dict[str, object] | None = None,
        auto_shift: bool = False,
    ) -> APIFuture[ForwardBackwardOutput]:
        return await self._submit_forward_batch(
            event_type=EventType.TRAINER_FORWARD_BACKWARD,
            data=data,
            loss_fn=loss_fn,
            loss_fn_config=loss_fn_config,
            auto_shift=auto_shift,
        )

    async def _submit_forward_batch(
        self,
        *,
        event_type: EventType,
        data: list[Datum],
        loss_fn: str,
        loss_fn_config: dict[str, object] | None,
        auto_shift: bool,
    ) -> APIFuture[ForwardBackwardOutput]:
        """编排一次逻辑 forward 调用从领域计划到异步结果的完整数据流。

        Client 依次组织 planner、builder、coordinator 和 adapter。planner 计算 totals，
        coordinator 构造 event metadata，adapter 解释后端响应。
        """
        if event_type not in (
            EventType.TRAINER_FORWARD,
            EventType.TRAINER_FORWARD_BACKWARD,
        ):
            raise ValueError(f"unsupported forward event type: {event_type.value}")

        self._validate_non_empty_batch(data)
        # 完整输入校验和 totals 计算先形成不可变计划，随后构造全部物理请求并进入初始化
        # 与网络提交阶段。
        plan = plan_training_batch(
            data,
            loss_fn=loss_fn,
            auto_shift=auto_shift,
            limits=self._limits,
            tokenizer_vocab_size=self._tokenizer_vocab_size,
        )
        payloads = [
            build_trainer_forward_payload(
                chunk=chunk,
                loss_fn_config=loss_fn_config,
                auto_shift=auto_shift,
                gradient_accumulation=plan.totals,
            )
            for chunk in plan.chunks
        ]

        coordinator = await self._ensure_initialized()
        # coordinator 将全部 payload 作为一个逻辑事件组原子准入：FB 分片共享 step，index
        # 仍逐事件递增，组内事件在本地队列中保持连续。
        response = await coordinator.submit_group(event_type, payloads)
        expected_samples = tuple(len(chunk.samples) for chunk in plan.chunks)
        # 公共调用暴露一个逻辑 Future，transport 管理物理 Future 的完成顺序和数量。
        return response.map(
            functools.partial(
                self._parse_forward_outputs,
                expected_samples=expected_samples,
            )
        )

    def _parse_forward_outputs(
        self,
        responses: list[dict[str, object]],
        *,
        expected_samples: tuple[int, ...],
    ) -> ForwardBackwardOutput:
        return actor_forward_responses_to_sdk(
            responses,
            expected_samples=expected_samples,
        )

    def optim_step(self, adam_params: AdamParams) -> APIFuture[OptimStepResponse]:
        """Apply one optimizer step using the currently accumulated gradients.

        Args:
            adam_params: AdamW parameters for this optimizer step.

        Returns:
            An API future that resolves to Trainer optimizer metrics.
        """
        return self._run_sync(self._optim_step(adam_params=adam_params))

    async def optim_step_async(
        self, adam_params: AdamParams
    ) -> APIFuture[OptimStepResponse]:
        """Submit one optimizer step asynchronously.

        Args:
            adam_params: AdamW parameters for this optimizer step.

        Returns:
            An API future that resolves to Trainer optimizer metrics.
        """
        return await self._run_async(self._optim_step(adam_params=adam_params))

    async def _optim_step(
        self, adam_params: AdamParams
    ) -> APIFuture[OptimStepResponse]:
        coordinator = await self._ensure_initialized()
        response = await coordinator.submit(
            EventType.TRAINER_OPTIMIZE_STEP,
            build_trainer_optimize_payload(adam_params),
        )
        return response.map(self._parse_optim_step)

    def _parse_optim_step(
        self,
        response: dict[str, object],
    ) -> OptimStepResponse:
        return actor_optim_response_to_sdk(response)

    def save_state(
        self, name: str, ttl_seconds: int | None = None, overwrite: bool = False
    ) -> APIFuture[SaveWeightsResponse]:
        """Save model weights and optimizer state.

        Args:
            name: Checkpoint name within the current training run.
            ttl_seconds: Optional checkpoint lifetime in seconds.
            overwrite: Whether to replace a checkpoint with the same name.

        Returns:
            An API future that resolves to the checkpoint URI, model, and size.
        """
        return self._run_sync(
            self._save_state(name=name, ttl_seconds=ttl_seconds, overwrite=overwrite)
        )

    async def save_state_async(
        self, name: str, ttl_seconds: int | None = None, overwrite: bool = False
    ) -> APIFuture[SaveWeightsResponse]:
        """Save model weights and optimizer state asynchronously.

        Args:
            name: Checkpoint name within the current training run.
            ttl_seconds: Optional checkpoint lifetime in seconds.
            overwrite: Whether to replace a checkpoint with the same name.

        Returns:
            An API future that resolves to the checkpoint URI, model, and size.
        """
        return await self._run_async(
            self._save_state(name=name, ttl_seconds=ttl_seconds, overwrite=overwrite)
        )

    async def _save_state(
        self, name: str, ttl_seconds: int | None = None, overwrite: bool = False
    ) -> APIFuture[SaveWeightsResponse]:
        payload = build_trainer_save_payload(
            name,
            ttl_seconds,
            overwrite=overwrite,
        )
        coordinator = await self._ensure_initialized()
        response = await coordinator.submit(
            EventType.TRAINER_SAVE_STATE,
            payload,
        )
        return response.map(self._parse_save_state)

    def _parse_save_state(
        self,
        response: dict[str, object],
    ) -> SaveWeightsResponse:
        try:
            return actor_save_state_response_to_sdk(
                response,
                default_model=self.model_id,
            )
        except Exception as error:
            self._record_checkpoint_result_error(response, error)
            raise

    def save_weights_for_sampler(
        self, name: str, ttl_seconds: int | None = None
    ) -> APIFuture[SaveWeightsForSamplerResponse]:
        """Save model weights in a sampler-loadable form.

        Args:
            name: Weight name within the current training run.
            ttl_seconds: Optional weight lifetime in seconds.

        Returns:
            An API future that resolves to the weight URI, model, and size.
        """
        return self._run_sync(
            self._save_weights_for_sampler(name=name, ttl_seconds=ttl_seconds)
        )

    async def save_weights_for_sampler_async(
        self, name: str, ttl_seconds: int | None = None
    ) -> APIFuture[SaveWeightsForSamplerResponse]:
        """Save sampler weights asynchronously.

        Args:
            name: Weight name within the current training run.
            ttl_seconds: Optional weight lifetime in seconds.

        Returns:
            An API future that resolves to the weight URI, model, and size.
        """
        return await self._run_async(
            self._save_weights_for_sampler(name=name, ttl_seconds=ttl_seconds)
        )

    async def _save_weights_for_sampler(
        self,
        name: str,
        ttl_seconds: int | None = None,
        visibility: CheckpointVisibility = "WORKSPACE",
    ) -> APIFuture[SaveWeightsForSamplerResponse]:
        payload = build_trainer_save_payload(
            name,
            ttl_seconds,
            visibility=visibility,
        )
        coordinator = await self._ensure_initialized()
        response = await coordinator.submit(
            EventType.TRAINER_SAVE_WEIGHTS,
            payload,
        )
        return response.map(self._parse_save_weights_for_sampler)

    def _parse_save_weights_for_sampler(
        self,
        response: dict[str, object],
    ) -> SaveWeightsForSamplerResponse:
        try:
            return actor_save_weights_response_to_sdk(
                response,
                default_model=self.model_id,
            )
        except Exception as error:
            self._record_checkpoint_result_error(response, error)
            raise

    def _record_checkpoint_result_error(
        self,
        response: dict[str, object],
        error: Exception,
    ) -> None:
        """Record SDK conversion failures after the Actor created a checkpoint."""
        attributes = {
            "training_run_cuid": self._training_run_cuid,
            "stage": "sdk_response",
            "error": type(error).__name__,
            "error.code": "actor.invalid_response",
            "error.message": "Failed to convert Actor checkpoint response",
        }
        result = response.get("result")
        if isinstance(result, dict):
            checkpoint = result.get("checkpoint")
            if isinstance(checkpoint, dict):
                checkpoint_cuid = checkpoint.get("checkpoint_cuid") or checkpoint.get(
                    "cuid"
                )
                if isinstance(checkpoint_cuid, str) and checkpoint_cuid:
                    attributes["checkpoint_cuid"] = checkpoint_cuid
        record_operation(
            self._runtime.telemetry,
            "checkpoint_save",
            status="error",
            attributes=attributes,
        )

    def load_state(self, path: str) -> APIFutureDict:
        """Load checkpoint weights before the first training operation.

        Args:
            path: Checkpoint URI returned by ``save_state``.

        Returns:
            An API future that marks Trainer initialization completion.

        Raises:
            ValidationError: The Trainer has already been initialized.
        """
        return self._run_sync(self._load_state(path=path))

    async def load_state_async(self, path: str) -> APIFutureDict:
        """Load checkpoint weights asynchronously.

        Args:
            path: Checkpoint URI returned by ``save_state``.

        Returns:
            An API future that marks Trainer initialization completion.

        Raises:
            ValidationError: The Trainer has already been initialized.
        """
        return await self._run_async(self._load_state(path=path))

    async def _load_state(self, path: str) -> APIFutureDict:
        return await self._load_state_impl(path=path, load_optimizer=False)

    def load_state_with_optimizer(self, path: str) -> APIFutureDict:
        """Load checkpoint weights and optimizer state before training starts.

        Args:
            path: Checkpoint URI returned by ``save_state``.

        Returns:
            An API future that marks Trainer initialization completion.

        Raises:
            ValidationError: The Trainer has already been initialized.
        """
        return self._run_sync(self._load_state_with_optimizer(path=path))

    async def load_state_with_optimizer_async(self, path: str) -> APIFutureDict:
        """Load checkpoint weights and optimizer state asynchronously.

        Args:
            path: Checkpoint URI returned by ``save_state``.

        Returns:
            An API future that marks Trainer initialization completion.

        Raises:
            ValidationError: The Trainer has already been initialized.
        """
        return await self._run_async(self._load_state_with_optimizer(path=path))

    async def _load_state_with_optimizer(self, path: str) -> APIFutureDict:
        return await self._load_state_impl(path=path, load_optimizer=True)

    async def _load_state_impl(
        self, path: str, *, load_optimizer: bool
    ) -> APIFutureDict:
        """校验并原子绑定 checkpoint，再向最终 Actor 提交唯一初始化。

        Args:
            path: ``save_state`` 返回的 checkpoint URI。
            load_optimizer: 是否同时恢复优化器状态。

        Returns:
            已完成的 Trainer 初始化标记。

        Raises:
            ValidationError: Trainer 已经初始化。
        """
        async with self._init_lock:
            if not isinstance(self._actor_binding, _PendingTrainingActorBinding):
                raise ValidationError(
                    "load_state cannot be called after training has started. "
                    "Call load_state before the first training operation.",
                    code="validation.already_initialized",
                )
            source_run = (
                await self._runtime.control_client.find_training_run_by_checkpoint_uri(
                    path
                )
            )
            mismatches: list[dict[str, object]] = []
            for field, target, source in (
                ("base_model", self.model_id, source_run.base_model),
                ("lora_rank", self.lora.rank, source_run.lora_rank),
                ("train_mlp", self.lora.train_mlp, source_run.train_mlp),
                ("train_attn", self.lora.train_attn, source_run.train_attn),
                (
                    "train_unembed",
                    self.lora.train_unembed,
                    source_run.train_unembed,
                ),
            ):
                if target != source:
                    mismatches.append(
                        {"field": field, "target": target, "source": source}
                    )
            if mismatches:
                summary = ", ".join(
                    f"{item['field']} (target={item['target']!r}, source={item['source']!r})"
                    for item in mismatches
                )
                raise ValidationError(
                    f"Checkpoint configuration is incompatible: {summary}.",
                    code="validation.checkpoint_config_mismatch",
                    details={"mismatches": mismatches},
                )

            async def update_training_run() -> TrainingRunUpdateResponse:
                """执行一轮 PATCH，并在请求完成时保持取消对账语义。"""
                update_task = asyncio.create_task(
                    self._runtime.control_client.update_training_run(
                        self._service_session_cuid,
                        self._training_run_cuid,
                        source_checkpoint_uri=path,
                        restore_optimizer=load_optimizer,
                    )
                )
                try:
                    return await asyncio.shield(update_task)
                except asyncio.CancelledError:
                    run = await update_task
                    self._apply_restore_binding(run)
                    raise

            run = await call_with_actor_capacity_polling(
                update_training_run,
                self._runtime.configuration,
            )

            actor_binding = self._apply_restore_binding(run)
            initializing = self._activate_actor(actor_binding)
            await self._submit_init(initializing.coordinator)
            self._actor_binding = _ReadyTrainingActorBinding(
                coordinator=initializing.coordinator,
                heartbeat_handle=initializing.heartbeat_handle,
            )
            return APIFuture.completed({})

    def _apply_restore_binding(
        self, run: TrainingRunUpdateResponse
    ) -> _PendingTrainingActorBinding:
        """发布 Control 原子更新返回的最终 Actor、限制和初始化来源。"""
        actor_binding = _PendingTrainingActorBinding(
            actor=run.actor,
            actor_jwt=run.actor_jwt,
        )
        self._actor_binding = actor_binding
        self._limits = training_run_limits_from_control(run.trainer)
        self._init_source = CheckpointLoraSource(run.source_checkpoint_uri)
        self._init_load_optimizer = run.restore_optimizer
        return actor_binding

    def get_tokenizer(self) -> object:
        """Return the tokenizer for this client's base model.

        Returns:
            A tokenizer provided by ModelScope or Transformers.
        """
        return get_tokenizer(self.model_id)

    @functools.cached_property
    def _tokenizer_vocab_size(self) -> int:
        """Resolve and cache the tokenizer token-ID upper bound."""
        tokenizer = self.get_tokenizer()
        if not isinstance(tokenizer, Sized):
            raise ValidationError(
                "model tokenizer does not expose a vocabulary length",
                code="validation.invalid_tokenizer_vocab_size",
            )
        vocab_size = len(tokenizer)
        if vocab_size < 1:
            raise ValidationError(
                "model tokenizer vocabulary must not be empty",
                code="validation.invalid_tokenizer_vocab_size",
                details={"vocab_size": vocab_size},
            )
        return vocab_size

    async def create_sampling_client_async(self, model_path: str) -> SamplingClient:
        """Create a sampling client for saved LoRA weights asynchronously.

        Args:
            model_path: LoRA weight URI for the sampler to load.

        Returns:
            A sampling client bound to the new sampling run.
        """
        return await self._run_async(
            self._create_sampling_client(model_path=model_path)
        )

    async def _create_sampling_client(self, model_path: str) -> SamplingClient:
        """为当前基础模型和指定权重创建共享运行时的采样 Client。"""
        run = await self._runtime.control_client.create_sampling_run(
            self._service_session_cuid,
            base_model=self.model_alias,
            source_checkpoint_uri=model_path,
        )
        limits = sampling_run_limits_from_control(run.sampler)
        sampling_coordinator = self._runtime.create_actor_sampling_run_coordinator(
            run.actor,
            run.actor_jwt,
            functools.partial(
                self._runtime.control_client.renew_sampling_run,
                run.sampling_run_cuid,
            ),
            sampling_run_cuid=run.sampling_run_cuid,
        )
        return SamplingClient(
            sampling_run_cuid=run.sampling_run_cuid,
            model_id=run.model_id,
            coordinator=sampling_coordinator,
            limits=limits,
            runtime=self._runtime,
        )

    def create_sampling_client(self, model_path: str) -> SamplingClient:
        """Create a sampling client for saved LoRA weights.

        Args:
            model_path: LoRA weight URI for the sampler to load.

        Returns:
            A sampling client bound to the new sampling run.
        """
        return self._run_sync(self._create_sampling_client(model_path=model_path))

    async def save_weights_and_get_sampling_client_async(self) -> SamplingClient:
        """Save temporary weights and create a sampling client asynchronously.

        Returns:
            A sampling client that loads the temporary weights.
        """
        return await self._run_async(self._save_weights_and_get_sampling_client())

    async def _save_weights_and_get_sampling_client(self) -> SamplingClient:
        name = f"{_TEMP_SAMPLING_NAME_PREFIX}{uuid.uuid4().hex}"
        future = await self._save_weights_for_sampler(
            name=name,
            ttl_seconds=_TEMP_SAMPLING_TTL_SECONDS,
            visibility=_TEMP_SAMPLING_VISIBILITY,
        )
        result = await future
        client = await self._create_sampling_client(model_path=result.path)
        return client

    def save_weights_and_get_sampling_client(self) -> SamplingClient:
        """Save temporary weights and create a sampling client.

        Returns:
            A sampling client that loads the temporary weights.
        """
        return self._run_sync(self._save_weights_and_get_sampling_client())
