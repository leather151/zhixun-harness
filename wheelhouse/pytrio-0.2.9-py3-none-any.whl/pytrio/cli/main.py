"""组装 trio 命令行入口及其子命令。"""

import click

from pytrio._version import __version__


@click.group(
    invoke_without_command=True,
    context_settings={"help_option_names": ["-h", "--help"]},
)
@click.version_option(
    __version__,
    "-V",
    "--version",
    prog_name="trio",
    message="PyTrio, version %(version)s",
)
@click.pass_context
def cli(context: click.Context) -> None:
    """Manage local PyTrio authentication and server profiles.

    PyTrio CLI changes only local SDK state under ~/.pytrio. It does not create,
    update, or delete resources on the PyTrio service.

    \b
    Example:
      trio login
          Log in to the active profile.

    \b
      trio env use myprofile
          Switch to the profile named `myprofile`. If it does not exist,
          authenticate against the default PyTrio service and create it.

    \b
      trio env use myprofile --base-url https://pytrio.com
          Authenticate against https://pytrio.com, then create or update the
          `myprofile` configuration and switch to it.

    \b
      trio env show
          Inspect the active profile.

    \b
      trio logout
          Remove its saved credentials.
    """
    if context.invoked_subcommand is None:
        click.echo(f"PyTrio, version {__version__}")
        click.echo(context.get_help())


def register_cli() -> None:
    from pytrio.auth.cli import login, logout
    from pytrio.auth.env_cli import env

    cli.add_command(env)
    cli.add_command(
        click.command(
            name="login",
        )(login)
    )
    cli.add_command(
        click.command(
            name="logout",
        )(logout)
    )


register_cli()
