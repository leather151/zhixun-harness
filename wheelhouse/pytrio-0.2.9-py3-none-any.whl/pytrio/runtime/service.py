"""持有派生 Client 共享的 Control、Actor 和异步运行时资源。"""

import asyncio
import logging
import threading
import weakref
from typing import Protocol

from pytrio.config.config import Configuration, configuration
from pytrio.observability.emitter import (
    NOOP_TELEMETRY_EMITTER,
    TelemetryEmitter,
)
from pytrio.protocol.control.actor.credentials import ActorConnectionInfo, ActorJWT
from pytrio.protocol.control.service_session.close import ServiceSessionCloseStatus
from pytrio.runtime.event_loop import SDKEventLoopRunner
from pytrio.transport.actor.http_base import ActorRenewalCallback
from pytrio.transport.actor.http_client import ActorHTTPClient
from pytrio.transport.actor.http_registry import ActorHTTPClientRegistry
from pytrio.transport.actor.sampling_run.coordinator import ActorSamplingRunCoordinator
from pytrio.transport.actor.training_run.coordinator import ActorTrainingRunCoordinator
from pytrio.transport.control.http_client import ControlHTTPClient

logger = logging.getLogger(__name__)


async def _close_http_resources(
    *,
    actor_http_clients: ActorHTTPClientRegistry | None,
    control_client: ControlHTTPClient | None,
) -> None:
    """Best-effort close for loop-owned HTTP resources."""
    for resource in (actor_http_clients, control_client):
        if resource is None:
            continue
        try:
            await resource.aclose()
        except Exception:
            logger.debug(
                "Failed to close ServiceRuntime HTTP resource %s",
                type(resource).__name__,
                exc_info=True,
            )


def _rollback_service_runtime_initialization(
    *,
    actor_http_clients: ActorHTTPClientRegistry | None,
    telemetry: TelemetryEmitter,
    control_client: ControlHTTPClient | None,
    event_loop: SDKEventLoopRunner | None,
) -> None:
    """Best-effort rollback for resources created before initialization failed."""
    cleanup = _close_http_resources(
        actor_http_clients=actor_http_clients,
        control_client=control_client,
    )
    try:
        if event_loop is not None:
            event_loop.run_sync(cleanup)
        else:
            # The event-loop runner may fail before it can be assigned to the runtime (for
            # example when its worker cannot start).  The injected resources
            # have not been used by another loop yet, so close them on a
            # short-lived loop rather than leaking an AsyncClient.
            try:
                asyncio.get_running_loop()
            except RuntimeError:
                asyncio.run(cleanup)
            else:
                # ServiceRuntime is normally constructed synchronously, but
                # make rollback deterministic when construction is attempted
                # from an already-running loop as well.
                result: list[BaseException] = []

                def run_cleanup() -> None:
                    try:
                        asyncio.run(cleanup)
                    except BaseException as error:  # noqa: BLE001
                        result.append(error)

                thread = threading.Thread(
                    target=run_cleanup,
                    name="pytrio-runtime-rollback",
                    daemon=True,
                )
                thread.start()
                thread.join()
                if result:
                    raise result[0]
    except Exception:
        # A custom/injected event_loop may reject the coroutine before taking
        # ownership (for example an inline event_loop called from a running
        # event loop).  Explicitly close the object in that case; the real
        # SDKEventLoopRunner already performs the same cleanup on rejection.
        cleanup.close()
        logger.debug("Failed to roll back async HTTP resources", exc_info=True)
    try:
        telemetry.close()
    except Exception:
        logger.debug("Failed to roll back telemetry", exc_info=True)
    if event_loop is not None:
        try:
            event_loop.close()
        except Exception:
            logger.debug("Failed to roll back SDKEventLoopRunner", exc_info=True)


class ActorHeartbeatClient(Protocol):
    """运行时心跳循环依赖的 Actor Client 契约。"""

    actor: ActorConnectionInfo

    async def heartbeat(self) -> dict[str, object]:
        raise NotImplementedError


class ActorHeartbeatHandle:
    """拥有单个 training run 心跳 task 的线程安全取消句柄。"""

    def __init__(self, task: asyncio.Task[None] | None = None) -> None:
        self._task: asyncio.Task[None] | None = task
        self._lock: threading.Lock = threading.Lock()

    def close(self) -> None:
        with self._lock:
            task = self._task
            self._task = None
        if task is None or task.done():
            return
        loop = task.get_loop()
        try:
            running_loop = asyncio.get_running_loop()
        except RuntimeError:
            running_loop = None
        try:
            if running_loop is loop:
                task.cancel()
            else:
                loop.call_soon_threadsafe(task.cancel)
        except RuntimeError:
            # The runtime may already have converged and closed its loop.
            return


class _ServiceSessionOwner:
    """拥有远端 ServiceSession，并提供线程安全的单次关闭入口。"""

    def __init__(self, control_client: ControlHTTPClient) -> None:
        self._control_client: ControlHTTPClient = control_client
        self._lock: threading.Lock = threading.Lock()
        self._service_session_cuid: str | None = None
        self._close_status: ServiceSessionCloseStatus = "ENDED"
        self._closed: bool = False

    def bind(self, service_session_cuid: str) -> None:
        """绑定当前 Runtime 创建的唯一 ServiceSession。"""
        with self._lock:
            if self._closed:
                raise RuntimeError("ServiceRuntime is closed")
            if self._service_session_cuid is not None:
                raise RuntimeError("ServiceRuntime already owns a service session")
            self._service_session_cuid = service_session_cuid

    def set_close_status(self, status: ServiceSessionCloseStatus) -> None:
        """在实际关闭前设置关联 Run 的终态。"""
        with self._lock:
            if not self._closed:
                self._close_status = status

    async def aclose(self) -> None:
        """至多一次关闭已绑定的远端 ServiceSession。"""
        with self._lock:
            if self._closed:
                return
            self._closed = True
            service_session_cuid = self._service_session_cuid
            close_status = self._close_status
        if service_session_cuid is not None:
            await self._control_client.close_service_session(
                service_session_cuid,
                status=close_status,
            )


async def _shutdown_service_runtime_async(
    heartbeat_lock: threading.Lock,
    heartbeat_tasks: set[asyncio.Task[None]],
    actor_run_coordinators_lock: threading.Lock,
    actor_run_coordinators: weakref.WeakSet[
        ActorTrainingRunCoordinator | ActorSamplingRunCoordinator
    ],
    service_session_owner: _ServiceSessionOwner,
    actor_http_clients: ActorHTTPClientRegistry,
    control_client: ControlHTTPClient,
) -> None:
    """在 SDK event loop 中按依赖顺序释放全部异步运行时资源。"""
    errors: list[BaseException] = []
    with heartbeat_lock:
        tasks = list(heartbeat_tasks)
        heartbeat_tasks.clear()
    for task in tasks:
        task.cancel()
    if tasks:
        await asyncio.gather(
            *tasks,
            return_exceptions=True,
        )
    with actor_run_coordinators_lock:
        coordinators = list(actor_run_coordinators)
        actor_run_coordinators.clear()
    if coordinators:
        results = await asyncio.gather(
            *(coordinator.aclose() for coordinator in coordinators),
            return_exceptions=True,
        )
        errors.extend(result for result in results if isinstance(result, BaseException))
    try:
        await service_session_owner.aclose()
    except Exception as e:  # noqa: BLE001
        errors.append(e)
    try:
        await actor_http_clients.aclose()
    except Exception as e:  # noqa: BLE001
        errors.append(e)
    try:
        await control_client.aclose()
    except Exception as e:  # noqa: BLE001
        errors.append(e)
    if errors:
        raise errors[0]


def _finish_runtime_shutdown(
    telemetry: TelemetryEmitter,
    event_loop: SDKEventLoopRunner,
    error: BaseException | None = None,
) -> None:
    if error is not None:
        logger.debug(
            "Failed to shut down ServiceRuntime",
            exc_info=(type(error), error, error.__traceback__),
        )
    try:
        telemetry.close()
    except Exception:
        logger.debug("Failed to close telemetry", exc_info=True)
    try:
        event_loop.close()
    except Exception:
        logger.debug("Failed to close SDKEventLoopRunner", exc_info=True)


def _shutdown_service_runtime(
    shutdown_lock: threading.Lock,
    shutdown_started: list[bool],
    heartbeat_lock: threading.Lock,
    heartbeat_tasks: set[asyncio.Task[None]],
    actor_run_coordinators_lock: threading.Lock,
    actor_run_coordinators: weakref.WeakSet[
        ActorTrainingRunCoordinator | ActorSamplingRunCoordinator
    ],
    service_session_owner: _ServiceSessionOwner,
    actor_http_clients: ActorHTTPClientRegistry,
    telemetry: TelemetryEmitter,
    control_client: ControlHTTPClient,
    event_loop: SDKEventLoopRunner,
) -> None:
    """Thread-safe synchronous convergence point for async runtime shutdown."""
    with shutdown_lock:
        if shutdown_started[0]:
            return
        shutdown_started[0] = True

    cleanup = _shutdown_service_runtime_async(
        heartbeat_lock,
        heartbeat_tasks,
        actor_run_coordinators_lock,
        actor_run_coordinators,
        service_session_owner,
        actor_http_clients,
        control_client,
    )
    if event_loop.is_runner_loop():
        task = asyncio.create_task(cleanup)

        def finish(completed: asyncio.Task[None]) -> None:
            error: BaseException | None = None
            if not completed.cancelled():
                try:
                    error = completed.exception()
                except BaseException as exc:  # noqa: BLE001
                    error = exc
            _finish_runtime_shutdown(telemetry, event_loop, error)

        task.add_done_callback(finish)
        return

    error: BaseException | None = None
    try:
        event_loop.run_sync(cleanup)
    except BaseException as exc:  # noqa: BLE001
        error = exc
    _finish_runtime_shutdown(telemetry, event_loop, error)


class ServiceRuntime:
    """派生 Client 共享的服务级资源所有者。

    每个根 ``ServiceClient`` 创建一个运行时。运行时拥有远端 ServiceSession、
    Telemetry emitter、异步 Control Client、SDK event loop 和 Actor HTTP client
    registry，并通过
    finalizer 提供幂等回收。全部派生 Client 共同维持该生命周期。
    """

    def __init__(
        self,
        *,
        api_key: str,
        control_client: ControlHTTPClient | None = None,
        event_loop: SDKEventLoopRunner | None = None,
        actor_http_clients: ActorHTTPClientRegistry | None = None,
        telemetry: TelemetryEmitter | None = None,
        runtime_configuration: Configuration | None = None,
    ) -> None:
        self.configuration: Configuration = (
            configuration.model_copy(deep=True)
            if runtime_configuration is None
            else runtime_configuration
        )
        telemetry_resource = telemetry or NOOP_TELEMETRY_EMITTER
        control_resource = control_client
        event_loop_resource = event_loop
        actor_http_clients_resource = actor_http_clients
        try:
            if event_loop_resource is None:
                event_loop_resource = SDKEventLoopRunner()
            if control_resource is None:
                control_resource = ControlHTTPClient(
                    api_key=api_key,
                    telemetry=telemetry_resource,
                    runtime_configuration=self.configuration,
                )
            if actor_http_clients_resource is None:
                actor_http_clients_resource = ActorHTTPClientRegistry(
                    runtime_configuration=self.configuration
                )
        except BaseException:
            _rollback_service_runtime_initialization(
                actor_http_clients=actor_http_clients_resource,
                telemetry=telemetry_resource,
                control_client=control_resource,
                event_loop=event_loop_resource,
            )
            raise

        self.telemetry: TelemetryEmitter = telemetry_resource
        self.control_client: ControlHTTPClient = control_resource
        self.event_loop: SDKEventLoopRunner = event_loop_resource
        self.actor_http_clients: ActorHTTPClientRegistry = actor_http_clients_resource
        self._actor_run_coordinators: weakref.WeakSet[
            ActorTrainingRunCoordinator | ActorSamplingRunCoordinator
        ] = weakref.WeakSet()
        self._actor_run_coordinators_lock: threading.Lock = threading.Lock()
        self._heartbeat_lock: threading.Lock = threading.Lock()
        self._heartbeat_tasks: set[asyncio.Task[None]] = set()
        self._heartbeat_slots: asyncio.Semaphore = asyncio.Semaphore(
            self.configuration.actor_heartbeat_max_in_flight
        )
        self._shutdown_lock: threading.Lock = threading.Lock()
        self._shutdown_started: list[bool] = [False]
        self._service_session_owner: _ServiceSessionOwner = _ServiceSessionOwner(
            self.control_client
        )
        with _active_service_runtimes_lock:
            _active_service_runtimes.add(self)
        # finalizer 捕获实际资源对象，回收不依赖 ServiceRuntime 本身仍可访问；显式
        # shutdown 与垃圾回收共享同一幂等入口。
        self._finalizer: weakref.finalize = weakref.finalize(
            self,
            _shutdown_service_runtime,
            self._shutdown_lock,
            self._shutdown_started,
            self._heartbeat_lock,
            self._heartbeat_tasks,
            self._actor_run_coordinators_lock,
            self._actor_run_coordinators,
            self._service_session_owner,
            self.actor_http_clients,
            self.telemetry,
            self.control_client,
            self.event_loop,
        )

    def bind_service_session(self, service_session_cuid: str) -> None:
        """把根 Client 创建的唯一远端 ServiceSession 交给 Runtime 管理。"""
        with self._shutdown_lock:
            if self._shutdown_started[0]:
                raise RuntimeError("ServiceRuntime is closed")
            self._service_session_owner.bind(service_session_cuid)

    def create_actor_training_run_coordinator(
        self,
        actor: ActorConnectionInfo,
        actor_jwt: ActorJWT,
        renewal_callback: ActorRenewalCallback,
        *,
        training_run_cuid: str,
    ) -> ActorTrainingRunCoordinator:
        """创建并注册复用运行时 HTTP registry 的 training run coordinator。"""
        # Hold the shutdown gate while constructing and registering the
        # coordinator. This prevents a concurrent finalizer from taking its
        # snapshot between the open check and registration.
        with self._shutdown_lock:
            if self._shutdown_started[0]:
                raise RuntimeError("ServiceRuntime is closed")
            actor_client = ActorHTTPClient(
                actor,
                actor_jwt,
                renewal_callback=renewal_callback,
                http_client_registry=self.actor_http_clients,
                telemetry=self.telemetry,
                telemetry_attributes={"training_run_cuid": training_run_cuid},
                runtime_configuration=self.configuration,
            )
            coordinator = ActorTrainingRunCoordinator(
                actor_client=actor_client,
                training_run_cuid=training_run_cuid,
                runtime=self,
                runtime_configuration=self.configuration,
            )
            with self._actor_run_coordinators_lock:
                self._actor_run_coordinators.add(coordinator)
        return coordinator

    def create_actor_sampling_run_coordinator(
        self,
        actor: ActorConnectionInfo,
        actor_jwt: ActorJWT,
        renewal_callback: ActorRenewalCallback,
        *,
        sampling_run_cuid: str,
    ) -> ActorSamplingRunCoordinator:
        """创建并注册复用运行时 HTTP registry 的 sampling run coordinator。"""
        with self._shutdown_lock:
            if self._shutdown_started[0]:
                raise RuntimeError("ServiceRuntime is closed")
            actor_client = ActorHTTPClient(
                actor,
                actor_jwt,
                renewal_callback=renewal_callback,
                http_client_registry=self.actor_http_clients,
                telemetry=self.telemetry,
                telemetry_attributes={"sampling_run_cuid": sampling_run_cuid},
                runtime_configuration=self.configuration,
            )
            coordinator = ActorSamplingRunCoordinator(
                actor_client=actor_client,
                sampling_run_cuid=sampling_run_cuid,
                runtime=self,
                runtime_configuration=self.configuration,
            )
            with self._actor_run_coordinators_lock:
                self._actor_run_coordinators.add(coordinator)
        return coordinator

    def start_actor_heartbeat(
        self,
        actor_client: ActorHeartbeatClient,
    ) -> ActorHeartbeatHandle:
        """为可弱引用的训练 Actor Client 启动运行时心跳。"""
        with self._shutdown_lock:
            if self._shutdown_started[0]:
                raise RuntimeError("ServiceRuntime is closed")
            if not self.configuration.actor_heartbeat_enabled:
                logger.debug(
                    "Heartbeat disabled for actor=%s",
                    actor_client.actor.actor_cuid,
                )
                return ActorHeartbeatHandle()
        try:
            actor_ref = weakref.ref(actor_client)
        except TypeError:
            logger.debug(
                "Heartbeat skipped for non-weakrefable actor=%s",
                actor_client.actor.actor_cuid,
            )
            return ActorHeartbeatHandle()
        if self.event_loop.is_runner_loop():
            task = self._register_actor_heartbeat_task(actor_ref)
        else:
            registration = self.event_loop.run_coroutine_threadsafe(
                self._register_actor_heartbeat_task_async(actor_ref)
            )
            task = registration.result()
        logger.debug(
            "Started actor heartbeat actor=%s interval=%s",
            actor_client.actor.actor_cuid,
            self.configuration.actor_heartbeat_interval_seconds,
        )
        return ActorHeartbeatHandle(task)

    async def _register_actor_heartbeat_task_async(
        self,
        actor_ref: weakref.ReferenceType[ActorHeartbeatClient],
    ) -> asyncio.Task[None]:
        """Create and register the real SDK-loop task for external callers."""
        return self._register_actor_heartbeat_task(actor_ref)

    def _register_actor_heartbeat_task(
        self,
        actor_ref: weakref.ReferenceType[ActorHeartbeatClient],
    ) -> asyncio.Task[None]:
        with self._shutdown_lock:
            if self._shutdown_started[0]:
                raise RuntimeError("ServiceRuntime is closed")
            task = asyncio.create_task(self._actor_heartbeat_loop(actor_ref))
            heartbeat_lock = self._heartbeat_lock
            heartbeat_tasks = self._heartbeat_tasks
            with heartbeat_lock:
                heartbeat_tasks.add(task)

        def cleanup(completed: asyncio.Task[None]) -> None:
            with heartbeat_lock:
                heartbeat_tasks.discard(completed)

        task.add_done_callback(cleanup)
        return task

    async def _actor_heartbeat_loop(
        self,
        actor_ref: weakref.ReferenceType[ActorHeartbeatClient],
    ) -> None:
        """按 Actor 返回的周期持续发送心跳，直到 Client 被释放或任务取消。"""
        interval = self.configuration.actor_heartbeat_interval_seconds
        while True:
            actor_client = actor_ref()
            if actor_client is None:
                return
            try:
                async with self._heartbeat_slots:
                    response = await actor_client.heartbeat()
                heartbeat_ms = response.get("heartbeat_ms")
                if isinstance(heartbeat_ms, (int, float)) and heartbeat_ms > 0:
                    interval = max(1.0, float(heartbeat_ms) / 1000.0)
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.debug("Actor heartbeat failed", exc_info=True)
            del actor_client
            await asyncio.sleep(interval)

    def shutdown(self, status: ServiceSessionCloseStatus = "ENDED") -> None:
        """触发运行时资源的幂等回收。"""
        self._service_session_owner.set_close_status(status)
        self._finalizer()


_active_service_runtimes: weakref.WeakSet[ServiceRuntime] = weakref.WeakSet()
_active_service_runtimes_lock = threading.Lock()


def cancel_active_service_runtimes() -> None:
    """在未捕获 Ctrl-C 退出时取消全部仍存活的服务会话。"""
    with _active_service_runtimes_lock:
        runtimes = list(_active_service_runtimes)
    for runtime in runtimes:
        runtime.shutdown(status="CANCELLED")
