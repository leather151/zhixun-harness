"""Low-level launcher for SDK-owned background workers."""

from __future__ import annotations

import _thread
from collections.abc import Callable
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class BackgroundWorkerHandle:
    """Identity of a dispatched worker without ``Thread.start`` synchronization."""

    ident: int

    def is_current(self) -> bool:
        return _thread.get_ident() == self.ident


def start(target: Callable[[], None]) -> BackgroundWorkerHandle:
    """Dispatch ``target`` without waiting on ``threading.Thread._started``."""

    return BackgroundWorkerHandle(_thread.start_new_thread(target, ()))
