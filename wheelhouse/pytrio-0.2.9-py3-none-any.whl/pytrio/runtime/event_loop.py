"""在专用后台线程中运行 SDK 的 asyncio 事件循环。"""

from __future__ import annotations

import asyncio
import logging
import threading
from collections.abc import Coroutine
from concurrent.futures import Future as ConcurrentFuture
from enum import Enum, auto
from time import monotonic, sleep
from typing import TypeVar

from pytrio.runtime import background_worker

T = TypeVar("T")
logger = logging.getLogger(__name__)

_DEFAULT_STARTUP_TIMEOUT_SECONDS = 5.0
_WORKER_DISPATCH_RETRY_DELAYS_SECONDS = (0.05, 0.2)


class _EventLoopRunnerState(Enum):
    STARTING = auto()
    RUNNING = auto()
    CLOSING = auto()
    CLOSED = auto()
    FAILED = auto()
    ABANDONED = auto()


class SDKEventLoopRunner:
    """在专用守护 worker 中运行 SDK asyncio 事件循环。

    公共同步 API 把协程提交到该循环并阻塞等待，异步 API 将 concurrent future 包装回
    调用方循环。构造只对 worker 就绪执行有界等待；事件循环无法及时启动时明确失败，
    避免 SDK 初始化永久阻塞。``close`` 负责停止循环并取消剩余 task。
    """

    def __init__(
        self,
        *,
        startup_timeout_seconds: float = _DEFAULT_STARTUP_TIMEOUT_SECONDS,
        shutdown_timeout_seconds: float = 5.0,
    ) -> None:
        self._startup_timeout_seconds: float = max(0.0, startup_timeout_seconds)
        self._shutdown_timeout_seconds: float = max(0.0, shutdown_timeout_seconds)
        self._state_lock: threading.Lock = threading.Lock()
        self._state: _EventLoopRunnerState = _EventLoopRunnerState.STARTING
        self._startup_finished: threading.Event = threading.Event()
        self._stopped: threading.Event = threading.Event()
        self._loop: asyncio.AbstractEventLoop | None = None
        self._worker: background_worker.BackgroundWorkerHandle | None = None
        startup_deadline = monotonic() + self._startup_timeout_seconds

        try:
            worker = self._dispatch_worker(startup_deadline)
        except Exception as exc:
            with self._state_lock:
                self._state = _EventLoopRunnerState.FAILED
            self._startup_finished.set()
            self._stopped.set()
            raise RuntimeError("SDK event-loop worker could not be started") from exc
        with self._state_lock:
            self._worker = worker

        startup_wait_seconds = max(0.0, startup_deadline - monotonic())
        if not self._startup_finished.wait(timeout=startup_wait_seconds):
            loop: asyncio.AbstractEventLoop | None = None
            with self._state_lock:
                # The worker mutates state while this thread waits; static narrowing
                # cannot model the cross-thread transition.
                if self._state is _EventLoopRunnerState.RUNNING:  # pyright: ignore[reportUnnecessaryComparison]
                    return
                if self._state is _EventLoopRunnerState.STARTING:
                    self._state = _EventLoopRunnerState.ABANDONED
                    loop = self._loop
            if loop is not None:
                try:
                    loop.call_soon_threadsafe(loop.stop)
                except RuntimeError:
                    pass
            raise RuntimeError(
                "SDK event-loop worker did not become ready within "
                f"{self._startup_timeout_seconds:.3f} seconds"
            )

        with self._state_lock:
            # The worker publishes RUNNING before setting the startup event.
            if self._state is _EventLoopRunnerState.RUNNING:  # pyright: ignore[reportUnnecessaryComparison]
                return
        raise RuntimeError("SDK event-loop worker failed during startup")

    def _dispatch_worker(
        self,
        startup_deadline: float,
    ) -> background_worker.BackgroundWorkerHandle:
        """Retry immediate dispatch failures without creating duplicate workers."""
        last_error: Exception | None = None
        attempts = len(_WORKER_DISPATCH_RETRY_DELAYS_SECONDS) + 1
        for attempt in range(attempts):
            if attempt > 0 and monotonic() >= startup_deadline:
                break
            try:
                return background_worker.start(self._worker_entrypoint)
            except Exception as exc:
                last_error = exc
                if attempt >= len(_WORKER_DISPATCH_RETRY_DELAYS_SECONDS):
                    break
                remaining = startup_deadline - monotonic()
                if remaining <= 0:
                    break
                delay = min(
                    _WORKER_DISPATCH_RETRY_DELAYS_SECONDS[attempt],
                    remaining,
                )
                logger.debug(
                    "SDK event-loop worker dispatch failed; retrying in %.3f seconds",
                    delay,
                    exc_info=True,
                )
                sleep(delay)
        if last_error is None:
            raise RuntimeError(
                "SDK event-loop startup deadline expired before dispatch"
            )
        raise last_error

    @property
    def loop(self) -> asyncio.AbstractEventLoop:
        with self._state_lock:
            loop = self._loop
        if loop is None:
            raise RuntimeError("SDK event loop is unavailable")
        return loop

    def _worker_entrypoint(self) -> None:
        loop: asyncio.AbstractEventLoop | None = None
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            with self._state_lock:
                if self._state is not _EventLoopRunnerState.STARTING:
                    return
                self._loop = loop
            loop.call_soon(self._mark_running, loop)
            loop.run_forever()
        except BaseException:
            logger.debug("SDK event-loop worker failed", exc_info=True)
            with self._state_lock:
                if self._state in {
                    _EventLoopRunnerState.STARTING,
                    _EventLoopRunnerState.RUNNING,
                }:
                    self._state = _EventLoopRunnerState.FAILED
        finally:
            if loop is not None:
                self._close_event_loop(loop)
            with self._state_lock:
                if self._state in {
                    _EventLoopRunnerState.RUNNING,
                    _EventLoopRunnerState.CLOSING,
                    _EventLoopRunnerState.ABANDONED,
                }:
                    self._state = _EventLoopRunnerState.CLOSED
                elif self._state is _EventLoopRunnerState.STARTING:
                    self._state = _EventLoopRunnerState.FAILED
            self._startup_finished.set()
            self._stopped.set()

    @staticmethod
    def _close_event_loop(loop: asyncio.AbstractEventLoop) -> None:
        """Best-effort cancel pending tasks and close a worker-owned loop."""
        try:
            pending = asyncio.all_tasks(loop)
            for task in pending:
                task.cancel()
            if pending:
                loop.run_until_complete(
                    asyncio.gather(*pending, return_exceptions=True)
                )
            loop.run_until_complete(loop.shutdown_asyncgens())
            loop.run_until_complete(loop.shutdown_default_executor())
        except BaseException:
            logger.debug("SDK event-loop task cleanup failed", exc_info=True)
        finally:
            try:
                loop.close()
            except BaseException:
                logger.debug("SDK event loop close failed", exc_info=True)

    def _mark_running(self, loop: asyncio.AbstractEventLoop) -> None:
        with self._state_lock:
            if self._state is _EventLoopRunnerState.STARTING and self._loop is loop:
                self._state = _EventLoopRunnerState.RUNNING
        self._startup_finished.set()

    def run_coroutine_threadsafe(
        self,
        coro: Coroutine[object, object, T],
    ) -> ConcurrentFuture[T]:
        """线程安全地提交协程，并在拒绝提交时关闭协程对象。"""
        with self._state_lock:
            loop = self._loop
            if (
                self._state is not _EventLoopRunnerState.RUNNING
                or loop is None
                or not loop.is_running()
            ):
                coro.close()
                raise RuntimeError("SDKEventLoopRunner is closed")
            try:
                return asyncio.run_coroutine_threadsafe(coro, loop)
            except BaseException:
                coro.close()
                raise

    def is_runner_loop(self) -> bool:
        try:
            with self._state_lock:
                loop = self._loop
            return asyncio.get_running_loop() is loop
        except RuntimeError:
            return False

    def run_sync(self, coro: Coroutine[object, object, T]) -> T:
        """从 SDK 循环之外同步等待协程结果。"""
        if self.is_runner_loop():
            coro.close()
            raise RuntimeError(
                "Cannot synchronously wait on SDKEventLoopRunner from its own event loop"
            )
        try:
            future = self.run_coroutine_threadsafe(coro)
        except Exception:
            coro.close()
            raise
        return future.result()

    async def run_async(self, coro: Coroutine[object, object, T]) -> T:
        """在任意调用方循环中异步等待 SDK 协程结果。"""
        if self.is_runner_loop():
            return await coro
        try:
            future = self.run_coroutine_threadsafe(coro)
        except Exception:
            coro.close()
            raise
        return await asyncio.wrap_future(future)

    def close(self) -> None:
        """幂等停止专用事件循环并有界等待后台 worker 回收。"""
        with self._state_lock:
            if self._state is _EventLoopRunnerState.CLOSED:
                return
            if self._state is _EventLoopRunnerState.STARTING:
                self._state = _EventLoopRunnerState.ABANDONED
            elif self._state is _EventLoopRunnerState.RUNNING:
                self._state = _EventLoopRunnerState.CLOSING
            loop = self._loop
            worker = self._worker

        if loop is not None and loop.is_running():
            try:
                if worker is not None and worker.is_current():
                    loop.call_soon(loop.stop)
                else:
                    loop.call_soon_threadsafe(loop.stop)
            except RuntimeError:
                pass
        if worker is None or not worker.is_current():
            self._stopped.wait(timeout=self._shutdown_timeout_seconds)
